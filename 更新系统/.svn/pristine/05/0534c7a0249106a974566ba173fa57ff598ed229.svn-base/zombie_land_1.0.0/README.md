# factorioCatmod

Replaces biters with cute cats, because it had to happen.