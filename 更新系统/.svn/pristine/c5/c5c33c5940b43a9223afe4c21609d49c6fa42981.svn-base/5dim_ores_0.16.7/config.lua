--Define if ores is installed
ores = true --Default: True