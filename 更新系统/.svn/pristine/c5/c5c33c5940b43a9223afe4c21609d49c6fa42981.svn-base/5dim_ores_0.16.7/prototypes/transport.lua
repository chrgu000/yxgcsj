data.raw.recipe["5d-mk5-transport-belt"].ingredients = {
    {"iron-plate", 10},
    {"steel-plate", 10},
    {"processing-unit", 2},
    {"5d-mk4-transport-belt", 2},
    };
data.raw.recipe["5d-mk4-transport-belt"].ingredients = {
      {"iron-plate", 10},
      {"steel-plate", 10},
      {"advanced-circuit", 2},
      {"express-transport-belt", 2},
    };
data.raw.recipe["5d-storage-tank"].ingredients = {
      {"storage-tank", 1},
      {"tin-plate", 15},
      {"lead-plate", 7},
      {"stone", 5},
    };
data.raw.recipe["5d-mk5-splitter"].ingredients = {
      {"5d-mk4-splitter", 5},
      {"processing-unit", 5},
      {"iron-plate", 5},
      {"transport-belt", 4},
    };
data.raw.recipe["5d-mk4-splitter"].ingredients = {
      {"express-splitter", 1},
      {"advanced-circuit", 15},
      {"iron-plate", 5},
      {"express-transport-belt", 4},
    };
data.raw.recipe["5d-pipe-to-ground-mk3-50"].ingredients = {
      {"5d-pipe-mk3", 50},
      {"steel-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk3-30"].ingredients = {
      {"5d-pipe-mk3", 30},
      {"steel-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk3"].ingredients = {
      {"5d-pipe-mk3", 10},
      {"steel-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk2-50"].ingredients = {
      {"5d-pipe-mk2", 50},
      {"copper-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk2-30"].ingredients = {
      {"5d-pipe-mk2", 30},
      {"copper-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk2"].ingredients = {
      {"5d-pipe-mk2", 10},
      {"copper-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk1-50"].ingredients = {
      {"pipe", 50},
      {"iron-plate", 5},
    };
data.raw.recipe["5d-pipe-to-ground-mk1-30"].ingredients = {
      {"pipe", 30},
      {"iron-plate", 5},
    };
data.raw.recipe["5d-iron-chest-mk2-3"].ingredients = {
		{"iron-chest", 5},
		{"iron-plate", 80},
		{"lead-plate", 60},
		{"steel-plate", 40},
    };
data.raw.recipe["5d-iron-chest-mk2-2"].ingredients = {
		{"iron-chest", 1},
		{"iron-plate", 20},
    };
data.raw.recipe["5d-iron-chest-mk3"].ingredients = {
		{"iron-chest", 4},
		{"iron-plate", 20},
    };
data.raw.recipe["5d-iron-chest-mk2"].ingredients = {
		{"iron-chest", 1},
		{"iron-plate", 20},
    };
data.raw.recipe["5d-mk5-transport-belt-to-ground-50"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk5-transport-belt", 50}
    };
data.raw.recipe["5d-mk5-transport-belt-to-ground-30"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk5-transport-belt", 30}
    };
data.raw.recipe["5d-mk5-transport-belt-to-ground"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk5-transport-belt", 5}
    };
data.raw.recipe["5d-mk4-transport-belt-to-ground-50"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk4-transport-belt", 50}
    };
data.raw.recipe["5d-mk4-transport-belt-to-ground-30"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk4-transport-belt", 30}
    };
data.raw.recipe["5d-mk4-transport-belt-to-ground"].ingredients = {
      {"iron-plate", 10},
      {"5d-mk4-transport-belt", 5}
    };
data.raw.recipe["5d-mk3-transport-belt-to-ground-50"].ingredients = {
      {"iron-plate", 10},
      {"express-transport-belt", 50}
    };
data.raw.recipe["5d-mk3-transport-belt-to-ground-30"].ingredients = {
      {"iron-plate", 10},
      {"express-transport-belt", 30}
    };
data.raw.recipe["5d-mk2-transport-belt-to-ground-50"].ingredients = {
      {"iron-plate", 10},
      {"fast-transport-belt", 50}
    };
data.raw.recipe["5d-mk2-transport-belt-to-ground-30"].ingredients = {
      {"iron-plate", 10},
      {"fast-transport-belt", 30}
    };
data.raw.recipe["5d-mk1-transport-belt-to-ground-50"].ingredients = {
      {"iron-plate", 10},
      {"transport-belt", 50}
    };
data.raw.recipe["5d-mk1-transport-belt-to-ground-30"].ingredients = {
      {"iron-plate", 10},
      {"transport-belt", 30}
    };