data.raw.recipe["5d-repair-pack-2"].ingredients = {
  {"electronic-circuit", 2},
  {"iron-gear-wheel", 1}
};
data.raw.recipe["5d-passive"].ingredients = {
  {"logistic-chest-passive-provider", 1},
  {"advanced-circuit", 1}
};
data.raw.recipe["5d-storage"].ingredients = {
  {"logistic-chest-storage", 1},
  {"advanced-circuit", 1}
};
data.raw.recipe["5d-logistic-robot-2"].ingredients = {
  {"logistic-robot", 1},
  {"advanced-circuit", 2}
};
data.raw.recipe["5d-construction-robot-2"].ingredients = {
  {"construction-robot", 1},
  {"electronic-circuit", 2}
};
data.raw.recipe["5d-roboport-2"].ingredients = {
  {"roboport", 1},
  {"zinc-plate", 15},
  {"processing-unit", 20},
};
data.raw.recipe["5d-requester"].ingredients = {
  {"logistic-chest-requester", 1},
  {"advanced-circuit", 1}
};
data.raw.recipe["5d-logistic-robot-3"].ingredients = {
  {"5d-logistic-robot-2", 1},
  {"advanced-circuit", 2}
};
data.raw.recipe["5d-construction-robot-3"].ingredients = {
  {"5d-construction-robot-2", 1},
  {"electronic-circuit", 2}
};
data.raw.recipe["5d-logistic-robot-4"].ingredients = {
  {"5d-logistic-robot-3", 1},
  {"advanced-circuit", 2}
};
data.raw.recipe["5d-construction-robot-4"].ingredients = {
  {"5d-construction-robot-3", 1},
  {"electronic-circuit", 2}
};