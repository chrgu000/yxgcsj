data.raw.recipe["5d-speed-productivity-5"].ingredients = {
      {"5d-speed-module-5", 1},
      {"5d-productivity-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-speed-pollution-5"].ingredients = {
      {"5d-speed-module-5", 1},
      {"5d-pollution-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-speed-pollution-4"].ingredients = {
      {"5d-speed-module-4", 1},
      {"5d-pollution-module-4", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-speed-effectivity-5"].ingredients = {
      {"5d-speed-module-5", 1},
      {"5d-effectivity-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-speed-effectivity-4"].ingredients = {
      {"5d-speed-module-4", 1},
      {"5d-effectivity-module-4", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-speed-module-5"].ingredients = {
      {"5d-speed-module-4", 4},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 5},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-speed-module-4"].ingredients = {
      {"speed-module-3", 4},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 1},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-productivity-module-5"].ingredients = {
      {"5d-productivity-module-4", 5},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 5},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-productivity-module-4"].ingredients = {
      {"productivity-module-3", 5},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 1},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-pollution-productivity-5"].ingredients = {
      {"5d-pollution-module-5", 1},
      {"5d-productivity-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-pollution-productivity-4"].ingredients = {
      {"5d-pollution-module-4", 1},
      {"5d-productivity-module-4", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-pollution-effectivity-5"].ingredients = {
      {"5d-pollution-module-5", 1},
      {"5d-effectivity-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-pollution-effectivity-4"].ingredients = {
      {"5d-pollution-module-4", 1},
      {"5d-effectivity-module-4", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-pollution-module-5"].ingredients = {
      {"5d-pollution-module-4", 4},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 5},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-pollution-module-4"].ingredients = {
      {"5d-pollution-module-3", 4},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 1},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-pollution-module-3"].ingredients = {
      {"5d-pollution-module-2", 4},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-pollution-module-2"].ingredients = {
      {"5d-pollution-module-1", 4},
      {"processing-unit", 5},
      {"advanced-circuit", 5},
    };
data.raw.recipe["5d-pollution-module-1"].ingredients = {
      {"advanced-circuit", 5},
      {"electronic-circuit", 5},
    };
data.raw.recipe["5d-effectivity-productivity-5"].ingredients = {
      {"5d-effectivity-module-5", 1},
      {"5d-productivity-module-5", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-effectivity-productivity-4"].ingredients = {
      {"5d-effectivity-module-4", 1},
      {"5d-productivity-module-4", 1},
      {"5d-gold-circuit", 1},
    };
data.raw.recipe["5d-effectivity-module-5"].ingredients = {
      {"5d-effectivity-module-4", 5},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 5},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-effectivity-module-4"].ingredients = {
      {"effectivity-module-3", 5},
      {"advanced-circuit", 5},
      {"processing-unit", 5},
      {"5d-gold-circuit", 1},
      --{"alien-artifact", 1}
    };
data.raw.recipe["5d-welder"].ingredients = {
      {"iron-plate", 10},
      {"electronic-circuit", 3},
      {"iron-gear-wheel", 5},
      {"assembling-machine-3", 1}
    };