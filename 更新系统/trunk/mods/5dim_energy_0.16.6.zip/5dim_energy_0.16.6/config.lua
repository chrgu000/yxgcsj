--Define if energy is installed
energy = true --Default: True