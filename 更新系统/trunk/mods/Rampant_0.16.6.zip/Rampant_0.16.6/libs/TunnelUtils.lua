local tunnelUtils = {}

function tunnelUtils.digTunnel(map, surface, natives, startChunk, endChunk)
    
end

function tunnelUtils.fillTunnel(map, surface, natives, tilePositions)
    local tunnels = natives.tunnels
    for i=1, #tunnels do
        
    end
end

return tunnelUtils
