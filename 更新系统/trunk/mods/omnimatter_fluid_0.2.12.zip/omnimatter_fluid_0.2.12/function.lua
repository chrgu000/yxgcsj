if not omni then omni={} end	
if not omni.fluid then omni.fluid={} end

forbidden_boilers={}

function omni.fluid.excempt_boiler(boiler)
	forbidden_boilers[boiler]=true
end