omni.fluid.excempt_boiler("crystal-reactor")
omni.fluid.excempt_boiler("burner-turbine")