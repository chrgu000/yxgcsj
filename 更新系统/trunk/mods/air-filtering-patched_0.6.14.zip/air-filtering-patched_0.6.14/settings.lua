data:extend(
{
  {
    type = "bool-setting",
    name = "af-integrate-bobs-plates",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "af-integrate-bobs-electronics",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "af-integrate-bobmods-tech",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
  {
    type = "bool-setting",
    name = "af-use-powerbar-icons",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },
}
)