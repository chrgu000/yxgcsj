function goAfunnyguys(entity, tiles, item)
  local surface = entity.surface
  if item.name == "landfill" then
    for i,tile in pairs(tiles) do
      surface.set_tiles({{name="grass-3", position=tile.position}})
    end
  elseif item.name == "art-dug-water" then
    for i,tile in pairs(tiles) do
      surface.set_tiles({{name="water", position=tile.position}})
    end
  end
end

script.on_event(defines.events.on_player_built_tile, function(event)
  goAfunnyguys(game.players[event.player_index], event.tiles, event.item)
end)

script.on_event(defines.events.on_robot_built_tile, function(event)
  goAfunnyguys(event.robot, event.tiles, event.item)
end)