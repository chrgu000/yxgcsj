data:extend(
{
  {
    type = "item",
    name = "art-dug-water",
    icon = "__artsDugWater__/graphics/icons/dug-water.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "terrain",
    order = "d[art-dug-water]",
    stack_size = 2400,
    place_as_tile =
    {
      result = "water",
      condition_size = 1,
      condition = { "water-tile" }
    }
  },
  {
    type = "recipe",
    name = "art-dug-water",
    energy_required = 0.5,
    enabled = false,
    category = "crafting-with-fluid",
    ingredients =
    {
      {type = "fluid", name = "water", amount = 20}
    },
    result= "art-dug-water",
    result_count = 1
  },
  {
    type = "technology",
    name = "art-dug-water",
    icon = "__artsDugWater__/graphics/technology/dug-water.png",
    icon_size = 128,
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
      },
      time = 30
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "art-dug-water"
      }
    },
    order = "b-e"
  }
}
)

local art_landfill = util.table.deepcopy(data.raw["tile"]["grass-3"])
art_landfill.name = "landfill"
art_landfill.autoplace = {}
art_landfill.can_be_part_of_blueprint = nil
data:extend({art_landfill})
data.raw["item"]["landfill"].stack_size = 2400
data.raw["item"]["landfill"].place_as_tile.result = "landfill"
