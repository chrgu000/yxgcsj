for _,kind in pairs({"generator","boiler","assembling-machine","locomotive","furnace","mining-drill"}) do
	for _, b in pairs(data.raw[kind]) do
		if b.smoke  ~= nil then
			b.smoke = nil
		end
		if b.energy_source and b.energy_source.smoke then
			b.energy_source.smoke = nil
		end
		if b.burner and b.burner.smoke then
			b.burner.smoke = nil
		end
	end
end