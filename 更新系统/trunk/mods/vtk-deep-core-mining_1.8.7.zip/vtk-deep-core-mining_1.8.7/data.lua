require("prototypes.deepcore-mining-resources")
require("prototypes.deepcore-mining-items")
require("prototypes.deepcore-mining-technology")