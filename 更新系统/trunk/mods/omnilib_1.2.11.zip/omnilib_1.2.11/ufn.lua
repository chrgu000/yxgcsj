local UFN = {
limacandia = {name = "Limacandia",population = 192.14,seats=0},
soviet= {name = "Soviet union",population = 223.145,seats=0},
usa= {name = "United States",population = 147.50,seats=0},
}

local seats = 10000

local total_pop = 0

log("United Federation of Nations")

for _,nat in pairs(UFN) do
	total_pop = total_pop + nat.population
end
for _,nat in pairs(UFN) do
	nat.ratio = 100*nat.population/total_pop
end
local determined_seats = 0
log(serpent.block(UFN))

local tot_low = 1

local find_max = function()
	local m = 0
	local low=false
	for _,nat in pairs(UFN) do
		if type(m) == "table" then
			if nat.ratio > m.ratio then
				m=nat
			end
		else
			m=nat
		end
		if nat.ratio < 1 then low=true end
	end
	if low then
		tot_low=tot_low+1
		for _,nat in pairs(UFN) do
			nat.ratio = nat.ratio*100
		end
	end
	return m
end

while determined_seats<seats do
	local nation = find_max()
	nation.ratio = nation.ratio/2
	nation.seats=nation.seats+1
	determined_seats=determined_seats+1
	--log(serpent.block(UFN))
end

for _,nat in pairs(UFN) do
	log(nat.name..": "..nat.seats)
end