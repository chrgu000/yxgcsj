if not omni then omni={} end
if not omni.marathon then omni.marathon={} end

standardized_recipes={}

function omni.marathon.standardise(recipe)
	--local new = table.deepcopy(recipe)
	if recipe == nil then return nil end
	if not recipe.expensive then recipe.expensive={} end
	if not recipe.normal then recipe.normal={} end
	
	local ingredients = {}
	--ingredients.normal = recipe.ingredients
	if recipe.normal and recipe.normal.ingredients and recipe.expensive and recipe.expensive.ingredients then
		ingredients.normal = table.deepcopy(recipe.normal.ingredients)
		ingredients.expensive = table.deepcopy(recipe.expensive.ingredients)
	else
		ingredients = {expensive=table.deepcopy(recipe.ingredients),normal=table.deepcopy(recipe.ingredients)}
	end
	log("standardizing: "..recipe.name)
	--log(serpent.block(recipe))
	local std_ingredients = {normal = {}, expensive = {}}
	
	recipe.normal.ingredients={}
	recipe.expensive.ingredients={}
	for _, diff in pairs({"normal","expensive"}) do
		for i,ing in pairs(ingredients[diff]) do
			local temp = {}
			if ing.name then
				temp = {type = ing.type, name=ing.name,amount=ing.amount,maximum_temperature=ing.maximum_temperature,minimum_temperature=ing.minimum_temperature}
				if not temp.type then temp.type ="item" end
			else
				temp = {type = "item", name=ing[1],amount=ing[2]}
			end	
			recipe[diff].ingredients[i]=table.deepcopy(temp)
		end
	end
	local results = {}
	if recipe.normal and (recipe.normal.results or recipe.normal.result)then
		if recipe.normal.results then
			results.normal = table.deepcopy(recipe.normal.results)
		else
			results.normal = {{recipe.normal.result,recipe.normal.result_count}}
			if not results.normal[1][2] then results.normal[1][2]=1 end
		end
	end
	if recipe.expensive and (recipe.expensive.results or recipe.expensive.result)then
		if recipe.expensive.results then
			results.expensive = table.deepcopy(recipe.expensive.results)
		else
			results.expensive = {{recipe.expensive.result,recipe.expensive.result_count}}
			if not results.expensive[1][2] then results.expensive[1][2]=1 end
		end
	end
	if recipe.results or recipe.result then
		if recipe.results then
			if not results.expensive then results.expensive = table.deepcopy(recipe.results) end
			if not results.normal then results.normal = table.deepcopy(recipe.results) end
		else
			if not results.expensive then results.expensive = {{recipe.result,recipe.result_count}} end
			if not results.normal then results.normal = {{recipe.result,recipe.result_count}} end
			if not (results.expensive[1] and results.expensive[1][2]) then results.expensive[1][2]=1 end
			if not results.normal[1][2] then results.normal[1][2]=1 end
		end
	end
	std_results = {normal={},expensive={}}
	recipe.normal.results={}
	recipe.expensive.results={}
	for i, diff in pairs({"normal","expensive"}) do
		for j,res in pairs(results[diff]) do
			local temp = {}
			if res.name then
				temp = {type = res.type, name=res.name,amount=res.amount,probability = res.probability, amount_min = res.amount_min, amount_max = res.amount_max,temperature=res.temperature}
				if not temp.type then temp.type ="item" end
			else
				temp = {type = "item", name=res[1],amount=res[2]}
			end	
			recipe[diff].results[j] = table.deepcopy(temp)
		end
	end
	recipe.result = nil
	recipe.result_count = nil
	recipe.results = nil
	recipe.ingredients = nil
	
	--new.normal.ingredients=std_ingredients.normal
	--new.normal.results=std_results.normal
	--new.expensive.ingredients=std_ingredients.expensive
	--new.expensive.results=std_results.expensive
	
	--if #recipe.normal.results==1 then recipe.normal.main_product = recipe.normal.results[1].name end
	--if #recipe.expensive.results==1 then recipe.expensive.main_product = recipe.expensive.results[1].name end
	
	if recipe.normal.hidden == nil then recipe.normal.hidden = recipe.hidden end
	if recipe.expensive.hidden == nil then recipe.expensive.hidden = recipe.hidden end
	if recipe.normal.enabled == nil then recipe.normal.enabled = recipe.enabled end
	if recipe.expensive.enabled == nil then recipe.expensive.enabled = recipe.enabled end
	
	if not recipe.subgroup and recipe.main_product and recipe.main_product ~="" then
		local it = omni.lib.find_prototype(recipe.main_product)
		if it.subgroup then
			recipe.subgroup = it.subgroup
		elseif it.type=="fluid" then
			recipe.subgroup="fluid-recipes"
		end
	end
	
	--[[
	if recipe.normal.subgroup == nil then
		if recipe.subgroup then
			recipe.normal.subgroup = recipe.subgroup
		elseif #recipe.normal.results == 1 then
			local proto = omni.lib.find_prototype(recipe.normal.results[1].name)
			if proto then 
				recipe.normal.subgroup = proto.subgroup
			end
		end
	end
	if recipe.expensive.subgroup == nil then
		if recipe.subgroup then
			recipe.expensive.subgroup = recipe.subgroup
		elseif #recipe.expensive.results == 1 then
			local proto = omni.lib.find_prototype(recipe.expensive.results[1].name)
			recipe.expensive.subgroup = proto.subgroup
		end
	end]]
	
	--recipe.main_product = recipe.main_product or recipe.normal.main_product or recipe.expensive.main_product
	--recipe.normal.main_product=recipe.main_product or recipe.normal.main_product or recipe.expensive.main_product
	--recipe.expensive.main_product=recipe.main_product or recipe.normal.main_product or recipe.expensive.main_product
	
	
	if recipe.normal.category == nil then recipe.normal.category = recipe.category end
	if recipe.expensive.category == nil then recipe.expensive.category = recipe.category end
	--if recipe.normal.main_product == nil then recipe.normal.main_product = recipe.main_product end
	--if recipe.expensive.main_product == nil then recipe.expensive.main_product = recipe.main_product end
	if recipe.normal.energy_required == nil then recipe.normal.energy_required = recipe.energy_required or recipe.energy_required or 0.5 end
	if recipe.expensive.energy_required == nil then recipe.expensive.energy_required = recipe.energy_required or recipe.energy_required or 0.5 end
	recipe.hidden = nil
	recipe.enabled = nil
	
	recipe.icon_size = 32
	recipe.energy_required = nil
	if (recipe.main_product and recipe.main_product ~= "") or (recipe.normal.main_product and recipe.normal.main_product ~= "") or (recipe.normal.main_product and recipe.normal.main_product ~= "") then
		local item = omni.lib.find_prototype(recipe.main_product or recipe.normal.main_product or recipe.expensive.main_product) 
		if item.icon then recipe.icon = item.icon end
		if item.icons then recipe.icons = item.icons end
	end
	recipe.main_product=nil
	recipe.normal.main_product=nil
	recipe.expensive.main_product=nil
	standardized_recipes[recipe.name] = true
	return table.deepcopy(new)
end