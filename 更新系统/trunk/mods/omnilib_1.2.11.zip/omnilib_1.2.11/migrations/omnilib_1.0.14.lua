for _, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()
end

function end_with(a,b)
	return string.sub(a,string.len(a)-string.len(b)+1) == b
end

for i, force in pairs(game.forces) do 
	if force.technologies["fluid-handling"].researched then
		for _, eff in pairs(force.technologies["fluid-handling"].effects) do
			if eff.type=="unlock-recipe" and eff.name and string.find(eff.name,"barrel") then
				force.recipes[eff.recipe].enabled=true
			end
		end
	end
end

