if not omni then omni = {} end
if not omni.lib then omni.lib = {} end
omni.tint_level = {{r=0,g=0,b=0},{r=1,g=1,b=0},{r=1,g=0,b=0},{r=0,g=0,b=1},{r=1,g=0,b=1},{r=0,g=1,b=0}}
require("prototypes.functions")
require("prototypes.recipe-standard")
--require("bobs-planets")
require("ufn")