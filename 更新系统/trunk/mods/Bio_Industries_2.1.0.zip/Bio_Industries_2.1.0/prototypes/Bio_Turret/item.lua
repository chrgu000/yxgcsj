data:extend({


  
  --- Conversion Turret
    {
    type = "item",
    name = "bio-turret",
    icon = "__Bio_Industries__/graphics/icons/bio_turret_icon.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
	order = "aa[turret]-a[gun-turret]",
    place_result = "bio-turret",
    stack_size = 50
  },
  
})
