data:extend{
    {
        type = "bool-setting",
        name = "crash-sequence",
        setting_type = "startup",
        default_value = true,
    }
}
