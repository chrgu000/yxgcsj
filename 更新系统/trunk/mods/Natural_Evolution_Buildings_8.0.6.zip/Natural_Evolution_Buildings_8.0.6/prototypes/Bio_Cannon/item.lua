data:extend({

	
	-- Hive Buster Turret
	
		{
	type = "item",
	name = "Bio_Cannon_Area",
	icon = "__Natural_Evolution_Buildings__/graphics/icons/biocannon_icon.png",
	icon_size = 32,
	flags = { "goes-to-quickbar" },
	subgroup = "defensive-structure",
	order = "x[turret]-x[gun-turret]",
	place_result = "Bio_Cannon_Area",
	stack_size = 1,
	},
	
})