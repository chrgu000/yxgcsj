data.raw["player"]["player"].inventory_size = 100;
data.raw["player"]["player"].light = {{ minimum_darkness = 0.3, intensity = 0.9, size = 40,},}