maximum_speed = 64			  -- maximum speed factor. Lower this to 32 or 16 if your computer is not supporting it.
clock_cycle_in_ticks = 5      -- number of game ticks between display clock refresh.
clock_combinator_cycle = 10   -- number of clock cycles between combinator clock refresh.
always_day_enabled = true	  -- set to false if you want to disable the possibility to swith on "always day" mode.

