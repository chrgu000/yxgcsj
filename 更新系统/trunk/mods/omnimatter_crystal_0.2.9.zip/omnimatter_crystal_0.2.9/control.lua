local string_contained_list = function(str, list)
	for i=1, #list do
		if type(list[i])=="table" then
			local found_it = true
			for _,words in pairs(list[i]) do
				found_it = found_it and string.find(str,words)
			end
			if found_it then return true end
		else
			if string.find(str,list[i]) then return true end
		end
	end
	return false
end

local ord={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r"}

script.on_configuration_changed( function(conf)
	local material_level = 0
	for each, force in pairs(game.forces) do
		for _, tech in pairs(force.technologies) do
			if tech.researched then
				if string_contained_list(tech.name,{{"pseudoliquid","amorphous","crystal"}}) then
					local length = string.len(tech.name)
					local lvl = 0
					if string.sub(tech.name,length-1,length-1) == "-" then
						lvl = tonumber(string.sub(tech.name,length,length))
					else
						lvl = tonumber(string.sub(tech.name,length-1,length))	
					end
					if lvl+1 > material_level then material_level=lvl+1 end
				end
			end
		end
		for i=1,material_level-1 do
			if force.recipes["pseudoliquid-amorphous-crystal"..ord[i]] then
				force.recipes["pseudoliquid-amorphous-crystal"..ord[i]].enabled = false	
			end
		end
		if material_level > 1 then
			force.recipes["pseudoliquid-amorphous-crystal"..ord[material_level]].enabled = true
		end
	end
end)

script.on_event(defines.events.on_research_finished, function(event)
	local tech = event.research
	--pseudoliquid-amorphous-crystal
	if string_contained_list(tech.name,{{"pseudoliquid","amorphous","crystal"}}) then
		local length = string.len(tech.name)
		local lvl = 0
		if string.sub(tech.name,length-1,length-1) == "-" then
			lvl = tonumber(string.sub(tech.name,length,length))
		else
			lvl = tonumber(string.sub(tech.name,length-1,length))		
		end
		lvl=lvl+1
		if lvl > 1 then
			for i=1,4 do
				for _,surface in pairs(game.surfaces) do
					for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name="crystallomnizer-"..i}) do
						local rec = entity.get_recipe()
						if rec and rec.name == "pseudoliquid-amorphous-crystal"..ord[lvl-1] then
							entity.set_recipe("pseudoliquid-amorphous-crystal"..ord[lvl])
						end
					end
				end
			end
			for i=1,lvl-1 do
				if tech.force.recipes["pseudoliquid-amorphous-crystal"..ord[i]] then
					tech.force.recipes["pseudoliquid-amorphous-crystal"..ord[i]].enabled = false	
				end
			end
		end
	end
end)