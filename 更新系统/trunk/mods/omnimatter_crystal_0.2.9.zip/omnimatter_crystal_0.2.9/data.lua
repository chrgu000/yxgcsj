if not omni then omni={} end
if not omni.crystal then omni.crystal={} end

require("prototypes.fluids")
require("prototypes.recipes.acids")
require("prototypes.crystals")
require("prototypes.crystal-making")
require("prototypes.recipes.acids")
require("prototypes.categories")
require("prototypes.fuel-category")
require("prototypes.crystallonics")
require("prototypes.buildings.crystallomnizer")
--require("prototypes.circuit")
require("prototypes.technology.crystallology")
require("functions")

--[[
data:extend({
  {
    type = "custom-input",
    name = "crystal-increase",
    key_sequence = "U",
    consuming = "none"
  },{
    type = "custom-input",
    name = "crystal-decrease",
    key_sequence = "J",
    consuming = "none"
  }
})]]
--[[
add_colour("iron",{0.46,0.53,0.59},"Fe")
add_colour("cobalt",{0.18,0.26,0.37},"Co")
add_colour("silver",{0.62,0.67,0.71},"Ag")
add_colour("chrome",{0.64,0.60,0.79},"Cr")
add_colour("gold",{0.82,0.66,0.15},"Au")
--add_colour("copper",{0.75,0.49,0.42})
add_colour("copper",{0.55,0.36,0.31},"Cu")
add_colour("rutile",{0.42,0.33,0.41},"Ti")
add_colour("lead",{0.24,0.24,0.28},"Pb")
add_colour("manganese",{0.75,0.29,0.29},"Mg")
add_colour("tin",{0.30,0.46,0.34},"Sn")
add_colour("zinc",{0.37,0.6,0.65},"Zn")
add_colour("aluminium",{0.58,0.54,0.28},"Al")
add_colour("bauxite",{0.58,0.54,0.28},"Al")
add_colour("steel",{0.0,0.60,0.0},"St")
add_colour("tungsten",{0.48,0.35,0.23},"W")
add_colour("nickel",{0.20,0.43,0.40},"Ni")
add_colour("omnine",{0.40,0.00,0.60},"Om")
]]
--require("prototypes.inserter")
require("prototypes.buildings.omniplant")