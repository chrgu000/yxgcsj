data:extend(
{
  {
    type = "bool-setting",
    name = "omnicrystal-sloth",
    setting_type = "startup",
    default_value = false,
	order=a
  },
}
)


