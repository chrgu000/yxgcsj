data:extend({
  {
    type = "item",
    name = "omnine",
    icon = "__omnimatter_crystal__/graphics/icons/omnine.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
	subgroup = "omni-basic",
    fuel_category = "crystal",
	fuel_value = "18MJ",
    stack_size = 200
  },
    {
    type = "item",
    name = "omnine-shards",
    icon = "__omnimatter_crystal__/graphics/icons/omnine-shards.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
	subgroup = "omni-basic",
    fuel_category = "crystal",
	fuel_value = "3500kJ",
    stack_size = 200
  },

})
if mods["angelsrefining"] then local cat = "ore-sorting-t1" end
data:extend({
	{
	type = "recipe",
	name = "omnine-distillation-quick",
	category = "omniplant",
	subgroup = "omnine",
    enabled = false,
    ingredients = {
    {type = "fluid", name = "omni-sludge", amount=20000}
    },
	order = "a[angelsore1-crushed]",
    icon = "__omnimatter_crystal__/graphics/icons/omnine.png",
    icon_size = 32,
	results = {{type = "item", name = "omnine", amount=1}},
    energy_required = 180,
    },
	{
	type = "recipe",
	name = "omnine-distillation-slow",
	category = "omniplant",
	subgroup = "omnine",
    enabled = false,
    ingredients = {
    {type = "fluid", name = "omni-sludge", amount=2000}
    },
	order = "a[angelsore1-crushed]",
    icon = "__omnimatter_crystal__/graphics/icons/omnine.png",
    icon_size = 32,
	results = {{type = "item", name = "omnine", amount=1}},
    energy_required = 1800,
    },
	{
	type = "recipe",
	name = "omnine-growth",
	category = "omniplant",
	subgroup = "omnine",
    enabled = false,
    ingredients = {
    {type = "item", name = "omnine-shards", amount=1},
    {type = "fluid", name = "omni-sludge", amount=100},
    },
	order = "a[angelsore1-crushed]",
    icon = "__omnimatter_crystal__/graphics/icons/omnine.png",
    icon_size = 32,
	results = {{type = "item", name = "omnine", amount=5}},
    energy_required = 10,
    },
	{
	type = "recipe",
	name = "crush-omnine",
	category = cat,
	subgroup = "omnine",
    enabled = false,
    ingredients = {
    {type = "item", name = "omnine", amount=1},
    },
	order = "a[angelsore1-crushed]",
    icon = "__omnimatter_crystal__/graphics/icons/omnine-shards.png",
    icon_size = 32,
	results = {{type = "item", name = "omnine-shards", amount=10}},
    energy_required = 10,
    },
	
})