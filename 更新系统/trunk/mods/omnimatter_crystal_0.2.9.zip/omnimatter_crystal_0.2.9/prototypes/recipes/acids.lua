local water = "water"
if mods["angelsrefining"] then water = "water-purified" end

data:extend({
{
    type = "recipe",
    name = "hydrolization-omnic-acid",
    icon = "__omnimatter_crystal__/graphics/icons/hydromnic-acid.png",
    icon_size = 32,
    subgroup = "crystallization",
    order = "g[hydromnic-acid]",
    category = "omniplant",
	energy_required = 1,
    enabled = false,
    ingredients =
    {
      {type = "fluid", name = "omnic-acid", amount = 50},
      {type = "fluid", name = water, amount = 200},
    },
    results =
    {
      {type = "fluid", name = "hydromnic-acid", amount = 500},
    },
  },
})
