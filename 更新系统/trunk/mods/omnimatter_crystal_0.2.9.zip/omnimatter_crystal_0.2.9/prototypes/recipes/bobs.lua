if mods["bobores"] then
	omni.crystal.add_crystal("lead-ore","Lead")
	omni.crystal.add_crystal("tin-ore","Tin")
	
	--omni.crystal.add_crystal("iron-ore","Quartz","angelsore-chunk-mix1-processing")
	omni.crystal.add_crystal("bauxite-ore","Bauxite")
	omni.crystal.add_crystal("zinc-ore","Zinc")
	omni.crystal.add_crystal("silver-ore","Silver")
	
	omni.crystal.add_crystal("rutile-ore","Rutile")
	omni.crystal.add_crystal("gold-ore","Gold")
	omni.crystal.add_crystal("cobalt-ore","Cobalt")
	omni.crystal.add_crystal("nickel-ore","Nickel")
	
	omni.crystal.add_crystal("tungsten-ore","Wolfram")
	omni.crystal.add_crystal("platinum-ore","Platinum")
	omni.crystal.add_crystal("quartz","Quartz")
end
