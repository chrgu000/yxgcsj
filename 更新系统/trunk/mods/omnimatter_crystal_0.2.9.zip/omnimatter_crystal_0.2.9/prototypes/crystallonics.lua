local crystal_cat = "crystallomnizer"
local shatter_cat = nil
if mods["angelsrefining"] then shatter_cat = "ore-sorting-t1" end

local ore_circuit = "coal"
if mods["bobores"] then ore_circuit = "lead-ore" end
local ord={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r"}

data:extend({
	{
	type = "item",
	name = "omnine-structure-crystal",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/circuit/omnine-structure-crystal.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	order="a",
	stack_size = 100
	},
	{
	type = "item",
	name = "crystal-rod",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/circuit/crystal-rod.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	order="a",
	stack_size = 100
	},
	{
	type = "item",
	name = "basic-crystallonic",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/circuit/basic-crystallonic.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 200
	},	
	{
    type = "recipe",
    name = "omnine-structure-crystal",
    energy_required = 1,
	enabled = false,
	icon_size = 32,
	category = crystal_cat,
	subgroup = "crystallonic-part",
    ingredients ={
		{type="item",name="omnine",amount=3}
	},
    results=
    {
      {type="item",name="omnine-structure-crystal",amount=2}
    },
    order = "a",
	} ,
	{
    type = "recipe",
    name = "crystal-rod",
    energy_required = 1,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category = crystal_cat,
    ingredients ={
		{type="item",name="copper-ore-crystal",amount=2}
	},
    results=
    {
      {type="item",name="crystal-rod",amount=3}
    },
    order = "b",
	},
	{
    type = "recipe",
    name = "basic-crystallonic",
    energy_required = 1,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic",
	category = crystal_cat,
    ingredients ={
		{type="item",name="omnine-structure-crystal",amount=1},
		{type="item",name="crystal-rod",amount=2}
	},
    results=
    {
      {type="item",name="basic-crystallonic",amount=1}
    },
    order = "a",
	},
	{
    type = "fluid",
    name = "pseudoliquid-amorphous-crystal",
    icon = "__omnimatter_crystal__/graphics/icons/liquid-pseudoliquid-amorphous-crystal.png",
    icon_size = 32,
	default_temperature = 25,
    heat_capacity = "0.1KJ",
    base_color = {r = 1, g = 0, b = 1},
    flow_color = {r = 1, g = 0, b = 1},
    max_temperature = 100,
	pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
},
	{
	type = "item",
	name = "shattered-omnine",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/shattered-omnine.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 600
	},	
	{
    type = "recipe",
    name = "shattered-omnine",
    energy_required = 1.5,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category = shatter_cat,
    ingredients ={
		{type="item",name="omnine",amount=2}
	},
    results=
    {
      {type="item",name="shattered-omnine",amount=3}
    },
    order = "d",
	},
	{
	type = "item",
	name = "impure-crystal-rod",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/circuit/impure-crystal-rod.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 150
	},	
	{
    type = "recipe",
    name = "impure-crystal-rod",
    energy_required = 2,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category = crystal_cat,
    ingredients ={
		{type="item",name="shattered-omnine",amount=1},
		{type="fluid",name="pseudoliquid-amorphous-crystal",amount=150},
		{type="item",name=ore_circuit,amount=2}
	},
    results=
    {
      {type="item",name="impure-crystal-rod",amount=3}
    },
    order = "e",
	},
	{
	type = "item",
	name = "fragmented-iron-crystal",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/iron-pebbles.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 400
	},	
	{
	type = "item",
	name = "fragmented-copper-crystal",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/copper-pebbles.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 400
	},	
	{
    type = "recipe",
    name = "fragment-iron-crystal",
    energy_required = 2,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category="advanced-crafting",
    ingredients ={
		{type="item",name="iron-ore-crystal",amount=1},
	},
    results=
    {
      {type="item",name="fragmented-iron-crystal",amount=3}
    },
    order = "f",
	},
	{
    type = "recipe",
    name = "fragment-copper-crystal",
    energy_required = 2,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category="advanced-crafting",
    ingredients ={
		{type="item",name="copper-ore-crystal",amount=1},
	},
    results=
    {
      {type="item",name="fragmented-copper-crystal",amount=3}
    },
    order = "g",
	},
	{
	type = "item",
	name = "omnilgium",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/omnilgium.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 400
	},	
	{
    type = "recipe",
    name = "omnilgium",
    energy_required = 3,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category=crystal_cat,
    ingredients ={
		{type="item",name="fragmented-copper-crystal",amount=2},
		{type="item",name="fragmented-iron-crystal",amount=2},
		{type="fluid",name="pseudoliquid-amorphous-crystal",amount=100},
	},
    results=
    {
      {type="item",name="omnilgium",amount=2}
    },
    order = "h",
	},
	{
	type = "item",
	name = "oscillocrystal",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/oscillocrystal.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 500
	},	
	{
    type = "recipe",
    name = "oscillocrystal",
    energy_required = 2,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category=crystal_cat,
    ingredients ={
		{type="item",name="impure-crystal-rod",amount=3},
		{type="item",name="omnilgium",amount=2},
	},
    results=
    {
      {type="item",name="oscillocrystal",amount=5}
    },
    order = "i",
	},
	{
	type = "item",
	name = "quasi-solid-omnistal",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/quasi-solid-omnistal.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 200
	},	
	{
    type = "recipe",
    name = "quasi-solid-omnistal",
    energy_required = 1,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category=crystal_cat,
    ingredients ={
		{type="item",name="shattered-omnine",amount=1},
		{type="fluid",name="pseudoliquid-amorphous-crystal",amount=20},
	},
    results=
    {
      {type="item",name="quasi-solid-omnistal",amount=5}
    },
    order = "j",
	},
	{
	type = "item",
	name = "basic-oscillo-crystallonic",
	icons = {
		{icon = "__omnimatter_crystal__/graphics/icons/circuit/basic-oscillo-crystallonic.png"}
	},
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
	subgroup = "crystallonic-part",
	stack_size = 200
	},	
	{
    type = "recipe",
    name = "basic-oscillo-crystallonic",
    energy_required = 1,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic",
	category = crystal_cat,
    ingredients ={
		{type="item",name="basic-crystallonic",amount=1},
		{type="item",name="quasi-solid-omnistal",amount=2},
		{type="item",name="oscillocrystal",amount=1}
	},
    results=
    {
      {type="item",name="basic-oscillo-crystallonic",amount=1}
    },
    order = "a",
	},
})

local reg = {}

for i=1, omni.fluid_levels do
	reg[#reg+1]=
	{
    type = "recipe",
    name = "pseudoliquid-amorphous-crystal-"..ord[i],
    energy_required = 1+i,
	enabled = false,
	icon_size = 32,
	subgroup = "crystallonic-part",
	category = crystal_cat,
    ingredients ={
		{type="item",name="omnine",amount=12}
	},
    results=
    {
      {type="fluid",name="pseudoliquid-amorphous-crystal",amount=240+2160*(i-1)/omni.fluid_levels},
    },
    order = "c",
	}
	local req={}
	if i > 1 then
		if i==2 then
			req={"crystallonics-2"}
		else
			req={"pseudoliquid-amorphous-crystal-"..i-2}
		end
		local c = omni.lib.round((omni.fluid_levels)/2)
		if i%c==0 and i>1 then
			req[#req+1]="crystallonics-"..math.floor(i/c)+2
		end
		reg[#reg+1]={ -- Omniston-1
		type = "technology",
		name = "pseudoliquid-amorphous-crystal-"..i-1,
		icon = "__omnimatter_crystal__/graphics/technology/amorphous-crystal.png",
		icon_size = 128,
		prerequisites =req,
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "pseudoliquid-amorphous-crystal-"..ord[i]
		  },
		},
		unit =
		{
		  count = 100+50*i,
		  ingredients = {
		  {"science-pack-1", 1},
		  {"science-pack-2", 1},
		  {"science-pack-3", 1},
		  },
		  time = 60
		},
		order = "c-a"
		}
	end
end

data:extend(reg)

if omni.rocket_locked then
	omni.lib.add_prerequisite("rocket-silo","pseudoliquid-amorphous-crystal-"..omni.fluid_levels-1)
end

if mods["bobores"] then
	omni.lib.replace_recipe_ingredient("crystal-rod","copper-ore-crystal","tin-ore-crystal")
end