data:extend({
{
	type = "fuel-category",
	name = "omnial"
},
{
	type = "fuel-category",
	name = "crystal"
},

})
