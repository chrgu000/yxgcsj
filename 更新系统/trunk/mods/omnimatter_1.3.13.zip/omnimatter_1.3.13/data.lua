--INITIALIZE
if not zemods then zemods = {} end
if not omnimatter then omnimatter = {} end
if not omni then omni = {} end
require("functions")
require("math-functions")

require("config")
--require("prototypes.omnitractor-dynamic")

--TRIGGER CHECKS

require("prototypes.constants")



if omni.pure_dependency > omni.pure_levels_per_tier then omni.pure_dependency = omni.pure_levels_per_tier end
if omni.impure_dependency > omni.impure_levels_per_tier then omni.impure_dependency = omni.impure_levels_per_tier end
if omni.fluid_dependency > omni.fluid_levels_per_tier then omni.fluid_dependency = omni.fluid_levels_per_tier end

--Infinite ore result probability check
--LOAD PROTOTYPES	 
require("prototypes.generation.omnite")
require("prototypes.categories")
require("prototypes.recipes.omnicium")
--require("prototypes.technology.omniological-technology-general")
--require("prototypes.technology.omniological-technology-angels")
--require("prototypes.recipes.extraction-general")
require("prototypes.recipes.extraction-basic")
require("prototypes.recipes.omnitractors")

--require("prototypes.generation.omniston")
require("prototypes.omniore") 
require("prototypes.generation.omnite-inf")
--require("prototypes.localization-override")

--Load buildings
require("prototypes.buildings.omnitractor")

