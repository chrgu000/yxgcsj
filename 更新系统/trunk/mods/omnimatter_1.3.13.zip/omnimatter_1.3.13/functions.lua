if not omni then omni = {} end

omnisource={}
tiercount={0,0,0}
omnifluid={}
uniomnitiers={}

phlog = false

function omni.add_resource(r,t,s,m)
  omnisource[#omnisource+1]={mod=m,tier = t, ore = r,techicon = s}
  tiercount[t]=tiercount[t]+1
end
function omni.add_fluid(r,t,q,s,m)
  omnifluid[#omnifluid+1]={mod=m,tier = t,ratio=q, fluid = r,techicon = s}
end

function sortTiers()
	for _,source in pairs(omnisource) do
		uniomnitiers[source.tier]={}
		uniomnitiers[source.tier][#uniomnitiers[source.tier]+1]=source.ore
	end
end

function omni.add_omniwaste()
	if not phlog then
	phlog = true
		data:extend({
	{ -- Item Burner Omnitracator
    type = "item",
    name = "burner-omniphlog",
    icon = "__omnimatter__/graphics/icons/burner-omniphlog.png",
	flags = {"goes-to-quickbar"},
    subgroup = "omnitractor",
    order = "a[burner-omnitractor]",
    place_result = "burner-omniphlog",
    icon_size = 32,
    stack_size = 10,
    },
	{ -- Entity Burner Omnitracator
    type = "assembling-machine",
    name = "burner-omniphlog",
    icon = "__omnimatter__/graphics/icons/burner-omniphlog.png",
	flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "burner-omniphlog"},
	fast_replaceable_group = "omniphlog",
    max_health = 300,
    icon_size = 32,
	corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    crafting_categories = {"omniphlog"},
    crafting_speed = 1,
	source_inventory_size = 3,
    energy_source =
    {
      type = "burner",
      effectivity = 0.25,
      fuel_inventory_size = 1,
      emissions = 0.01,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }
    },
	fluid_boxes =
    {
      {
        production_type = "input",
        pipe_picture = assembler3pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {0, -2} }}
      },
	  {
        production_type = "output",
        pipe_picture = assembler3pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = 1,
        pipe_connections = {{ type="output", position = {0, 2} }}
      },
    },
    energy_usage = "300kW",
    ingredient_count = 2,
    animation ={
	layers={
	{
        filename = "__omnimatter__/graphics/entity/buildings/omniphlog.png",
		priority = "extra-high",
        width = 160,
        height = 160,
        frame_count = 36,
		line_length = 6,
        shift = {0.00, -0.05},
		scale = 0.90,
		animation_speed = 0.5
	},
	}
	},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__omnimatter__/sound/ore-crusher.ogg", volume = 0.8 },
	  idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2,
    },
    },
  {
    type = "item-subgroup",
    name = "omniphlog",
	group = "omnimatter",
	order = "z",
  },
	{
    type = "recipe",
    name = "omnic-waste",
    icon = "__omnimatter__/graphics/icons/omnic-waste.png",
    icon_size = 32,
    subgroup = "omniphlog",
    order = "g[wood-extraction]",
    category = "omniphlog",
	energy_required = 5,
    enabled = false,
    ingredients =
    {
      {type = "item", name = "stone-crushed", amount = 1},
      {type = "item", name = "omnite", amount = 10},
    },
    results =
    {
      {type = "fluid", name = "omnic-waste", amount=100},
    },
  },
	{
    type = "recipe",
    name = "omniphlog",
    energy_required = 10,
    enabled = "false",
    icon_size = 32,
    ingredients =
    {
      {type = "item", name = "omnicium-plate", amount = 10},
      {type = "item", name = "omnicium-gear-wheel", amount = 15},
      {type = "item", name = "iron-plate", amount = 10},
      {type = "item", name = "copper-plate", amount = 5},
    },
    result = "burner-omniphlog"
  },
  {
    type = "technology",
    name = "omniwaste",
    icon = "__omnimatter__/graphics/technology/omniwaste.png",
    icon_size = 128,
    prerequisites = nil,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "omnic-waste"
      },
      {
        type = "unlock-recipe",
        recipe = "omniphlog"
      },
    },
    unit =
    {
      count = 50,
      ingredients = 
      {
        {"science-pack-1", 1},
      },
      time = 15
    },
    order = "f-a-a"
  },
  {
    type = "recipe-category",
    name = "omniphlog"
  },
  {
    type = "fluid",
    name = "omnic-waste",
    icon = "__omnimatter__/graphics/icons/omnic-waste.png",
    icon_size = 32,
	default_temperature = 25,
    heat_capacity = "0.7KJ",
    base_color = {r = 1, g = 0, b = 1},
    flow_color = {r = 1, g = 0, b = 1},
    max_temperature = 100,
	pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
  },
	})
	end
end
