--Tells how many tiers there will be, there is always 2 more than given here.
--Tier on ores cannot be higher than this.
omnimatter.omnitractortiers=3
omnimatter.fluidtiers=5