local component={}

local parts={"plate","gear","circuit","bearing",}

local quant={}
quant["gear"]=10
quant["plate"]=20
quant["circuit"]=5
quant["bearing"]=5

component["circuit"]={"electronic-circuit","advanced-circuit","processing-unit"}
component["plate"]= {"","iron-plate","steel-plate"}

if data.raw.item["basic-circuit-board"] then
	if mods["omnimatter_crystal"] then
		component["circuit"]={"basic-circuit-board","electronic-circuit","advanced-circuit","basic-crystallonic","basic-oscillo-crystallonic"}
	else
		component["circuit"]={"basic-circuit-board","electronic-circuit","advanced-circuit","processing-unit","advanced-processing-unit"}
	end
end
if mods["omnimatter_crystal"] then
	component["gear"]={"","omnicium-iron-gear-box"}
else
	component["gear"]={"","iron-gear-wheel"}
end

if bobmods and bobmods.plates then
--component["gear"][#component["gear"]+1] = ""
if not mods["omnimatter_crystal"] then
	component["gear"][#component["gear"]+1] = "steel-gear-wheel"
	component["gear"][#component["gear"]+1] = "brass-gear-wheel"
	component["gear"][#component["gear"]+1] = "titanium-gear-wheel"
	component["gear"][#component["gear"]+1] = "tungsten-gear-wheel"
	component["gear"][#component["gear"]+1] = "nitinol-gear-wheel"
else
	component["gear"][#component["gear"]+1] = "omnicium-steel-gear-box"
	component["gear"][#component["gear"]+1] = "omnicium-brass-gear-box"
	component["gear"][#component["gear"]+1] = "omnicium-titanium-gear-box"
	component["gear"][#component["gear"]+1] = "omnicium-tungsten-gear-box"
	component["gear"][#component["gear"]+1] = "omnicium-nitinol-gear-box"
	quant["gear"]={5,7,9,11,13,15,17,19}
end
--Gear Tier max 6
component["bearing"]={"",""}
component["bearing"][#component["bearing"]+1]="steel-bearing"
component["bearing"][#component["bearing"]+2]="titanium-bearing"
component["bearing"][#component["bearing"]+1]="ceramic-bearing"
component["bearing"][#component["bearing"]+1]="nitinol-bearing"
--Bearing Tier max 4

component["plate"][#component["plate"]+1]="aluminium-plate"
component["plate"][#component["plate"]+1]="tungsten-plate"
--Plate tier 4
--[[
alloytier[#alloytier+1]="brass-alloy"
alloytier[#alloytier+1]="invar-alloy"
alloytier[#alloytier+1]="electrum-alloy"
alloytier[#alloytier+1]="nitinol-alloy"
alloytier[#alloytier+1]="cobalt-steel-alloy"]]
end
local omnitractor_recipes = {}
local omnitractor_item = {}
local omnitractor_technology = {}
local omnitractor_entities = {}

local timestier = {1,1.5,2.2,3.5,5}
--"electronic-circuit"
local get_icons = function(tier)
    --Build the icons table
    local icons = {{icon = "__omnimatter__/graphics/icons/electric-omnitractor.png"},{icon = "__omnimatter__/graphics/icons/extraction-"..tier..".png"}}
    return icons
end

local get_pure_req = function(i)
	local r = {}
	--omni.pure_dependency
	--omni.pure_levels_per_tier
	for _,item in pairs(omnisource) do
		if item.tier < i and item.tier >= i-3 then
			r[#r+1]="omni-sorting-"..item.ore.name.."-"..omni.pure_levels_per_tier*(i-item.tier-1)+omni.pure_dependency
			--omni.impure_dependency
		end
		if item.tier == i then
			r[#r+1]="omni-impure-"..item.ore.name.."-extraction-"..omni.impure_dependency
		end
	end
	if i>1 and i*omni.fluid_levels_per_tier < omni.fluid_levels then
		r[#r+1]="omniston-solvation-"..(i-2)*omni.fluid_levels_per_tier+omni.fluid_dependency
		r[#r+1]="omnic-hydrolyzation-"..(i-2)*omni.fluid_levels_per_tier+omni.fluid_dependency
		r[#r+1]="stone-omnisolvent-"..(i-2)*omni.fluid_levels_per_tier+omni.fluid_dependency
	end
	for _,item in pairs(omnifluid) do
		if item.tier < i and item.tier >= i-3 then
			if omni.fluid_levels_per_tier*(i-item.tier-1)+omni.fluid_dependency <= omni.fluid_levels then
				r[#r+1]="distillation-"..item.fluid.name.."-"..omni.fluid_levels_per_tier*(i-item.tier-1)+omni.fluid_dependency
			elseif omni.fluid_levels_per_tier*(i-item.tier-1)+omni.fluid_dependency > omni.fluid_levels then
				r[#r+1]="distillation-"..item.fluid.name.."-"..omni.fluid_levels
			end
		end
	end
	return r
end

local get_tech_times = function(tier)
	local t = 50*timestier[tier]
	return t
end

local techcost = function(lvl,tier)
	local c = {}
	local size = tier+((lvl-1)-(lvl-1)%omni.pure_levels_per_tier)/omni.pure_levels_per_tier
	local length = math.min(size,#omni.sciencepacks)
	for l=1,length do
		local q = 0
		if omni.linear_science then
			q = 1+omni.science_constant*(size-l)
		else
			q=round(math.pow(omni.science_constant,size-l))
		end
		c[#c+1] = {omni.sciencepacks[l],q}
	end
	return c
end

local get_tech_cost = function(tier)
	local c = {}
	for l=1,tier do
		local q = 0
		if omni.linear_science then
			q = 1+omni.science_constant*(tier-l)
		else
			q=round(math.pow(omni.science_constant,tier-l))
		end
		c[#c+1] = {omni.sciencepacks[l],q}
	end
	return c
end

local get_tractor_cost = function(tier)
	local ing = {}
	ing[#ing+1]={type="item",name="omnicium-plate",amount=10+8*tier}
	if tier == 1 then
		ing[#ing+1]={type="item",name="omnicium-gear-wheel",amount=7+3*tier}
	end
	for _,part in pairs(parts) do
		local amount = quant[part]
		if type(quant[part])=="table" then amount=quant[part][tier] end
		for i=tier,1,-1 do
			if component[part] and component[part][i]~="" and component[part][i]~=nil then
				ing[#ing+1]={type="item",name=component[part][i],amount=amount}
				break
			else
				amount = 2*amount
			end
		end
	end
	if tier > 1 then
		ing[#ing+1]={type="item",name="omnitractor-"..tier-1,amount=1}
	else
		ing[#ing+1]={type="item",name="burner-omnitractor-1",amount=1}
	end
	return ing
end


for i=1,omni.max_tier do


	local ic = get_icons(i)

	local req = get_pure_req(i)
	local times = get_tech_times(i)
	local cost = get_tech_cost(i)
	local ingr = get_tractor_cost(i)
	local loc_key = {i}
	
	local omnitractorrecipe = {
	type = "recipe",
	name = "omnitractor-"..i,
    icon_size = 32,
    localised_name = {"recipe-name.omnitractor", loc_key},
    localised_description = {"recipe-description.compress-item", loc_key},
	subgroup = "omnitractor",
    enabled = false,
    ingredients = ingr,
       --subgroup = "compressor-"..sub_group,
	order = "a[angelsore1-crushed]",
	icons = ic,
       --inter_item_count = item_count,
	results = {
	{type = "item", name = "omnitractor-"..i, amount=1},
	},
    energy_required = 5,
    }
	omnitractor_recipes[#omnitractor_recipes+1]=omnitractorrecipe
	
	local omnitractortech = {
    type = "technology",
    name = "omni-sorting-electric-"..i,
    localised_name = {"technology-name.omnitractor-electric", loc_key},
    icon = "__omnimatter__/graphics/technology/electric-omnitraction.png",
	icon_size = 128,
	prerequisites =req,
    effects =
    {
	  {
        type = "unlock-recipe"	,
        recipe = "omnitractor-"..i
      },
    },
	
    unit =
    {
      count = times,
      ingredients = cost,
      time = 15*i
    },
    order = "c-a"
    }
	
	omnitractor_technology[#omnitractor_technology+1]=omnitractortech
	
	--Item
	local omnitractoritem={
    type = "item",
    name = "omnitractor-"..i,
    icon_size = 32,
    localised_name = {"item-name.omnitractor-electric", loc_key},
    icons = ic,
	flags = {"goes-to-quickbar"},
    subgroup = "omnitractor",
    order = "a[burner-ore-crusher]",
    place_result = "omnitractor-"..i,
    stack_size = 10,
    }
	omnitractor_item[#omnitractor_item+1]=omnitractoritem
	--entity
	local omnitractorentity = { -- Entity Electric Omnitracator 1
	
    type = "assembling-machine",
    name = "omnitractor-"..i,
    icon_size = 32,
    localised_name = {"entity-name.omnitractor-electric", loc_key},
    icons = ic,
	flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "omnitractor-"..i},
	fast_replaceable_group = "omnitractor",
    max_health = 300,
	corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
	module_specification =
    {
      module_slots = i
    },
    allowed_effects = {"consumption", "speed", "pollution", "productivity"},
    crafting_categories = {"omnite-extraction-both","omnite-extraction"},
    crafting_speed = i,
	source_inventory_size = 1,
    energy_source =
    {
	  type = "electric",
	  usage_priority = "secondary-input",
	  emissions = 0.04 / 3.5
	},
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      },
    energy_usage = (100+25*i).."kW",
    ingredient_count = 2,
    animation ={
	layers={
	{
        filename = "__omnimatter__/graphics/entity/buildings/tractor.png",
		priority = "extra-high",
        width = 160,
        height = 160,
        frame_count = 36,
		line_length = 6,
        shift = {0.00, -0.05},
		scale = 0.90,
		animation_speed = 0.5
	},
	{
        filename = "__omnimatter__/graphics/entity/buildings/tractor-over.png",
		priority = "extra-high",
        width = 160,
        height = 160,
        frame_count = 36,
		line_length = 6,
        shift = {0.00, -0.05},
		tint=omni.tint_level[i+1],
		scale = 0.90,
		animation_speed = 0.5
	},
	},
	},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__omnimatter__/sound/ore-crusher.ogg", volume = 0.8 },
	  idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2,
    },
    }
	omnitractor_entities[#omnitractor_entities+1]=omnitractorentity
end
data:extend(omnitractor_technology)
data:extend(omnitractor_entities)
data:extend(omnitractor_item)
data:extend(omnitractor_recipes)