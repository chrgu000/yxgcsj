	data:extend(
{
	--Omniston
	{ -- Omniston-1
    type = "technology",
    name = "omniston-production-1",
    icon = "__omnimatter__/graphics/technology/omniston-tech.png",
	icon_size = 128,
	prerequisites =
    {
		"omni-sorting-electric-2",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "omniston-processing-2"
      },
    },
    unit =
    {
      count = 100,
      ingredients = {
	  {"science-pack-1", 2},
	  {"science-pack-2", 1},
	  },
      time = 40
    },
    order = "c-a"
    },
	{ -- Omniston-2
    type = "technology",
    name = "omniston-production-2",
    icon = "__omnimatter__/graphics/technology/omniston-tech.png",
	icon_size = 128,
	prerequisites =
    {
		"omniston-production-1",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "omniston-processing-3"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 2},
	  {"science-pack-2", 1},
	  },
      time = 40
    },
    order = "c-a"
    },
	{ -- Omniston-3
    type = "technology",
    name = "omniston-production-3",
    icon = "__omnimatter__/graphics/technology/omniston-tech.png",
	icon_size = 128,
	prerequisites =
    {
		"omniston-production-2",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "omniston-processing-4"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 4},
	  {"science-pack-2", 2},
	  {"science-pack-3", 1},
	  },
      time = 40
    },
    order = "c-a"
    },
	{ -- Omniston-4
    type = "technology",
    name = "omniston-production-4",
    icon = "__omnimatter__/graphics/technology/omniston-tech.png",
	icon_size = 128,
	prerequisites =
    {
		"omniston-production-3",
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "omniston-processing-5"
      },
    },
    unit =
    {
      count = 400,
      ingredients = {
	  {"science-pack-1", 6},
	  {"science-pack-2", 3},
	  {"science-pack-3", 2},
	  {"science-pack-4", 1},
	  },
      time = 40
    },
    order = "c-a"
    },
	
}
)