data:extend(
{
--Omniburner
    { -- Item Burner Omnitracator
    type = "item",
    name = "burner-omnitractor-1",
    icon = "__omnimatter__/graphics/icons/burner-omnitractor.png",
	flags = {"goes-to-quickbar"},
    subgroup = "omnitractor",
    order = "a[burner-omnitractor]",
    place_result = "burner-omnitractor-1",
    icon_size = 32,
    stack_size = 10,
    },
	{ -- Entity Burner Omnitracator
    type = "assembling-machine",
    name = "burner-omnitractor-1",
    icon = "__omnimatter__/graphics/icons/burner-omnitractor.png",
	flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "burner-omnitractor-1"},
	fast_replaceable_group = "omnitractor",
    max_health = 300,
    icon_size = 32,
	corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    crafting_categories = {"omnite-extraction-burner","omnite-extraction-both"},
    crafting_speed = 1,
	source_inventory_size = 1,
    energy_source =
    {
      type = "burner",
      effectivity = 0.5,
      fuel_inventory_size = 1,
      emissions = 0.01,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }
    },
    energy_usage = "100kW",
    ingredient_count = 2,
    animation ={
	layers={
	{
        filename = "__omnimatter__/graphics/entity/buildings/tractor.png",
		priority = "extra-high",
        width = 160,
        height = 160,
        frame_count = 36,
		line_length = 6,
        shift = {0.00, -0.05},
		scale = 0.90,
		animation_speed = 0.5
	},
	{
        filename = "__omnimatter__/graphics/entity/buildings/black-over.png",
		priority = "extra-high",
        width = 160,
        height = 160,
        frame_count = 36,
		line_length = 6,
        shift = {0.00, -0.05},
		scale = 0.90,
		animation_speed = 0.5
	},
	}
	},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__omnimatter__/sound/ore-crusher.ogg", volume = 0.8 },
	  idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2,
    },
    },
--Ore-Crusher
}
  )