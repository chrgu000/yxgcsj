	if bobmods.plates then
	    --data.raw["resource"]["omnite"].localised_description={"entity-description.angels-ore1-bob", {}}
		
	    --data.raw["item"]["omnite"].localised_description={"entity-description.angels-ore1-bob", {}}
	end