data:extend(
{
--ORE CRUSHER
	{
    type = "recipe",
    name = "burner-omnitractor-1",
    energy_required = 15,
	enabled = "true",
    ingredients ={
	{"omnicium-gear-wheel", 2},
	{"omnicium-plate", 4},
	{"iron-plate", 3},
	},
    result= "burner-omnitractor-1",
    subgroup = "omnitractor",
	order = "z"
    },
  }
  )