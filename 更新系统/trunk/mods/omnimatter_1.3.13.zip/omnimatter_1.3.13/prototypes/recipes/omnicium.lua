local res = {}

res[#res+1]= {
	type = "item",
	name = "omnicium-plate",
	icon = "__omnimatter__/graphics/icons/plate-omnicium.png",
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "d[solar-panel]-aa[solar-panel-1-a]",
	stack_size = 400,
  }
  
res[#res+1]= {
    type = "recipe",
    name = "crushing-omnite-by-hand",
	category = "crafting",
	subgroup = "omni-basic",
    energy_required = 0.25,
	enabled = "true",
    ingredients ={{"omnite", 4}},
    results=
    {
      {type="item", name="crushed-omnite", amount=2},
      {type="item", name="stone-crushed", amount=1}
    },
    icon = "__omnimatter__/graphics/icons/crushed-omnite.png",
	icon_size = 32,
    order = "a[angelsore1-crushed-hand]",
	}
res[#res+1]= {
	type = "item",
	name = "omnicium-gear-wheel",
	icon = "__omnimatter__/graphics/icons/omnicium-gear-wheel.png",
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[solar-panel]-aa[solar-panel-1-a]",
	stack_size = 100,
  }
res[#res+1]= {
	type = "item",
	name = "omnicium-iron-gear-box",
	icon = "__omnimatter__/graphics/icons/omnicium-iron-gear-box.png",
	icon_size = 32,
	flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "d[solar-panel]-aa[solar-panel-1-a]",
	stack_size = 100,
  }
res[#res+1]= {
    type = "recipe",
    name = "omnicium-iron-gear-box",
	category = "crafting",
	subgroup = "omni-basic",
    energy_required = 0.25,
	enabled = "true",
    ingredients ={{"omnicium-gear-wheel", 1},{"iron-gear-wheel", 1}},
    results=
    {
      {type="item", name="omnicium-iron-gear-box", amount=1},
    },
	icon_size = 32,
    order = "a[angelsore1-crushed-hand]",
	}
res[#res+1]={
    type = "recipe",
    name = "omnicium-plate-mix",
    category = "omnifurnace",
	icons={
		{ 
			icon = "__omnimatter__/graphics/icons/plate-omnicium.png"
		},
		{
			icon = data.raw.item["copper-ore"].icon,
			scale = 0.4375,
			shift = { -10, -10},
		},
		{
			icon = data.raw.item["iron-ore"].icon,
			scale = 0.4375,
			shift = { 10, -10},
		},
	},
	icon_size = 32,
    energy_required = 5,
	enabled = true,
    ingredients = {
		{type="item", name="copper-ore",amount=1},
		{type="item", name="iron-ore",amount=1},
		{type="item", name="omnite",amount=4},
	},
    results = {{type="item", name="omnicium-plate",amount=2}}
  }
  
res[#res+1]={
    type = "recipe",
    name = "omnicium-gear-wheel",
    normal =
    {
      ingredients = {{"omnicium-plate", 3}},
      results = {{"omnicium-gear-wheel",2}},
    },
    expensive =
    {
      ingredients = {{"omnicium-plate", 2}},
      result = "omnicium-gear-wheel"
    }
  }
res[#res+1]={
    type = "recipe",
    name = "omnicium-plate-pure",
    category = "smelting",
    energy_required = 5,
	enabled = true,
	--hidden=true,
    ingredients = {{ "crushed-omnite", 40}},
    result = "omnicium-plate"
  }
  
res[#res+1]={
    type = "recipe-category",
    name = "omnifurnace",
  }
res[#res+1]={
    type = "recipe",
    name = "omni-furnace",
    energy_required = 5,
	enabled = true,
    ingredients = {{ "omnicium-plate", 10},{ "stone-brick", 5},{ "stone-furnace", 1}},
    result = "omni-furnace"
  }
res[#res+1]= {
	type = "item",
	name = "omni-furnace",
	icon = "__omnimatter__/graphics/icons/omni-furnace.png",
	icon_size = 32,
	flags = {"goes-to-quickbar"},
	subgroup = "energy",
    order = "d[solar-panel]-aa[solar-panel-1-a]",
    place_result = "omni-furnace",
	stack_size = 20,
  }
res[#res+1]={
    type = "assembling-machine",
    name = "omni-furnace",
    icon = "__omnimatter__/graphics/icons/omni-furnace.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "omni-furnace"},
    max_health = 200,
    corpse = "medium-remnants",
    repair_sound = { filename = "__base__/sound/manual-repair-simple.ogg" },
    mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
    working_sound =
    {
      sound = { filename = "__base__/sound/furnace.ogg", }
    },
    resistances =
    {
      {
        type = "fire",
        percent = 90
      },
      {
        type = "explosion",
        percent = 30
      },
      {
        type = "impact",
        percent = 30
      }
    },
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-0.8, -1}, {0.8, 1}},
    crafting_categories = {"smelting","omnifurnace"},
    energy_usage = "180kW",
    crafting_speed = 1.5,
	ingredient_count = 5,
    energy_source =
    {
      type = "burner",
      fuel_category = "chemical",
      effectivity = 1,
      fuel_inventory_size = 1,
      emissions = 0.01,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {0.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }
    },
    animation =
    {
      layers = {
        {
          filename = "__omnimatter__/graphics/entity/buildings/omni-furnace.png",
          priority = "high",
          width = 85,
          height = 87,
          frame_count = 1,
          shift = util.by_pixel(-1.5, 1.5),
          hr_version = {
            filename = "__omnimatter__/graphics/entity/buildings/hr-omni-furnace.png",
            priority = "high",
            width = 171,
            height = 174,
            frame_count = 1,
            shift = util.by_pixel(-1.25, 2),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/steel-furnace/steel-furnace-shadow.png",
          priority = "high",
          width = 139,
          height = 43,
          frame_count = 1,
          draw_as_shadow = true,
          shift = util.by_pixel(39.5, 11.5),
          hr_version = {
            filename = "__base__/graphics/entity/steel-furnace/hr-steel-furnace-shadow.png",
            priority = "high",
            width = 277,
            height = 85,
            frame_count = 1,
            draw_as_shadow = true,
            shift = util.by_pixel(39.25, 11.25),
            scale = 0.5
          }
        },
      },
    },
    working_visualisations =
    {
      {
        north_position = {0.0, 0.0},
        east_position = {0.0, 0.0},
        south_position = {0.0, 0.0},
        west_position = {0.0, 0.0},
        animation =
        {
          filename = "__base__/graphics/entity/steel-furnace/steel-furnace-fire.png",
          priority = "high",
          line_length = 8,
          width = 29,
          height = 40,
          frame_count = 48,
          axially_symmetrical = false,
          direction_count = 1,
          shift = util.by_pixel(-0.5, 6),
          hr_version = {
            filename = "__base__/graphics/entity/steel-furnace/hr-steel-furnace-fire.png",
            priority = "high",
            line_length = 8,
            width = 57,
            height = 81,
            frame_count = 48,
            axially_symmetrical = false,
            direction_count = 1,
            shift = util.by_pixel(-0.75, 5.75),
            scale = 0.5
          }
        },
        light = {intensity = 1, size = 1, color = {r = 1.0, g = 1.0, b = 1.0}}
      },
      {
        north_position = {0.0, 0.0},
        east_position = {0.0, 0.0},
        south_position = {0.0, 0.0},
        west_position = {0.0, 0.0},
        effect = "flicker", -- changes alpha based on energy source light intensity
        animation =
        {
          filename = "__base__/graphics/entity/steel-furnace/steel-furnace-glow.png",
          priority = "high",
          width = 60,
          height = 43,
          frame_count = 1,
          shift = {0.03125, 0.640625},
          blend_mode = "additive"
        }
      },
      {
        north_position = {0.0, 0.0},
        east_position = {0.0, 0.0},
        south_position = {0.0, 0.0},
        west_position = {0.0, 0.0},
        effect = "flicker", -- changes alpha based on energy source light intensity
        animation =
        {
          filename = "__base__/graphics/entity/steel-furnace/steel-furnace-working.png",
          priority = "high",
          line_length = 8,
          width = 64,
          height = 75,
          frame_count = 1,
          axially_symmetrical = false,
          direction_count = 1,
          shift = util.by_pixel(0, -4.5),
          blend_mode = "additive",
          hr_version = {
            filename = "__base__/graphics/entity/steel-furnace/hr-steel-furnace-working.png",
            priority = "high",
            line_length = 8,
            width = 130,
            height = 149,
            frame_count = 1,
            axially_symmetrical = false,
            direction_count = 1,
            shift = util.by_pixel(0, -4.25),
            blend_mode = "additive",
            scale = 0.5
          }
        }
      },
    },
    fast_replaceable_group = "furnace"
  }
--data.raw.furnace["stone-furnace"].source_inventory_size=2
--data.raw.furnace["steel-furnace"].source_inventory_size=2

if mods["bobplates"] then
	local plates = {"steel","brass","titanium","tungsten","nitinol"}
	for _,p in pairs(plates) do
		res[#res+1]= {
			type = "item",
			name = "omnicium-"..p.."-gear-box",
			icon = "__omnimatter__/graphics/icons/omnicium-"..p.."-gear-box.png",
			icon_size = 32,
			flags = {"goes-to-main-inventory"},
			subgroup = "intermediate-product",
			order = "d[solar-panel]-aa[solar-panel-1-a]",
			stack_size = 100,
		  }
		res[#res+1]= {
			type = "recipe",
			name = "omnicium-"..p.."-gear-box",
			category = "crafting",
			energy_required = 1.25,
			enabled = false,
			ingredients ={{"omnicium-gear-wheel", 1},{p.."-gear-wheel", 1}},
			results=
			{
			  {type="item", name="omnicium-"..p.."-gear-box", amount=1},
			},
			icon_size = 32,
			order = "a[angelsore1-crushed-hand]",
			}
	end
	omni.lib.add_unlock_recipe("steel-processing","omnicium-steel-gear-box")
	omni.lib.add_unlock_recipe("zinc-processing","omnicium-brass-gear-box")
	omni.lib.add_unlock_recipe("titanium-processing","omnicium-titanium-gear-box")
	omni.lib.add_unlock_recipe("tungsten-processing","omnicium-tungsten-gear-box")
	omni.lib.add_unlock_recipe("nitinol-processing","omnicium-nitinol-gear-box")
	data.raw.item["brass-gear-wheel"].icon="__omnimatter__/graphics/icons/brass-gear-wheel.png"
	data.raw.item["steel-gear-wheel"].icon="__omnimatter__/graphics/icons/steel-gear-wheel.png"
end

data.raw.item["iron-gear-wheel"].icon="__omnimatter__/graphics/icons/iron-gear-wheel.png"

data:extend(res)
if mods["angelssmelting"] then
	data:extend({
  {
    type = "item-subgroup",
    name = "omnicium-casting",
    group = "angels-casting",
    order = "u",
  },
  {
    type = "item-subgroup",
    name = "angels-omnicium",
    group = "angels-smelting",
    order = "r",
  },
  })
  data.raw.item["omnicium-plate"].subgroup = "omnicium-casting"
  
  local smelt = {}
  smelt[#smelt+1] = table.deepcopy(data.raw.item["ingot-iron"])
  smelt[#smelt].name="ingot-omnicium"
  smelt[#smelt].icon="__omnimatter__/graphics/icons/ingot-omnicium.png"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["iron-ore-smelting"])
  smelt[#smelt].name="omnite-smelting"
  smelt[#smelt].ingredients[1].name="copper-ore"
  smelt[#smelt].ingredients[2]={type="item", name="iron-ore", amount=24}
  smelt[#smelt].ingredients[3]={type="item", name="omnite", amount=48}
  smelt[#smelt].results[1].name = "ingot-omnicium"
  smelt[#smelt].subgroup="angels-omnicium"
  smelt[#smelt].icon=nil
  smelt[#smelt].icons = {
		{ 
			icon = "__omnimatter__/graphics/icons/ingot-omnicium.png",
		},
		{
			icon = data.raw.item["copper-ore"].icon,
			scale = 0.4375,
			shift = { -10, -10},
		},
		{
			icon = data.raw.item["iron-ore"].icon,
			scale = 0.4375,
			shift = { 10, -10},
		},
	}
  
  smelt[#smelt+1] = table.deepcopy(data.raw.fluid["liquid-molten-iron"])
  smelt[#smelt].name="liquid-molten-omnicium"
  smelt[#smelt].icon="__omnimatter__/graphics/icons/molten-omnicium.png"
  smelt[#smelt].base_color = {r = 125/255, g = 0/255, b = 161/255}
  smelt[#smelt].flow_color = {r = 125/255, g = 0/255, b = 161/255}
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["molten-iron-smelting-1"])
  smelt[#smelt].name="molten-omnicium-smelting-1"
  smelt[#smelt].ingredients[1].name="ingot-omnicium"
  smelt[#smelt].subgroup = "omnicium-casting"
  smelt[#smelt].results[1].name = "liquid-molten-omnicium"
  smelt[#smelt].icons[1].icon="__omnimatter__/graphics/icons/molten-omnicium.png"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["angels-plate-iron"])
  smelt[#smelt].name="angels-plate-omnicium"
  smelt[#smelt].subgroup="omnicium-casting"
  smelt[#smelt].normal.ingredients[1].name="liquid-molten-omnicium"
  smelt[#smelt].normal.results[1].name="omnicium-plate"
  smelt[#smelt].expensive.ingredients[1].name="liquid-molten-omnicium"
  smelt[#smelt].expensive.results[1].name="omnicium-plate"
  smelt[#smelt].icons[1].icon="__omnimatter__/graphics/icons/plate-omnicium.png"
  smelt[#smelt].icons[2].icon="__omnimatter__/graphics/icons/molten-omnicium.png"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.technology["angels-iron-smelting-1"])
  smelt[#smelt].name="angels-omnicium-smelting-1"
  smelt[#smelt].icon = "__omnimatter__/graphics/technology/smelting-omnicium.png"
  
  
  smelt[#smelt+1]=table.deepcopy(data.raw.item["processed-iron"])
  smelt[#smelt].name="processed-omnicium"
  smelt[#smelt].icon="__omnimatter__/graphics/icons/processed-omnicium.png"
  smelt[#smelt].subgroup="omnicium-casting"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["iron-ore-processing"])
  smelt[#smelt].name = "omnicium-processing"
  smelt[#smelt].subgroup="angels-omnicium"
  smelt[#smelt].ingredients[2]={"copper-ore",4}
  smelt[#smelt].ingredients[3]={"omnite",8}
  smelt[#smelt].results[1].name="processed-omnicium"
  smelt[#smelt].results[1].amount=4
  smelt[#smelt].icon=nil
  smelt[#smelt].icons={
		{ 
			icon = "__omnimatter__/graphics/icons/processed-omnicium.png",
		},
	}
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["processed-iron-smelting"])
  smelt[#smelt].name = "processed-omnicium-smelting"
  smelt[#smelt].subgroup="angels-omnicium"
  smelt[#smelt].ingredients[1].name="processed-omnicium"
  smelt[#smelt].results[1].name="ingot-omnicium"
  smelt[#smelt].icon=nil
  smelt[#smelt].icons={
		{ 
			icon = "__omnimatter__/graphics/icons/ingot-omnicium.png",
		},
		{
			icon = "__omnimatter__/graphics/icons/processed-omnicium.png",
			scale = 0.4375,
			shift = { -10, -10},
		},
	}
  
  smelt[#smelt+1] = table.deepcopy(data.raw.technology["angels-iron-smelting-2"])
  smelt[#smelt].name="angels-omnicium-smelting-2"
  smelt[#smelt].icon = "__omnimatter__/graphics/technology/smelting-omnicium.png"
  
  
  smelt[#smelt+1] = table.deepcopy(data.raw.technology["angels-iron-smelting-3"])
  smelt[#smelt].name="angels-omnicium-smelting-3"
  smelt[#smelt].icon = "__omnimatter__/graphics/technology/smelting-omnicium.png"
  
  smelt[#smelt+1]=table.deepcopy(data.raw.item["pellet-iron"])
  smelt[#smelt].name="pellet-omnicium"
  smelt[#smelt].icon="__omnimatter__/graphics/icons/pellet-omnicium.png"
  smelt[#smelt].subgroup="omnicium-casting"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["iron-processed-processing"])
  smelt[#smelt].name="omnicium-processed-processing"
  smelt[#smelt].ingredients[1][1]="processed-omnicium"
  smelt[#smelt].subgroup = "omnicium-casting"
  smelt[#smelt].results[1].name = "pellet-omnicium"
  smelt[#smelt].icon="__omnimatter__/graphics/icons/pellet-omnicium.png"
  
  smelt[#smelt+1] = table.deepcopy(data.raw.recipe["pellet-iron-smelting"])
  smelt[#smelt].name = "pellet-omnicium-smelting"
  smelt[#smelt].subgroup="angels-omnicium"
  smelt[#smelt].ingredients[1].name="pellet-omnicium"
  smelt[#smelt].ingredients[2].name="solid-coke"
  smelt[#smelt].ingredients[3]={type="fluid", name="omnic-acid", amount = 60}
  smelt[#smelt].results[1].name="ingot-omnicium"
  smelt[#smelt].icon=nil
  smelt[#smelt].icons={
		{ 
			icon = "__omnimatter__/graphics/icons/ingot-omnicium.png",
		},
		{
			icon = "__omnimatter__/graphics/icons/processed-omnicium.png",
			scale = 0.4375,
			shift = { -10, -10},
		},
	}
	
  
  data:extend(smelt)
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-1","iron-ore-smelting","omnite-smelting")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-1","molten-iron-smelting-1","molten-omnicium-smelting-1")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-1","angels-plate-iron","angels-plate-omnicium")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-1","ingot-iron-smelting")
  
  omni.lib.replace_prerequisite("angels-omnicium-smelting-2","angels-iron-smelting-1","angels-omnicium-smelting-1")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-2","iron-ore-processing","omnicium-processing")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-2","molten-iron-smelting-2","processed-omnicium-smelting")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","processed-iron-smelting")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","omnicium-copper-processing")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","molten-iron-smelting-3")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","powder-iron")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","roll-iron-casting")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-2","angels-roll-iron-converting")
  
  omni.lib.replace_prerequisite("angels-omnicium-smelting-3","angels-iron-smelting-2","angels-omnicium-smelting-2")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-3","iron-processed-processing","omnicium-processed-processing")
  omni.lib.replace_unlock_recipe("angels-omnicium-smelting-3","pellet-iron-smelting","pellet-omnicium-smelting")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-3","molten-iron-smelting-4")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-3","molten-iron-smelting-5")
  omni.lib.remove_unlock_recipe("angels-omnicium-smelting-3","roll-iron-casting-fast")
  omni.lib.remove_prerequisite("angels-omnicium-smelting-3","angels-coolant-1")
  omni.lib.remove_prerequisite("angels-omnicium-smelting-3","water-washing-2")
  
  if mods["omnimatter_crystal"] then
	omni.lib.replace_recipe_ingredient("pellet-omnicium-smelting","solid-coke","omnine")
  end
  
end
if mods["only-smelting"] then
	omni.lib.replace_recipe_ingredient("omnicium-plate-mix","iron-ore",{"angels-ore1-crushed",4})
	omni.lib.replace_recipe_ingredient("omnicium-plate-mix","copper-ore",{"angels-ore3-crushed",4})
	data.raw.recipe["omnicium-plate-mix"].icons[2].icon=data.raw.item["angels-ore1-crushed"].icon
	data.raw.recipe["omnicium-plate-mix"].icons[3].icon=data.raw.item["angels-ore3-crushed"].icon
else
	data.raw.recipe["iron-plate"].hidden = false
	data.raw.recipe["copper-plate"].hidden = false
end
