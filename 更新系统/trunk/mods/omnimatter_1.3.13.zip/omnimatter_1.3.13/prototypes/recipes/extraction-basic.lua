local res = {}
if angelsmods and angelsmods.refining then
	res[#res+1] = {
    type = "recipe",
    name = "crushing-omnite",
    category = "ore-sorting-t1",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "false",
    ingredients ={{"omnite", 5}},
    results=
    {
      {type="item", name="crushed-omnite", amount=10},
      --{type="item", name="stone-crushed", amount=1}
    },
    icon = "__omnimatter__/graphics/icons/crushed-omnite.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1] = {
    type = "recipe",
    name = "pulverize-omnite",
    category = "ore-sorting-t1",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "false",
	icon_size = 32,
    ingredients ={{"crushed-omnite", 10}},
    results=
    {
      {type="item", name="pulverized-omnite", amount=15},
      --{type="item", name="stone-crushed", amount=1}
    },
    icon = "__omnimatter__/graphics/icons/pulverized-omnite.png",
    order = "a[angelsore1-crushed]",
	}
	--"__omnimatter__/graphics/icons/stone-crushed.png"
	res[#res+1]=
	{
    type = "recipe",
    name = "crush-stone",
    category = "ore-sorting-t1",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "true",
    ingredients ={{"stone", 5}},
    results=
    {
      {type="item", name="stone-crushed", amount=10}
    },
    icon = "__omnimatter__/graphics/icons/stone-crushed.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1]=
	{
    type = "recipe",
    name = "pulverize-stone",
    category = "ore-sorting-t1",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "true",
	icon_size = 32,
    ingredients ={{"stone-crushed", 15}},
    results=
    {
      {type="item", name="pulverized-stone", amount=15}
    },
    icon = "__omnimatter__/graphics/icons/pulverized-stone.png",
    order = "a[angelsore1-crushed]",
	}
else
	res[#res+1] = {
    type = "recipe",
    name = "crushing-omnite",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "false",
    ingredients ={{"omnite", 5}},
    results=
    {
      {type="item", name="crushed-omnite", amount=10},
      --{type="item", name="stone-crushed", amount=1}
    },
    icon = "__omnimatter__/graphics/icons/crushed-omnite.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1]=
	{
    type = "recipe",
    name = "crush-stone",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "true",
    ingredients ={{"stone", 5}},
    results=
    {
      {type="item", name="stone-crushed", amount=10}
    },
    icon = "__omnimatter__/graphics/icons/stone-crushed.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1] = {
    type = "recipe",
    name = "pulverize-omnite",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "false",
    ingredients ={{"crushed-omnite", 10}},
    results=
    {
      {type="item", name="pulverized-omnite", amount=15},
      --{type="item", name="stone-crushed", amount=1}
    },
    icon = "__omnimatter__/graphics/icons/pulverized-omnite.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1]=
	{
    type = "recipe",
    name = "pulverize-stone",
	subgroup = "omni-basic",
    energy_required = 0.5,
	enabled = "true",
    ingredients ={{"stone-crushed", 15}},
    results=
    {
      {type="item", name="pulverized-stone", amount=15}
    },
    icon = "__omnimatter__/graphics/icons/pulverized-stone.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
end
if not mods["only-smelting"] then
	res[#res+1]={
    type = "recipe",
    name = "omni-iron-general-1",
    category = "omnite-extraction-burner",
	subgroup = "omni-basic",
    energy_required = 5,
	enabled = "true",
    ingredients ={{"omnite", 5}},
    results=
    {
      {type="item", name="iron-ore", amount=1},
      {type="item", name="stone-crushed", amount=4}
    },
    icon = "__base__/graphics/icons/iron-ore.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1]={
    type = "recipe",
    name = "omni-copper-general-1",
    category = "omnite-extraction-burner",
	subgroup = "omni-basic",
    energy_required = 5,
	enabled = "true",
    ingredients ={{"omnite", 5}},
    results=
    {
      {type="item", name="copper-ore", amount=1},
      {type="item", name="stone-crushed", amount=4}
    },
    icon = "__base__/graphics/icons/copper-ore.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
else
	res[#res+1]={
    type = "recipe",
    name = "omni-saphirite-general-1",
    category = "omnite-extraction-burner",
	subgroup = "omni-basic",
    energy_required = 5,
	enabled = "true",
    ingredients ={{"omnite", 7}},
    results=
    {
      {type="item", name="angels-ore1", amount=1},
      {type="item", name="stone-crushed", amount=6}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore1.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
	res[#res+1]={
    type = "recipe",
    name = "omni-stiratite-general-1",
    category = "omnite-extraction-burner",
	subgroup = "omni-basic",
    energy_required = 5,
	enabled = "true",
    ingredients ={{"omnite", 7}},
    results=
    {
      {type="item", name="angels-ore3", amount=1},
      {type="item", name="stone-crushed", amount=6}
    },
    icon = "__angelsrefining__/graphics/icons/angels-ore3.png",
    icon_size = 32,
    order = "a[angelsore1-crushed]",
	}
end
data:extend(res)