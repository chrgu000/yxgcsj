sortTiers()
log("test1")
require("prototypes.omnitractor-dynamic")
log("test2")
require("prototypes.recipes.extraction-dynamic")
log("test3")
require("prototypes.recipes.solvation-dynamic")
log("test4")
if mods["angelsrefining"] then 
	data.raw.resource["uranium-ore"]=nil
end

log("not blocking here")

for _,f in pairs(data.raw.fluid) do
	data.raw.recipe["angels-fluid-splitter-"..f.name]=nil
end

omni.lib.add_unlock_recipe("omni-sorting-electric-1","crushing-omnite")
omni.lib.add_unlock_recipe("omni-sorting-electric-1","pulverize-omnite")

--omni.lib.add_unlock_recipe("omnic-hydrolyzation-"..math.floor(omni.fluid_levels/2),"stone-omnisolvent")
--omni.lib.add_unlock_recipe("omnic-hydrolyzation-"..math.floor(omni.fluid_levels/2),"omnite-crystalization")

for i = 1, omnimatter.omnitractortiers-1 do
	omni.lib.add_unlock_recipe("omni-sorting-electric-"..i,"base-impure-extraction-"..(i+1))
end

for _,r in pairs(omnisource) do
  for _, gen in pairs(data.raw["resource"]) do
	if gen.minable.result == r.ore.name then
		data.raw.resource[gen.name] = nil
		data.raw["autoplace-control"][gen.name] = nil
		--return
	elseif gen.minable.results  then
		for _,res in pairs(gen.minable.results) do
			if res.name == r.ore.name then
				data.raw.resource[gen.name] = nil
				data.raw["autoplace-control"][gen.name] = nil			
			end
		end
	end
  end
  for _, pre in pairs(data.raw["map-gen-presets"].default) do
	if pre.basic_settings then
		if pre.basic_settings.autoplace_controls then
			pre.basic_settings.autoplace_controls[r.ore.name] = nil
		end
	end
  end
end


for _,r in pairs(omnifluid) do 
  for _, gen in pairs(data.raw["resource"]) do
	if gen.minable.results then
		for _,f in pairs(gen.minable.results) do
			if f.name == r.fluid.name then
				data.raw.resource[gen.name] = nil
				data.raw["autoplace-control"][gen.name] = nil
				--return
			end
		end
	end
  end
  for _, pre in pairs(data.raw["map-gen-presets"].default) do
	if pre.basic_settings then
		if pre.basic_settings.autoplace_controls then
			pre.basic_settings.autoplace_controls[r.fluid.name] = nil
			pre.basic_settings.autoplace_controls["crude-oil"] = nil
			pre.basic_settings.autoplace_controls["angels-fissure"] = nil
		end
	end
  end
end
if bobmods and bobmods.ores then
	require("prototypes.bob-compensation")
end

for _,rock in pairs(data.raw["simple-entity"]) do
	if string.find(rock.name,"rock") then
		if rock.minable and rock.minable.results then
			for _,res in pairs(rock.minable.results) do
				if res.name == "stone" then
					res.name = "omnite"
				end
			end
		end
		if rock.loot then
			for _,loot in pairs(rock.loot) do
				if loot.name == "stone" then
					loot.name = "omnite"
				end
			end
		end
	end
end
--sortTiers()
if omni.rocket_locked then
--"rocket-silo"
	for _,ore in pairs(omnisource) do
		omni.lib.add_prerequisite("rocket-silo","omni-sorting-"..ore.ore.name.."-"..3*omni.pure_levels_per_tier)
	end
	omni.lib.add_prerequisite("rocket-silo","stone-omnisolvent-"..omni.fluid_levels)
	for _,fluid in pairs(omnifluid) do
		omni.lib.add_prerequisite("rocket-silo","distillation-"..fluid.fluid.name.."-"..omni.fluid_levels)
	end
end

local debrick = table.deepcopy("stone-brick")
if debrick.normal then


end


--data.raw.technology["coal-liquefaction"]=nil
--data.raw.recipe["coal-liquefaction"]=nil

--require("prototypes.omnitractor-requirements")


--require("migrations.omnimatter_reset")