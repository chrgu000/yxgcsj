	
local ord={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r"}

local omni_fluids_prefixes = {{"omniston","solvation"},{"omnic","hydrolyzation"},{"stone","omnisolvent"},{"water","omnitraction"},{"mud","omnitraction"}}

script.on_event(defines.events.on_player_created, function(event)
local iteminsert = game.players[event.player_index].insert
iteminsert{name="burner-omnitractor-1", count=1}
end)

local start_with = function(a,b)
	return string.sub(a,1,string.len(b)) == b
end
local start_within_table = function(a,b)
	return string.sub(a,1,string.len(b)) == b
end

script.on_event(defines.events.on_player_joined_game, function(event)
	
end)

local string_contained_list = function(str, list)
	for i=1, #list do
		if type(list[i])=="table" then
			local found_it = true
			for _,words in pairs(list[i]) do
				found_it = found_it and string.find(str,words)
			end
			if found_it then return true end
		else
			if string.find(str,list[i]) then return true end
		end
	end
	return false
end

script.on_configuration_changed( function(conf)
	local material_level = {}
	for each, force in pairs(game.forces) do
		for _, tech in pairs(force.technologies) do
			if tech.researched then
				if start_with(tech.name,"omni-sorting-") and not start_with(tech.name,"omni-sorting-electric-")then
					local length = string.len(tech.name)
					local lvl = 0
					local material = ""
					if string.sub(tech.name,length-1,length-1) == "-" then
						lvl = tonumber(string.sub(tech.name,length,length))
						material = string.sub(tech.name,string.len("omni-sorting-")+1,length-2)
					else
						lvl = tonumber(string.sub(tech.name,length-1,length))	
						material = string.sub(tech.name,string.len("omni-sorting-")+1,length-3)	
					end
					if not material_level[material] then
						material_level[material]={name=material, pure = 1}
					elseif not material_level[material].pure then
						material_level[material].pure=1
					end
					if lvl > material_level[material].pure then material_level[material].pure=lvl end
				elseif start_with(tech.name,"omni-impure-") then
					local length = string.len(tech.name)
					local lvl = 0
					local material = ""
					if string.sub(tech.name,length-1,length-1) == "-" then
						lvl = tonumber(string.sub(tech.name,length,length))
						material = string.sub(tech.name,string.len("omni-impure-")+1,length-1-string.len("-extraction-"))
					else
						lvl = tonumber(string.sub(tech.name,length-1,length))	
						material = string.sub(tech.name,string.len("omni-impure-")+1,length-2-string.len("-extraction-"))	
					end
					if not material_level[material] then
						material_level[material]={name=material, impure = 1}
					elseif not material_level[material].impure then
						material_level[material].impure=1
					end
					if lvl > material_level[material].impure then material_level[material].impure=lvl end
				elseif start_with(tech.name,"distillation") then
					local length = string.len(tech.name)
					local lvl = 0
					local material = ""
					if string.sub(tech.name,length-1,length-1) == "-" then
						lvl = tonumber(string.sub(tech.name,length,length))
						material = string.sub(tech.name,string.len("distillation-")+1,length-2)
					else
						lvl = tonumber(string.sub(tech.name,length-1,length))	
						material = string.sub(tech.name,string.len("distillation-")+1,length-3)	
					end
					if not material_level[material] then
						material_level[material]={name=material, fluid = 1}
					elseif not material_level[material].fluid then
						material_level[material].fluid=1
					end
					if lvl > material_level[material].fluid then material_level[material].fluid=lvl end
				else
					log(tech.name)
					for _,str in pairs(omni_fluids_prefixes) do
						if string_contained_list(tech.name,{str}) then
							local length = string.len(tech.name)
							local lvl = 0
							local material = str[1]
							for i, part in pairs(str) do
								if i>1 then
									material=material.."-"..part
								end
							end
							material=material.."-"
							if string.sub(tech.name,length-1,length-1) == "-" then
								lvl = tonumber(string.sub(tech.name,length,length))
							else
								lvl = tonumber(string.sub(tech.name,length-1,length))
							end
							if not material_level[material] then
								material_level[material]={name=material, fluid = 1,prefix=material}
							elseif not material_level[material].fluid then
								material_level[material].fluid=1
								material_level[material].prefix=material
							end
							if lvl > material_level[material].fluid then material_level[material].fluid=lvl end
						end
					end
				end
			end
		end
		log(serpent.block(material_level))
		for _, mat in pairs(material_level) do
			if mat.pure then
				for i=1,mat.pure do
					force.recipes[mat.name.."-extraction-"..ord[i]].enabled = false	
				end
				force.recipes[mat.name.."-extraction-"..ord[mat.pure]].enabled = true					
			end
			if mat.impure then
				for i=1,mat.impure do
					force.recipes["impure-"..mat.name.."-extraction-"..i].enabled = false	
				end
				force.recipes["impure-"..mat.name.."-extraction-"..mat.impure].enabled = true					
			end
			if mat.fluid and mat.prefix then
				for i=1,mat.fluid do
					force.recipes[mat.prefix..ord[i]].enabled = false	
				end
				force.recipes[mat.prefix..ord[mat.fluid]].enabled = true
			elseif mat.fluid then
				for i=1,mat.fluid do
					force.recipes["distillation-"..mat.name.."-"..ord[i]].enabled = false	
				end
				force.recipes["distillation-"..mat.name.."-"..ord[mat.fluid]].enabled = true				
			end
		end
	end
end)

script.on_event(defines.events.on_research_finished, function(event)
	local tech = event.research
	if string_contained_list(tech.name,{{"omni","sorting"}}) and not string.find(tech.name,"electric") then
		local length = string.len(tech.name)
		local lvl = 0
		local material = ""
		if string.sub(tech.name,length-1,length-1) == "-" then
			lvl = tonumber(string.sub(tech.name,length,length))
			material = string.sub(tech.name,string.len("omni-sorting-")+1,length-2)
		else
			lvl = tonumber(string.sub(tech.name,length-1,length))	
			material = string.sub(tech.name,string.len("omni-sorting-")+1,length-3)	
		end
		if lvl > 1 then
			for i=1,5 do
				for _,surface in pairs(game.surfaces) do
					for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name="omnitractor-"..i}) do
						local rec = entity.get_recipe()
						if rec and rec.name == material.."-extraction-"..ord[lvl-1] then
							entity.set_recipe(material.."-extraction-"..ord[lvl])
						end
					end
				end
			end
			for i=1,lvl-1 do
				tech.force.recipes[material.."-extraction-"..ord[i]].enabled = false	
			end
		end
	end
	--tech: "omni-impure-"..omnisource[i].ore.name.."-extraction-"..l
	--Recipe: "impure-"..omnisource[i].ore.name.."-extraction-"..l
	if string_contained_list(tech.name,{{"omni","impure"}}) and not string.find(tech.name,"base") then
		local length = string.len(tech.name)
		local lvl = 0
		local material = ""
		if string.sub(tech.name,length-1,length-1) == "-" then
			lvl = tonumber(string.sub(tech.name,length,length))
			material = string.sub(tech.name,string.len("omni-impure-")+1,length-1-string.len("-extraction-"))
		else
			lvl = tonumber(string.sub(tech.name,length-1,length))	
			material = string.sub(tech.name,string.len("omni-impure-")+1,length-2-string.len("-extraction-"))	
		end
		if lvl > 1 then
			for i=1,5 do
				for _,surface in pairs(game.surfaces) do
					for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name="omnitractor-"..i}) do
						local rec = entity.get_recipe()
						if rec and rec.name == "impure-"..material.."-extraction-"..lvl-1 then
							entity.set_recipe("impure-"..material.."-extraction-"..lvl)
						end
					end
				end
			end
			for _,surface in pairs(game.surfaces) do
				for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name="burner-omnitractor-1"}) do
					local rec = entity.get_recipe()
					if rec and rec.name == "impure-"..material.."-extraction-"..lvl-1 then
					entity.set_recipe("impure-"..material.."-extraction-"..lvl)
					end
				end
			end
			tech.force.recipes["impure-"..material.."-extraction-"..lvl-1].enabled = false
		end
	end
	for _,str in pairs(omni_fluids_prefixes) do
		if string_contained_list(tech.name,{str}) then
			local length = string.len(tech.name)
			local lvl = 0
			local material = ""
			if string.sub(tech.name,length-1,length-1) == "-" then
				lvl = tonumber(string.sub(tech.name,length,length))
			else
				lvl = tonumber(string.sub(tech.name,length-1,length))
			end
			local fluid_buildings = {"chemical-plant","chemical-plant-2","chemical-plant-3","chemical-plant-4","chemical-plant-5"}
			if game.active_mods["omnimatter_crystal"] then
				fluid_buildings={}
				for i=1,4 do
					fluid_buildings[#fluid_buildings+1] = "omni-plant-"..i
				end
			end
			if lvl > 1 then
				local material = str[1]
				for i, part in pairs(str) do
					if i>1 then
						material=material.."-"..part
					end
				end
				material=material.."-"
				for _,building in pairs(fluid_buildings) do
					for _,surface in pairs(game.surfaces) do
						for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name=building}) do
							local rec = entity.get_recipe()
							if rec and rec.name == material..ord[lvl-1] then
								entity.set_recipe(material..ord[lvl])
							end
						end
					end
				end
				tech.force.recipes[material..ord[lvl-1]].enabled = false
			end
		end
	end
	--"distillation-"..f.fluid.name.."-"..ord[i]
	if start_with(tech.name,"distillation") then
		local length = string.len(tech.name)
		local lvl = 0
		local material = ""
		if string.sub(tech.name,length-1,length-1) == "-" then
			lvl = tonumber(string.sub(tech.name,length,length))
			material = string.sub(tech.name,string.len("distillation-")+1,length-2)
		else
			lvl = tonumber(string.sub(tech.name,length-1,length))	
			material = string.sub(tech.name,string.len("distillation-")+1,length-3)	
		end
		local fluid_buildings = {"chemical-plant","chemical-plant-2","chemical-plant-3","chemical-plant-3"}
		if game.active_mods["omnimatter_crystal"] then fluid_buildings = {"omni-plant"} end
		if lvl > 1 then
			for _,building in pairs(fluid_buildings) do
				for _,surface in pairs(game.surfaces) do
					for _,entity in pairs(surface.find_entities_filtered{force=event.research.force, name=building}) do
						local rec = entity.get_recipe()
						if rec and rec.name == "distillation-"..material.."-"..ord[lvl-1] then
							entity.set_recipe("distillation-"..material.."-"..ord[lvl])
						end
					end
				end
			end
			tech.force.recipes["distillation-"..material.."-"..ord[lvl-1]].enabled = false
		end
	end
end)
