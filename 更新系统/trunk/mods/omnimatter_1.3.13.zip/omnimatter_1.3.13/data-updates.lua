
if mods["omnimatter_marathon"] then
	omni.marathon.exclude_recipe("pulverize-omnite")
	omni.marathon.exclude_recipe("omni-iron-general-1")
	omni.marathon.exclude_recipe("omni-copper-general-1")
	omni.marathon.exclude_recipe("omni-saphirite-general-1")
	omni.marathon.exclude_recipe("omni-stiratite-general-1") 
end

omni.add_resource(data.raw.item["coal"],2)
omni.add_resource(data.raw.item["stone"],3)

if mods["SigmaOne_Nuclear"] then
	omni.add_resource(data.raw.item["fluorine-ore"],3)
end

if mods["omnimatter_science"] and mods["omnimatter_crystal"] then
	omni.sciencepacks={"science-pack-1","science-pack-2","omni-pack","military-science-pack","science-pack-3","production-science-pack","high-tech-science-pack"}
end
	
if angelsmods and angelsmods.refining then
	omni.add_resource(data.raw.item["angels-ore1"],1)
	omni.add_resource(data.raw.item["angels-ore3"],1)
	if bobmods and bobmods.ores then
		omni.add_resource(data.raw.item["angels-ore5"],2)
		omni.add_resource(data.raw.item["angels-ore6"],2)
		omni.add_resource(data.raw.item["angels-ore2"],3)
		omni.add_resource(data.raw.item["angels-ore4"],3)
	else
		omni.add_resource(data.raw.item["angels-ore2"],2)
		omni.add_resource(data.raw.item["angels-ore4"],3)
		omni.add_resource(data.raw.item["uranium-ore"],3)
		omni.add_fluid(data.raw.fluid["crude-oil"],1,1)
	end
	omni.add_fluid(data.raw.fluid["thermal-water"],3,3)
else
	if bobmods and bobmods.ores then
		omni.add_resource(data.raw.item["iron-ore"],1)
		omni.add_resource(data.raw.item["copper-ore"],1)
		omni.add_resource(data.raw.item["lead-ore"],1)
		omni.add_resource(data.raw.item["tin-ore"],1)
		omni.add_resource(data.raw.item["quartz"],2)
		omni.add_resource(data.raw.item["zinc-ore"],2)
		omni.add_resource(data.raw.item["nickel-ore"],2)
		omni.add_resource(data.raw.item["bauxite-ore"],2)
		omni.add_resource(data.raw.item["rutile-ore"],3)
		omni.add_resource(data.raw.item["gold-ore"],3)
		omni.add_resource(data.raw.item["cobalt-ore"],3)
		omni.add_resource(data.raw.item["silver-ore"],3)
		omni.add_resource(data.raw.item["uranium-ore"],3)
		omni.add_resource(data.raw.item["tungsten-ore"],3)
		
		--omni.add_resource(data.raw.item["sapphire-ore"],1)
		--omni.add_resource(data.raw.item["emerald-ore"],1)
		--omni.add_resource(data.raw.item["amethyst-ore"],2)
		--omni.add_resource(data.raw.item["topaz-ore"],2)
		--omni.add_resource(data.raw.item["diamond-ore"],3)
		omni.add_resource(data.raw.item["gem-ore"],3)
		
		omni.add_fluid(data.raw.fluid["lithia-water"],2,3/4)
		--sulfur
	else
		omni.add_resource(data.raw.item["iron-ore"],1)
		omni.add_resource(data.raw.item["copper-ore"],2)
		omni.add_resource(data.raw.item["uranium-ore"],3)
	end
	for _, gen in pairs(data.raw["resource"]) do
		if gen.minable.result == "stone" then
			data.raw.resource[gen.name] = nil
			data.raw["autoplace-control"][gen.name] = nil
		elseif gen.minable.results  then
			for _,res in pairs(gen.minable.results) do
				if res.name == "stone" then
					data.raw.resource[gen.name] = nil
					data.raw["autoplace-control"][gen.name] = nil			
				end
			end
		end
	end
end
if angelsmods and angelsmods.petrochem then
	omni.add_fluid(data.raw.fluid["gas-natural-1"],1,3+4/7)
	omni.add_fluid(data.raw.fluid["liquid-multi-phase-oil"],2,1+3/8)
	if not mods["omnimatter_water"] then omni.add_resource(data.raw.item["sulfur"],2) end
else
	omni.add_fluid(data.raw.fluid["crude-oil"],1,1)
end
if mods["dark-matter-replicators"] then
	omni.add_resource(data.raw.tool["tenemut"],3)
end
if mods["Yuoki"] then
	omni.add_resource(data.raw.item["y-res1"],2)
	omni.add_resource(data.raw.item["y-res2"],3)
end
require("prototypes.stone")
for i,tech in pairs(data.raw.technology) do
	if string.find(tech.name,"pumpjack") then
		--table.remove(data.raw.technology,i)
		data.raw.technology[tech.name].enabled=false
	elseif tech.prerequisites then
		for j=1,#tech.prerequisites do
			if string.find(tech.prerequisites[j],"pumpjack") then
				--data.raw.technology[tech.name].prerequisites[j]=nil
			end
		end
		if tech and tech.effects then
			for i,eff in pairs(tech.effects) do
				if eff.type == "unlock-recipe" and string.find(eff.recipe,"pumpjack") then
					table.remove(data.raw.technology[tech.name].effects,i)
				end
			end
		end
	end
end
for _,recipe in pairs(data.raw.recipe) do
	if (recipe.result and string.find(recipe.result,"pumpjack")) or (recipe.results and recipe.results[1].name and string.find(recipe.results[1].name,"pumpjack")) then
		data.raw.recipe[recipe.name].enabled=false
	elseif recipe.ingredients then
		for i=1, #recipe.ingredients do
			if recipe.ingredients[i].name and string.find(recipe.ingredients[i].name,"pumpjack") then
				--table.remove(data.raw.recipe[recipe.name].ingredients,i)
			elseif recipe.ingredients[i][1] and string.find(recipe.ingredients[i][1],"pumpjack") then
				--table.remove(data.raw.recipe[recipe.name].ingredients,i)
			end
		end
	end
end

for _, item in pairs(data.raw.item) do
	if string.find(item.name,"pumpjack") then
		--data.raw.item[item.name]=nil
		--data.raw["mining-drill"][item.place_result]=nil
	end
end

if mods["omnimatter_marathon"] then
	omni.marathon.exclude_recipe("omnicium-plate-pure")
	omni.marathon.exclude_recipe("crushing-omnite-by-hand")
end
--data:extend(set)