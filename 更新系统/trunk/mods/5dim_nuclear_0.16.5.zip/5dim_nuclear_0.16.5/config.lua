--Define if vehicles is installed
nuclear = true --Default: True