data:extend{
    {
    type = "custom-input",
    name = "resource-labels-add",
    key_sequence = "SHIFT + G",
    consuming = "none"
    },
    
    {
    type = "custom-input",
    name = "resource-labels-remove",
    key_sequence = "SHIFT + H",
    consuming = "none"
    }
}