data:extend({
  {
    type = "flying-text",
    name = "statictext",
    flags = {"not-on-map"},
    time_to_live = 1999999999,
    speed = 0.0
  }
})
