Display utilization of various buildings as a percentage for the last one minute.
100% utilization means the factory was working in every single tick in the last 60 seconds.

The percentage is displayed at the top left corner of the building. I used "flying-text" for the percentages for simplicity, which means the percentages have a fixed size regardless of the zoom level. It is useful to overview the whole base.

The mod is published here: https://mods.factorio.com/mods/suan2/UtilizationMonitor