require("prototypes.item")
require("prototypes.statictext")

data:extend({
  {
      type = "custom-input",
      name = "toggle-utilization-monitor",
      key_sequence = "CONTROL + SHIFT + U"
  },
  {
      type = "custom-input",
      name = "toggle-utilization-monitor-labels",
      key_sequence = "CONTROL + U"
  }
})
