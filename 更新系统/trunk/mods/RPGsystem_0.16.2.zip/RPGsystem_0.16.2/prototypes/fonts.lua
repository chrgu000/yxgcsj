data:extend(
   {
      {
         type = "font",
         name = "charxpmod_font_30b",
         from = "default-bold",
         size = 30
      },
      {
         type = "font",
         name = "charxpmod_font_30",
         from = "default",
         size = 30
      },
	  {
         type = "font",
         name = "charxpmod_font_17",
         from = "default",
         size = 17
      },
	  {
         type = "font",
         name = "charxpmod_font_17b",
         from = "default-bold",
         size = 17
      },

      {
         type = "font",
         name = "charxpmod_font_20",
         from = "default",
         size = 20
      },	  
  }
)