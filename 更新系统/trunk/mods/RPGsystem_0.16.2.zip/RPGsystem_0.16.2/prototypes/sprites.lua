data:extend({
  {
    type="sprite",
    name="charxpmod_space_suit",
    filename = "__RPGsystem__/graphics/space_suit.png",
    priority = "extra-high-no-scale",
    width = 80,
    height = 150,
  }
 
  
})
