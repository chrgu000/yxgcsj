require("prototypes.fonts")
require("prototypes.sprites")
require("controls")