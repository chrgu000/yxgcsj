data:extend({
  {
    type = "custom-input",
    name = "key-I",
    key_sequence = "I",
    consuming = "script-only"
  }  
})
