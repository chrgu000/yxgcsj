require "mod-gui"
require("utils")

--[[
  ** SISTEMA DE XP E LEVEL UP**
]]

--formula exponencial para level up

function ResetXPTables()

local xp = settings.startup["charxpmod_xpinilevel"].value
global.xp_table = {[1] = xp}

for k=2,100 do
	xp = math.ceil(xp * settings.startup["charxpmod_xpmult"].value)
	global.xp_table[k] = xp
	end
end

function InitPlayer(player)
player.gui.top.add{name="btcharxp", type="sprite-button", sprite = "entity/player", tooltip = {"panel-title"}}
SetupPlayer(player,true)
end

function resetAllPlayerStats()
	for _, player in pairs(game.players) do
		if not player.gui.top.btcharxp then
			InitPlayer(player)
			else
			SetupPlayer(player,false)
			end
		end
end

	
function XPSetup()

if global.CharXPMOD == nil then 
	global.CharXPMOD = 1
	global.kills_spawner={}
	global.kills_units={}
	global.kills_worms={}
	global.XP={}
	global.XP_GANHO={}
	global.XP_KILL_HP={}
	global.XP_TECH={}
	global.XP_LEVEL={}
	global.XP_LEVEL_MIN={}
	
	
	global.personalxp = {}
	global.personalxp.Level = {}
	global.personalxp.XP = {}
	global.personalxp.Death = {}
	
    global.personalxp.LV_Craft_Speed = {}
    global.personalxp.LV_Mining_Speed = {}
    global.personalxp.LV_Run_Speed = {}
    global.personalxp.LV_Build_Dist = {}
    global.personalxp.LV_Reach_Dist = {}
    global.personalxp.LV_Inv_Bonus = {}
    global.personalxp.LV_InvQB_Bonus = {}
    global.personalxp.LV_InvLog_Bonus = {}
    global.personalxp.LV_InvTrash_Bonus = {}
    global.personalxp.LV_Robot_Bonus = {}
    global.personalxp.LV_Health_Bonus = {}
	

		
	for name, force in pairs (game.forces) do
		if name~='neutral' and name~='enemy' then
		
		global.kills_spawner[name] = 0
		global.kills_units[name] = 0
		global.kills_worms[name] = 0
		global.XP[name] = 0
		global.XP_GANHO[name] = 0
		global.XP_KILL_HP[name]=0
		global.XP_TECH[name] = 0
		global.XP_LEVEL[name] = 1
		global.XP_LEVEL_MIN[name] = 0
		
		end
		end
	
	resetAllPlayerStats()
	end
	

ResetXPTables()
	
end



function XP_Player_upd()

 	for name, force in pairs (game.forces) do
	if name~='neutral' and name~='enemy' then

		local cp = #force.connected_players
		local afk = settings.global["charxpmod_afk"].value
		if cp>0 then
			local XP = global.XP[name]   --math.ceil(global.XP[name] / cp)
			
			for p, PL in pairs (force.connected_players) do 
				if afk==0 or PL.afk_time<afk*3600 then 
				global.personalxp.XP[PL.name] = global.personalxp.XP[PL.name] + XP
				UpdatePanel(PL)
				end
				end
		global.XP[name]=0	
		end
	end
	end
end



function XP_PlayerLv_upd()

	for _, player in pairs(game.players) do
		if player.connected then
			local name = player.name
			local Lv = global.personalxp.Level[name]
			for L=Lv, #global.xp_table do
				if global.personalxp.XP[name]< global.xp_table[L] then
					global.personalxp.Level[name]=L
					break
				end
			end
			
			if global.personalxp.Level[name] > Lv then
				player.print({'player_lv_up'})
				UpdatePanel(player)
				end
		end
	end
end



function XP_UPDATE_tick()

XP_Player_upd()
XP_PlayerLv_upd()

end


function SetupPlayer(player,all)
name= player.name
	
	if all then
		global.personalxp.XP[name] = 0
		global.personalxp.Death[name] = 0
		end

	global.personalxp.Level[name] = 1
    global.personalxp.LV_Craft_Speed[name]  = 0
    global.personalxp.LV_Mining_Speed[name] = 0
    global.personalxp.LV_Run_Speed[name]    = 0
    global.personalxp.LV_Build_Dist[name]   = 0
    global.personalxp.LV_Reach_Dist[name]   = 0
    global.personalxp.LV_Inv_Bonus[name]    = 0
    global.personalxp.LV_InvQB_Bonus[name]  = 0
    global.personalxp.LV_InvLog_Bonus[name] = 0
    global.personalxp.LV_InvTrash_Bonus[name] = 0
    global.personalxp.LV_Robot_Bonus[name]  = 0
    global.personalxp.LV_Health_Bonus[name] = 0
	
end


function FormulaSumLv(lv)
local pt = 0
if lv>0 then
for k=1,lv do pt=pt+ 1 + math.floor((k-1)/2)  end end
return pt
end
---pt=pt+(math.floor((k+0.5)/2))


function SumPoitSpent(name)
local sum = (FormulaSumLv(global.personalxp.LV_Craft_Speed[name]) + 
    FormulaSumLv(global.personalxp.LV_Mining_Speed[name]) +
    FormulaSumLv(global.personalxp.LV_Run_Speed[name])    +
    --FormulaSumLv(global.personalxp.LV_Build_Dist[name])   +
    FormulaSumLv(global.personalxp.LV_Reach_Dist[name])   +
    FormulaSumLv(global.personalxp.LV_Inv_Bonus[name])    +
    FormulaSumLv(global.personalxp.LV_InvQB_Bonus[name])  +
    FormulaSumLv(global.personalxp.LV_InvLog_Bonus[name]) +
    FormulaSumLv(global.personalxp.LV_InvTrash_Bonus[name]) +
    FormulaSumLv(global.personalxp.LV_Robot_Bonus[name])  +
    FormulaSumLv(global.personalxp.LV_Health_Bonus[name]))
return sum	
end





local function Cria_GUI(event)
    local player = game.players[event.player_index]
    if not player.gui.top.btcharxp then
		InitPlayer(player)
	end
end


function update_char_panel(player)
 
 
  local force = player.force.name
  local painel = player.gui.center["char-panel"]
  local frame = painel.tabcharScroll
  local nome = player.name
  local Level = global.personalxp.Level[nome] 


local ptime = player.online_time
local txtPTime = {"time-played" ,string.format("%d:%02d:%02d", math.floor(ptime / 216000), math.floor(ptime / 3600) % 60, math.floor(ptime / 60) % 60)}

local PontosXP = Level - 1 - SumPoitSpent(nome)
if PontosXP<0 then PontosXP=0 end

--	local img = frame.add{type = "sprite", sprite = "msi_win"}
--  local evo   = {"missions.evolution-factor", string.format("%.2f", math.floor(game.forces["enemy"].evolution_factor * 10000) / 100)}

  local tabChar = frame.add{type = "table", name = "tab_tbchar", column_count = 2}
  tabChar.add{type = "sprite", sprite = "charxpmod_space_suit"}

  local tabScroll = tabChar.add{type = "scroll-pane", name= "tabScroll2", vertical_scroll_policy="auto", horizontal_scroll_policy="auto"}
	tabScroll.style.minimal_height = 150
	tabScroll.style.minimal_width = 320
	tabScroll.style.maximal_width = 350		

 
  local tabPName = tabScroll.add{type = "table", name = "tab_pname", column_count = 3}
  local pname = tabPName.add{type="label", name='ocharname',  caption=nome}
  pname.style.font="charxpmod_font_30b"
  pname.style.font_color=player.color 
  tabPName.add{type="label", name='blanklab1', caption='        - '}
  local pnivel = tabPName.add{type="label", name='ocharlevel', caption={'actual_lv',Level}}
  pnivel.style.font="charxpmod_font_30"
  pnivel.style.font_color=player.color 


  local tabPStat = tabScroll.add{type = "table", name = "tab_PStat", column_count = 2}
  tabPStat.add{type="label", name='STT1', caption= txtPTime}.style.font="charxpmod_font_17"
  tabPStat.add{type="label", name='STT2', caption={'xp_deaths',global.personalxp.Death[nome]}}.style.font="charxpmod_font_17"
   
  tabScroll.add{type="label", name='blankL1', caption=' '}
  
  -- stats
  local tabStats = tabScroll.add{type = "table", name = "tabStats", column_count = 2}
  tabStats.add{type="label", name='STT3', caption={'xp_spawnk',global.kills_spawner[force]}}
  tabStats.add{type="label", name='STT4', caption={'xp_techs',global.XP_TECH[force]}}
  tabStats.add{type="label", name='STT5', caption={'xp_wormk',global.kills_worms[force]}}
  tabStats.add{type="label", name='STT6', caption={'xp_unitk',global.kills_units[force]}}


-- BARRA DE XP 
local XP = global.personalxp.XP[nome] 
local NextLevel = global.xp_table[Level]
local XP_ant
if Level==1 then XP_ant = 0 else XP_ant = global.xp_table[Level-1] end
local Interval_XP = NextLevel - XP_ant
local pbvalue = (XP-XP_ant)/Interval_XP
  
  local tabXP = frame.add{type = "table", name = "tab_XP", column_count = 3}
  tabXP.add{type="label", name='lbxpatual', caption='XP: ' .. XP }.style.font="charxpmod_font_17"
  local bar = tabXP.add{type = "progressbar", size = 150, value = pbvalue, name = "tab_XPbar"}
  tabXP.add{type="label", name='lbxpnext', caption={'next_lv',NextLevel}}.style.font="charxpmod_font_17"


  
  frame.add{type="label", name='blankL3', caption=' '}
  frame.add{type="label", name='lbxPAGastar', caption={'xp_points',PontosXP}}.style.font="charxpmod_font_20"   
  
-- LEVELS / UPGRADES
  local tabUpgrades = frame.add{type = "table", name = "tabUpgrades", column_count = 6}
  
  local Max = 20
  
  local vchar = 'global.personalxp.LV_Health_Bonus' 
  local atual = global.personalxp.LV_Health_Bonus[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

	 
  local vchar = 'global.personalxp.LV_Run_Speed'
  atual = global.personalxp.LV_Run_Speed[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo},name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

  local vchar = 'global.personalxp.LV_Craft_Speed'
  atual = global.personalxp.LV_Craft_Speed[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end
  
  local vchar = 'global.personalxp.LV_Mining_Speed'
  atual = global.personalxp.LV_Mining_Speed[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

--[[
  local vchar = 'global.personalxp.LV_Build_Dist'
  atual = global.personalxp.LV_Build_Dist[nome]
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}
  if PontosXP>=atual+1 and atual<=Max  then tabUpgrades.add{type="button", style = mod_gui.button_style, caption='+', name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='    '} end
]]
	 
  local vchar = 'global.personalxp.LV_Reach_Dist'
  atual = global.personalxp.LV_Reach_Dist[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

  local vchar = 'global.personalxp.LV_Inv_Bonus'
  atual = global.personalxp.LV_Inv_Bonus[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button",  caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

--[[  local vchar = 'global.personalxp.LV_InvQB_Bonus'
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=global.personalxp.LV_InvQB_Bonus[nome]}
  if PontosXP>=atual and atual<=Max  then tabUpgrades.add{type="button", style = mod_gui.button_style, caption='+', name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='    '} end
]]	 

  local vchar = 'global.personalxp.LV_InvLog_Bonus'
  atual = global.personalxp.LV_InvLog_Bonus[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button", caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

  local vchar = 'global.personalxp.LV_InvTrash_Bonus'
  atual = global.personalxp.LV_InvTrash_Bonus[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button", caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end

  local vchar = 'global.personalxp.LV_Robot_Bonus'
  atual = global.personalxp.LV_Robot_Bonus[nome]
  local custo = 1 + math.floor(atual/2)
  tabUpgrades.add{type="label", name='lmChar1'..vchar, caption={vchar}}
  tabUpgrades.add{type="label", name='lmChar2'..vchar, caption=atual}.style.font="charxpmod_font_17b"
  if PontosXP>=custo and atual<=Max  then tabUpgrades.add{type="button", caption='+', tooltip={'xp_costbt',custo}, name='btLVU_'..vchar} else
     tabUpgrades.add{type="label", name='lmChar3'..vchar, caption='      ', tooltip={'xp_costbt',custo}} end
	 
---
   frame.add{type="label", name='blankL4', caption=' '}
   
  --TAG 
  local tabtag = frame.add{type = "table", name = "tabchartag", column_count = 3}	
  tabtag.add{type="label", name="lab_ctag", caption="Tag  "}
  tabtag.add{type="textfield", name="ctag_field", text=player.tag}
  local btTagOK= tabtag.add{name="btTagCharOK", type="button", style = mod_gui.button_style, caption='OK'}
  end


function ListAll(player)
  local force = player.force
  local painel = player.gui.center["char-panel"]
  local frame = painel.tabcharScroll

  frame.add{type="label", name='lbxplayerlst', caption=Players}.style.font="charxpmod_font_20"
  local tabpllst = frame.add{type = "table", name = "tabpllst", column_count = 4}
  for p,PL in pairs (force.players) do
	tabpllst.add{type="label", name='pllstname'..p, caption=PL.name .. '('..global.personalxp.Level[PL.name] ..')'}
	end
  
end  
  
  
function UpdatePanel(player)
local frame = player.gui.center["char-panel"]
    if frame then
	
	local textImput = player.gui.center["char-panel"].tabcharScroll.tabchartag.ctag_field.text
	if player.tag~=textImput then return end
	
	expand_char_gui(player)
	expand_char_gui(player)
	end

end

function expand_char_gui(player)
    local frame = player.gui.center["char-panel"]
    if frame then
        frame.destroy()
    else
		frame = player.gui.center.add{type="frame", name="char-panel", direction = "vertical", style=mod_gui.frame_style, caption={"panel-title"}} 
		frame.style.minimal_height = 430
  		--frame.style.maximal_height = 430
		frame.style.minimal_width = 485
		frame.style.maximal_width = 485
		local tabcharScroll = frame.add{type = "scroll-pane", name= "tabcharScroll", vertical_scroll_policy="auto", horizontal_scroll_policy="auto"}
		tabcharScroll.style.minimal_height = 400
		--tabcharScroll.style.maximal_height = 1000
		tabcharScroll.style.minimal_width = 455
		tabcharScroll.style.maximal_width = 455		
		update_char_panel(player) 
    end
end





local function on_tick(event)
if game.tick % 1200 == 0 then
	XP_UPDATE_tick()
	end
end


function Cria_Player(event) 
local player = game.players[event.player_index]



end



function on_force_created(event) 

local name = event.force.name

	global.kills_spawner[name] = 0
	global.kills_units[name] = 0
	global.kills_worms[name] = 0
	global.XP[name] = 0
	global.XP_GANHO[name] = 0
	global.XP_TECH[name] = 0
	global.XP_LEVEL[name] = 1
	global.XP_LEVEL_MIN[name] = 0
	global.XP_KILL_HP[name] = 0
	
	
end



script.on_event(defines.events.on_player_created, Cria_Player)
script.on_event(defines.events.on_player_joined_game, Cria_GUI)
script.on_event(defines.events.on_tick, on_tick )
script.on_event(defines.events.on_force_created,on_force_created)

--------------------------------------------------------------------------------------
function On_Init_MAF() 
XPSetup()
end


function on_configuration_changed(data)
--VersionChange()
XPSetup()
end



script.on_configuration_changed(on_configuration_changed)
script.on_init(On_Init_MAF)



function UpdatePlayerLvStats(player)
local name=player.name
	player.character.character_crafting_speed_modifier = global.personalxp.LV_Craft_Speed[name] / 5
	player.character.character_mining_speed_modifier =  global.personalxp.LV_Mining_Speed[name] /5
	player.character.character_running_speed_modifier  =  global.personalxp.LV_Run_Speed[name] / 5
	player.character.character_build_distance_bonus   =  global.personalxp.LV_Reach_Dist[name]	--global.personalxp.LV_Build_Dist[name]
	player.character.character_reach_distance_bonus   =  global.personalxp.LV_Reach_Dist[name]
	player.character.character_inventory_slots_bonus    =  global.personalxp.LV_Inv_Bonus[name] * 5
	player.character.quickbar_count_bonus    =  global.personalxp.LV_InvQB_Bonus[name]
	player.character.character_logistic_slot_count_bonus    =  global.personalxp.LV_InvLog_Bonus[name] * 5
	player.character.character_trash_slot_count_bonus =  global.personalxp.LV_InvTrash_Bonus[name] * 5
	player.character.character_maximum_following_robot_count_bonus =  global.personalxp.LV_Robot_Bonus[name] * 3
	player.character.character_health_bonus =  global.personalxp.LV_Health_Bonus[name] * 50
end


function LevelUPPlayer(player,btname)

local name=player.name
if btname=='btLVU_global.personalxp.LV_Craft_Speed' then
	global.personalxp.LV_Craft_Speed[name] = global.personalxp.LV_Craft_Speed[name] + 1

elseif btname=='btLVU_global.personalxp.LV_Mining_Speed' then
	global.personalxp.LV_Mining_Speed[name] =  global.personalxp.LV_Mining_Speed[name] + 1

elseif btname=='btLVU_global.personalxp.LV_Run_Speed' then
	global.personalxp.LV_Run_Speed[name] =  global.personalxp.LV_Run_Speed[name] + 1

elseif btname=='btLVU_global.personalxp.LV_Build_Dist' then
	global.personalxp.LV_Build_Dist[name] =  global.personalxp.LV_Build_Dist[name] + 1

elseif btname=='btLVU_global.personalxp.LV_Reach_Dist' then
	global.personalxp.LV_Reach_Dist[name] =  global.personalxp.LV_Reach_Dist[name] + 1
	
elseif btname=='btLVU_global.personalxp.LV_Inv_Bonus' then
	global.personalxp.LV_Inv_Bonus[name] =  global.personalxp.LV_Inv_Bonus[name] + 1

elseif btname=='btLVU_global.personalxp.LV_InvQB_Bonus' then
	global.personalxp.LV_InvQB_Bonus[name] =  global.personalxp.LV_InvQB_Bonus[name] + 1

elseif btname=='btLVU_global.personalxp.LV_InvLog_Bonus' then
	global.personalxp.LV_InvLog_Bonus[name] =  global.personalxp.LV_InvLog_Bonus[name] + 1

elseif btname=='btLVU_global.personalxp.LV_InvTrash_Bonus' then
	global.personalxp.LV_InvTrash_Bonus[name] =  global.personalxp.LV_InvTrash_Bonus[name] + 1
	
elseif btname=='btLVU_global.personalxp.LV_Robot_Bonus' then
	global.personalxp.LV_Robot_Bonus[name] =  global.personalxp.LV_Robot_Bonus[name] + 1

elseif btname=='btLVU_global.personalxp.LV_Health_Bonus' then
	global.personalxp.LV_Health_Bonus[name] =  global.personalxp.LV_Health_Bonus[name] + 1
end
  
UpdatePlayerLvStats(player)
	
end


function ResetAll()
ResetXPTables()
resetAllPlayerStats()
end


script.on_event("key-I", function(event) expand_char_gui(game.players[event.player_index]) end)


local function on_gui_click(event)
--	message_all(global.debug)

local player = game.players[event.element.player_index]
local name = event.element.name

    if (name == "btcharxp") then
        expand_char_gui(player)
    elseif (name == "btTagCharOK")then
		local textImput = player.gui.center["char-panel"].tabcharScroll.tabchartag.ctag_field.text
		
		if textImput == "{resetall}" then ResetAll() return 
		elseif textImput == "{list}" then ListAll(player) return end
		
		player.tag = textImput
		expand_char_gui(player)
	
	elseif string.sub(name,1,6)=='btLVU_' then
		LevelUPPlayer(player,name)
		expand_char_gui(player)
		expand_char_gui(player)
	end
	
end
script.on_event(defines.events.on_gui_click, on_gui_click)




--- XP FOR KILL
script.on_event(defines.events.on_entity_died, function(event)

local force=event.force.name 
local killer=event.cause


if event.entity.force.name == 'enemy' and force~='neutral' and force~='enemy' then --aliens
	if event.entity.type == 'unit' then
		global.kills_units[force] = global.kills_units[force] + 1
		elseif event.entity.type == 'unit-spawner' then
		global.kills_spawner[force] = global.kills_spawner[force] +1
		elseif event.entity.type == 'turret' then
		global.kills_worms[force] = global.kills_worms[force] +1
		end

	local XP = event.entity.prototype.max_health
	if XP > 99999 then XP=99999 end
	XP = math.ceil(XP/100)
	if XP<1 then XP=1 end

	local teamxp = true

--[[	if killer~=nil then
	if killer.valid then
		if killer.type=='player' then
			local plname = killer.player.name
			global.personalxp.XP[plname] = global.personalxp.XP[plname] + XP
			teamxp = false
			end 
		end
		end ]]

	if teamxp then
		global.XP_KILL_HP[force] = global.XP_KILL_HP[force] + XP
		global.XP[force] = global.XP[force] + XP
		
		end
	end


end)

script.on_event(defines.events.on_player_respawned, function(event)
local player = game.players[event.player_index]
UpdatePlayerLvStats(player)
end)

script.on_event(defines.events.on_pre_player_died, function(event)
local player = game.players[event.player_index]
local name = player.name
local XP = global.personalxp.XP[name] 
local Level = global.personalxp.Level[name] 
local NextLevel = global.xp_table[Level]
local XP_ant
if Level==1 then XP_ant = 0 else XP_ant = global.xp_table[Level-1] end
local Interval_XP = NextLevel - XP_ant
local Penal = math.floor((XP-XP_ant)*settings.global["charxpmod_afk"].value/100)

global.personalxp.Death[name] = global.personalxp.Death[name]+1

if Penal>0 then 
global.personalxp.XP[name] = global.personalxp.XP[name]-Penal
player.print({'xp_lost'})
player.print(Penal)
end

end)

-- XP by research
script.on_event(defines.events.on_research_finished, function(event)

local techXP = event.research.research_unit_count * #event.research.research_unit_ingredients
techXP = math.ceil(techXP * (1+ (5*game.forces["enemy"].evolution_factor)))
--techXP = math.floor(techXP/10)
local force = event.research.force.name
global.XP_TECH[force] = global.XP_TECH[force]  +techXP
global.XP[force] = global.XP[force]  +techXP 

end)


-- XP by Rocket
script.on_event(defines.events.on_rocket_launched, function(event)
local rocket = event.rocket
local force = rocket.force

	for p, PL in pairs (force.connected_players) do 
		global.personalxp.XP[PL.name] = global.personalxp.XP[PL.name] + math.ceil(global.personalxp.XP[PL.name]/5) --20%
	end
end)


-- INTERFACE  --
--------------------------------------------------------------------------------------
-- /c remote.call("RPG","TeamXP","player",150)
local interface = {}

-- Give XP to Team (may be negative)
function interface.TeamXP(forcename,XP)
global.XP[forcename] = global.XP[forcename] + XP
end

-- Give XP to a player (may be negative)
function interface.PlayerXP(playername,XP)
global.personalxp.XP[playername] = global.personalxp.XP[playername] + XP
end

function interface.PlayerXPPerc(playername,Perc)
global.personalxp.XP[playername] = global.personalxp.XP[playername] + math.ceil(global.personalxp.XP[playername]*Perc/100) 
end

function interface.PlayerXPPenalPerc(playername,Perc)
global.personalxp.XP[playername] = global.personalxp.XP[playername] - math.ceil(global.personalxp.XP[playername]*Perc/100) 
end

function interface.TeamXPPerc(forcename,Perc)
	for p, PL in pairs (game.forces[forcename].connected_players) do 
		global.personalxp.XP[PL.name] = global.personalxp.XP[PL.name] + math.ceil(global.personalxp.XP[PL.name]*Perc/100) 
	end
end


remote.add_interface("RPG", interface )
