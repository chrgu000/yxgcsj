--Create a hash(?) table of pointers to all items which can be replicated
local all_items = {}
for _,current_replication in pairs(repl_table) do
	for _,current_item in ipairs(current_replication.items) do
		all_items[current_item.name] = current_item
		--Also have each replicatable item contain a pointer to its repltech
		current_item.parent = current_replication
		
		--Find and save a pointer to the item as well as whether this item is a fluid or not
		current_item.pointer = data.raw["fluid"][current_item.name]
		current_item.fluid = true
		if not current_item.pointer then
			current_item.pointer = data.raw["item"][current_item.name] or data.raw["tool"][current_item.name] or data.raw["repair-tool"][current_item.name] or data.raw["mining-tool"][current_item.name] or data.raw["ammo"][current_item.name] or data.raw["armor"][current_item.name] or data.raw["capsule"][current_item.name] or data.raw["gun"][current_item.name] or data.raw["blueprint"][current_item.name] or data.raw["deconstruction-item"][current_item.name] or data.raw["module"][current_item.name] or data.raw["module"][current_item.name] or data.raw["rail-planner"][current_item.name] 
			current_item.fluid = false
		end
		if not current_item.pointer then
			log("The replication of \""..current_item.name.."\" (in the repltech \""..current_replication.name.."\") is for an item which does not exist.  It will not be used as a research prerequisite and any tech which tries to do so will recieve its prerequisites instead.")
		end
	end
end

--Go through every replication prerequisite and make those values into a list
for _,current_replication in pairs(repl_table) do
	--Only process prerequisites for replications from enabled categories.  The prerequisites of disabled replications stay in table form.
	if current_replication.category.enabled then
		local prerequisite_table = current_replication.prerequisites
		
		--Find and save the replication's tier
		if current_replication.overrides then
			current_replication.tier = current_replication.overrides.tier or current_replication.category.tier
		else
			current_replication.tier = current_replication.category.tier
		end
		--Add the replication technology for the current tier as a prerequisite
		local prerequisite_strings = {"replication-"..current_replication.tier}
		
		--Convert each reference from a subtable to a string
		for i,current_prerequisite in ipairs(prerequisite_table) do
			
			if not current_prerequisite.target then
				log("\"repl-"..current_replication.name.."\" has a prerequisite with no target.  Factorio will now crash for your convenience.")
			end
			
			if current_prerequisite.type == "recipe" or current_prerequisite.type == "recipe-items-only" or current_prerequisite.type == "recipe-tech-only" then
				--Get a pointer to the referenced recipe
				local recipe = data.raw.recipe[current_prerequisite.target]
				if recipe then
					if current_prerequisite.type == "recipe" or current_prerequisite.type == "recipe-items-only" then
						--Get the list of recipe ingredients
						local ingredients = recipe.ingredients or recipe.normal.ingredients or {}
						--Append an item requirement for each item used in the recipe which also has an item replication
						for _,ingredient in ipairs(ingredients) do
							--Get the name of the ingredient
							local ingredient_name = ingredient.name or ingredient[1]
							--Check to see if there the ingredient can be replicated
							if all_items[ingredient_name] then
								--Append the replication of that item as a prerequisite
								prerequisite_table[#prerequisite_table + 1] = {target = ingredient_name, type = "item"}
							end
						end
					end
					if current_prerequisite.type == "recipe" or current_prerequisite.type == "recipe-tech-only" then
						--If the recipe is not enabled at the start, append a technology requirement for the first found technology which unlocks this recipe
						if recipe.enabled == false or (recipe.normal and recipe.normal.enabled == false) then
							local found_it = false
							for tech_name,technology in pairs(data.raw.technology) do
								--Look through every technology and check their effects until the technology which unlocks this recipe is found
								if technology.effects then
									for _,effect in ipairs(technology.effects) do
										if effect.type == "unlock-recipe" and effect.recipe == current_prerequisite.target then
											prerequisite_table[#prerequisite_table + 1] = {target = tech_name, type = "tech"}
											found_it = true
										end
									end
								end
								if found_it then break end
							end
							if not found_it then log("The recipe \""..current_prerequisite.target.."\" is not enabled by default but is also not unlocked by any technologies.  It only requires its existing ingredients to replicate.") end
						else
						end
					end
				else
					--Log that the recipe in question does not exist
					log("The prerequisites for \"repl-"..current_replication.name.."\" are generated from a recipe named \""..current_prerequisite.target.."\", but that recipe does not exist.  The prerequisite was dropped.")
				end
				
			elseif current_prerequisite.type == "item" then
				--Find the last replication (it should really be the only one, but if there are multiples the last one is used) which has the selected item as an item and add its name to the prerequisite list
				local item = all_items[current_prerequisite.target]
				--If an item could be found, add its repltech to the prerequisites list
				if item then
					if item.parent.category.enabled and item.pointer then
						--Add the item's repltech only if its replication is enabled
						prerequisite_strings[#prerequisite_strings + 1] = "repl-"..item.parent.name
					else
						--If the item is from a disabled category, copy its prerequisites onto the end of this repltech's prerequisites
						for _,copy_this in ipairs(item.parent.prerequisites) do
							prerequisite_table[#prerequisite_table + 1] = copy_this
						end
					end
				else
					--If an item cannot be found, drop the prerequisite and leave a note in Factorio's log file
					log("\"repl-"..current_replication.name.."\" requires the replication of \""..current_prerequisite.target.."\" as a prerequisite, but \""..current_prerequisite.target.."\" cannot be replicated.  The prerequisite was dropped.")
				end
				
			elseif current_prerequisite.type == "tech" then
				--Check to see if the technology in question exists
				if data.raw.technology[current_prerequisite.target] then
					--Add a technology to the replication list
					prerequisite_strings[#prerequisite_strings + 1] = current_prerequisite.target
				else
					--Unless the technology in question doesn't exist.
					log("\"repl-"..current_replication.name.."\" requires \""..current_prerequisite.target.."\" as a prerequisite, but \""..current_prerequisite.target.."\" is not a real technology.  The prerequisite was dropped.")
				end
			else
				--Log the mistake
				if current_prerequisite.type then
					log("\"repl-"..current_replication.name.."\" has a \""..current_prerequisite.type.."\" prerequisite named \""..current_prerequisite.target.."\".  There is no such thing as a \""..current_prerequisite.type.."\" prerequisite.  It's probably just a typo but the DMR mod can't figure things out on its own.")
				else
					log("\"repl-"..current_replication.name.."\" has a prerequisite named \""..current_prerequisite.target.."\" which does not have a type.")
				end
			end
		end
		
		--Remove any recursive or repeated prerequisites
		for i=#prerequisite_strings, 1, -1 do
			if prerequisite_strings[i] == "repl-"..current_replication.name then
				table.remove(prerequisite_strings, i)
			else
				for j=#prerequisite_strings, i+1, -1 do
					if prerequisite_strings[i] == prerequisite_strings[j] then
						table.remove(prerequisite_strings, j)
					end
				end
			end
		end
		
		--Save the prerequisites of the replication in place of the table
		current_replication.prerequisites = prerequisite_strings
	end
end
