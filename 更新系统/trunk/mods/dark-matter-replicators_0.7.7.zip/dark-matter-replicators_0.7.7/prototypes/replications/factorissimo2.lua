--Factorissimo 2
--The different internal names are so that numerical icons like those used with upgrades do not appear on the technology icons
repltech_recipe("factory-1", "device3", {internal_name = "factory-a"})
repltech_recipe("factory-2", "device4", {internal_name = "factory-b"})
repltech_recipe("factory-3", "device5", {internal_name = "factory-c"})