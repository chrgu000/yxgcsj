--Angel's mods machines
--replvar("category", number)

if angelsmods.refining then
	--TODO
	if angelsmods.petrochem then
		--TODO
	end
end