require "edits.base"
require "edits.items"
require "edits.technology"
require "edits.cleanbase"
require "edits.recipe"

require "prototypes.ammo-category"
require "prototypes.damage-type"
require "prototypes.explosions"
require "prototypes.item-subgroups"
require "prototypes.recipe-category"
require "prototypes.resource-category"
require "prototypes.gui-style"

require "prototypes.enemy.special"
require "prototypes.enemy.base"
require "prototypes.enemy.defense"
require "prototypes.enemy.units"
require "prototypes.enemy.items"

require("prototypes.player.buildings")
require("prototypes.player.items")
require("prototypes.player.fluid")
require("prototypes.player.cars")
require("prototypes.player.robots")
require("prototypes.player.observer")
require("prototypes.player.settile")
require("prototypes.player.fish-farm")

require("prototypes.player.character")
require("prototypes.player.weapons.guns")
require("prototypes.player.weapons.ammo")
require("prototypes.player.weapons.projectile")
require("prototypes.player.transport-to-ground")
require("prototypes.player.turrets")

require("prototypes.recipe.ammo")
require("prototypes.recipe.compressor")
require("prototypes.recipe.electrolizer")
require("prototypes.recipe.grinder")
require("prototypes.recipe.gun")
require("prototypes.recipe.turrets")
require("prototypes.recipe.cars")
require("prototypes.recipe.robots")
require("prototypes.recipe.other")

require("prototypes.technology.all")
require("prototypes.technology.heavy")
require("prototypes.technology.762x39")
require("prototypes.technology.556x45")
require("prototypes.technology.127x99")
require("prototypes.technology.laser")
require("prototypes.technology.plasma")
require("prototypes.technology.upgrade")
