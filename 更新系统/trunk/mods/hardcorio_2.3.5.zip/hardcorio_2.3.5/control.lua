global.ch = {}
global.bases = {{},{},108000}
global.units = {}
global.df = {0,"none",1,0,1,0}
global.targets = {{},{}}
global.players = {}
global.livesystem = {0,0,0,{},0}
global.time = {0,0,0,0,0}
global.ship = {nil,nil,0,0}
global.lzrs = {{},{},{}}
global.guns = {{},{},{},{},{},{}}
global.group = {{120*120,0},{},{},{}} --timer/points/group/units
global.turrets = {{{},{}},{{},{}}}
global.expirience = {}
global.counters = 0
global.observ = {{},{},{1,0,{}}}
global.abomb = {{},{}}
global.fishfarm = {{},{},{}}

local colr = {green={r=0.1,g=0.8,b=0.1},yellow={r=0.9,g=0.9},red={r=1,g=0.2,b=0.3}}

	--function
	
local function disableTechnologies(player)
	local technologylist = player.force.technologies
	--technologylist["flying"].enabled = false
	--technologylist["explosives"].enabled = false
	technologylist["laser"].enabled = false
	technologylist["laser-turrets"].enabled = false
	technologylist["laser-turrets"].enabled = false
	technologylist["military"].enabled = false
	technologylist["military-2"].enabled = false
	technologylist["military-3"].enabled = false
	technologylist["military-4"].enabled = false
	technologylist["flammables"].enabled = false
	technologylist["flamethrower"].enabled = false
	--technologylist["rocket-speed-1"].enabled = false
	--technologylist["rocket-speed-2"].enabled = false
	--technologylist["rocket-speed-3"].enabled = false
	--technologylist["rocket-speed-4"].enabled = false
	--technologylist["rocket-speed-5"].enabled = false
	--technologylist["rocket-speed-6"].enabled = false
	--technologylist["rocket-speed-7"].enabled = false
	technologylist["rocket-damage-1"].enabled = false
	technologylist["rocket-damage-2"].enabled = false
	technologylist["rocket-damage-3"].enabled = false
	technologylist["rocket-damage-4"].enabled = false
	technologylist["rocket-damage-5"].enabled = false
	technologylist["rocket-damage-6"].enabled = false
	technologylist["rocket-damage-7"].enabled = false
	technologylist["bullet-damage-1"].enabled = false
	technologylist["bullet-damage-2"].enabled = false
	technologylist["bullet-damage-3"].enabled = false
	technologylist["bullet-damage-4"].enabled = false
	technologylist["bullet-damage-5"].enabled = false
	technologylist["bullet-damage-6"].enabled = false
	technologylist["bullet-damage-7"].enabled = false
	technologylist["bullet-speed-1"].enabled = false
	technologylist["bullet-speed-2"].enabled = false
	technologylist["bullet-speed-3"].enabled = false
	technologylist["bullet-speed-4"].enabled = false
	technologylist["bullet-speed-5"].enabled = false
	technologylist["bullet-speed-6"].enabled = false
	technologylist["laser-turret-damage-1"].enabled = false
	technologylist["laser-turret-damage-2"].enabled = false
	technologylist["laser-turret-damage-3"].enabled = false
	technologylist["laser-turret-damage-4"].enabled = false
	technologylist["laser-turret-damage-5"].enabled = false
	technologylist["laser-turret-damage-6"].enabled = false
	technologylist["laser-turret-damage-7"].enabled = false
	technologylist["laser-turret-damage-8"].enabled = false
	technologylist["laser-turret-speed-1"].enabled = false
	technologylist["laser-turret-speed-2"].enabled = false
	technologylist["laser-turret-speed-3"].enabled = false
	technologylist["laser-turret-speed-4"].enabled = false
	technologylist["laser-turret-speed-5"].enabled = false
	technologylist["laser-turret-speed-6"].enabled = false
	technologylist["laser-turret-speed-7"].enabled = false
	technologylist["shotgun-shell-damage-1"].enabled = false
	technologylist["shotgun-shell-damage-2"].enabled = false
	technologylist["shotgun-shell-damage-3"].enabled = false
	technologylist["shotgun-shell-damage-4"].enabled = false
	technologylist["shotgun-shell-damage-5"].enabled = false
	technologylist["shotgun-shell-damage-6"].enabled = false
	technologylist["shotgun-shell-damage-7"].enabled = false
	technologylist["shotgun-shell-speed-1"].enabled = false
	technologylist["shotgun-shell-speed-2"].enabled = false
	technologylist["shotgun-shell-speed-3"].enabled = false
	technologylist["shotgun-shell-speed-4"].enabled = false
	technologylist["shotgun-shell-speed-5"].enabled = false
	technologylist["shotgun-shell-speed-6"].enabled = false
	technologylist["cannon-shell-damage-1"].enabled = false
	technologylist["cannon-shell-damage-2"].enabled = false
	technologylist["cannon-shell-damage-3"].enabled = false
	technologylist["cannon-shell-damage-4"].enabled = false
	technologylist["cannon-shell-damage-5"].enabled = false
	technologylist["cannon-shell-damage-6"].enabled = false
	technologylist["cannon-shell-speed-1"].enabled = false
	technologylist["cannon-shell-speed-2"].enabled = false
	technologylist["cannon-shell-speed-3"].enabled = false
	technologylist["cannon-shell-speed-4"].enabled = false
	technologylist["cannon-shell-speed-5"].enabled = false
	technologylist["gun-turret-damage-1"].enabled = false
	technologylist["gun-turret-damage-2"].enabled = false
	technologylist["gun-turret-damage-3"].enabled = false
	technologylist["gun-turret-damage-4"].enabled = false
	technologylist["gun-turret-damage-5"].enabled = false
	technologylist["gun-turret-damage-6"].enabled = false
	technologylist["gun-turret-damage-6"].enabled = false
	technologylist["combat-robot-damage-1"].enabled = false
	technologylist["combat-robot-damage-2"].enabled = false
	technologylist["combat-robot-damage-3"].enabled = false
	technologylist["combat-robot-damage-4"].enabled = false
	technologylist["combat-robot-damage-5"].enabled = false
	technologylist["combat-robot-damage-6"].enabled = false
	technologylist["grenade-damage-1"].enabled = false
	technologylist["grenade-damage-2"].enabled = false
	technologylist["grenade-damage-3"].enabled = false
	technologylist["grenade-damage-4"].enabled = false
	technologylist["grenade-damage-5"].enabled = false
	technologylist["grenade-damage-6"].enabled = false
	technologylist["grenade-damage-7"].enabled = false
	technologylist["flamethrower-damage-1"].enabled = false
	technologylist["flamethrower-damage-2"].enabled = false
	technologylist["flamethrower-damage-3"].enabled = false
	technologylist["flamethrower-damage-4"].enabled = false
	technologylist["flamethrower-damage-5"].enabled = false
	technologylist["flamethrower-damage-6"].enabled = false
	technologylist["flamethrower-damage-6"].enabled = false
	technologylist["flamethrower-damage-7"].enabled = false
	technologylist["uranium-ammo"].enabled = false
	technologylist["atomic-bomb"].enabled = false
	--technologylist["power-armor"].enabled = false
	--technologylist["power-armor-2"].enabled = false
	--technologylist["energy-shield-mk2-equipment"].enabled = false
	--technologylist["basic-exoskeleton-equipment"].enabled = false
	--technologylist["battery-mk2-equipment"].enabled = false
	--technologylist["fusion-reactor-equipment"].enabled = false
	technologylist["personal-laser-defense-equipment"].enabled = false
	technologylist["discharge-defense-equipment"].enabled = false
	technologylist["turrets"].enabled = false
	technologylist["stack-inserter"].enabled = false
end

local function migration ()
	if global.migration ~= 3 then
		if global.guns[2][1] ~= "rpg" then
			global.guns = 
			{
				{"regenerator"},
				{"rpg"},
				{"new-shotgun","plasma-shotgun"},
				{"m82","scopem82","plasma-sniper"},
				{"rpk74","minigun","plasma-gun"},
				{"ak47","m60","laser-rifle","gauss-rifle"}
			}
			
			local expe = {}
			for i = 1, #global.expirience do
				local j = global.expirience[i]
				table.insert(expe, {j[1][1]+j[1][2],
					{
						j[2][1],
						j[2][10],
						math.ceil((j[2][2]+j[2][14])/2),
						math.ceil((j[2][5]+j[2][8]+j[2][11])/3),
						math.ceil((j[2][6]+j[2][7]+j[2][13])/3),
						math.ceil((j[2][3]+j[2][4]+j[2][9]+j[2][12])/4),
						0
					},
					{
						j[3][1],
						j[3][10],
						math.ceil((j[3][2]+j[3][14])/2),
						math.ceil((j[3][5]+j[3][8]+j[3][11])/3),
						math.ceil((j[3][6]+j[3][7]+j[3][13])/3),
						math.ceil((j[3][3]+j[3][4]+j[3][9]+j[3][12])/4),
						0
					}
				})
			end
			global.expirience = expe
		end
		if global.migration == nil then
			for _,u in pairs (global.group[4]) do
				if u[1] == "queen" then u[1] = "utsk" else u[1] = string.sub(u[1],1,4) end
			end
			if global.group[3][2] ~= nil then
				for _,u in pairs (global.group[3][2]) do
					if u[2][1] == "queen" then u[2][1] = "utsk" else u[2][1] = string.sub(u[2][1],1,4) end
				end
			end
			for _,u in pairs (global.units) do
				if u[3] ~= nil then
					if u[3][1] == "queen" then u[3][1] = "utsk" else u[3][1] = string.sub(u[3][1],1,4) end
				end
			end
			if #global.bases[2] > 0 then
				for i = 1, #global.bases[2] do
					local base = global.bases[2][i]
					for _,j in pairs (base[5]) do
						for _,u in pairs (j[3]) do
							u[1] = string.sub(u[1],1,4)
						end
						for _,u in pairs (j[4]) do
							u[2][1] = string.sub(u[2][1],1,4)
						end
					end
					for _,u in pairs (base[7]) do
						u[3][1] = string.sub(u[3][1],1,4)
					end
				end
			end
			global.fr = nil
			global.temp = nil
			global.migration = 1
		end
		if global.migration ~= 2 then
			if global.fishfarm == nil then global.fishfarm = {{},{},{}} end
			for _,j in pairs (global.fishfarm[3]) do
				if j[1].name == "fish-1" then j[1].name = "tiny-fish"
				elseif j[1].name == "fish-2" then j[1].name = "small-fish"
				end
			end
			global.migration = 2
		end
		if global.migration ~= 3 then
			global.migration = 3
		end
		for _,player in pairs(game.players) do
			disableTechnologies(player)
		end
	end
end

local function find_random_point(pos, radius, ent, dist, acur)
	local rp = {x = (pos.x - radius + (math.random(radius*200)/100)), y = (pos.y - radius + (math.random(radius*200)/100))}
	return game.surfaces[1].find_non_colliding_position(ent, rp, dist, acur)
end

local function distance(position1, position2)
  return ((position1.x - position2.x)^2 + (position1.y - position2.y)^2)^0.5
end

local function button(name, caption, place, color, miw, maw, mah, tp)
	local botton = place.add{name=name, type="button", caption = caption, style = "hardcorio_button_style"}
	botton.style.font_color = color
	botton.style.minimal_width = miw
	botton.style.maximal_width = maw
	botton.style.maximal_height = mah
	botton.style.top_padding = tp
end

local function show_skills(p)
	local skill = global.expirience[p]
	for i = 1,7 do
		if skill[3][i] > 0 then
			game.players[p].print({"skill-up-"..i,skill[3][i]})
		end
	end
end

local function drop_skills(p)
	local skill = global.expirience[p]
	for i = 1,7 do
		skill[2][i] = 0
		if skill[3][i] > 0 then
			skill[3][i] = skill[3][i] - 1
			game.players[p].print({"skill-up-"..i,skill[3][i]})
		end
	end
end

	--live-system

local function live_system_recharge(p,player,live)
	for i,t in ipairs(global.livesystem[4]) do
		if not t.valid then
			table.remove(global.livesystem[4], i)
		elseif t.fluidbox[1] ~= nil then
			local ant = t.fluidbox[1].amount
			local fluid = t.fluidbox[1]
			if ant > 0 then
				if fluid.name ~= "oxygen" and fluid.name ~= "pure-water" and fluid.name ~= "biomass-food" then
					fluid = nil
				elseif fluid~= nil then
					if math.sqrt((player.character.position.x-t.position.x)^2+(player.character.position.y-t.position.y)^2) < 3 then
						if fluid.name == "oxygen" then
							local cnt = player.get_item_count("air-tank")
							if cnt < 100 and ant > 21.6+(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant-(21.6+(2.16*global.livesystem[1]))}
								player.insert({name = "air-tank", count = 1})
							elseif cnt > 100 and ant < 24978.4-(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant+(21.6+(2.16*global.livesystem[1]))}
								player.remove_item({name = "air-tank", count = 1})
							end
						elseif fluid.name == "pure-water" then
							local cnt = player.get_item_count("water-tank")
							if cnt < 100 and ant > 21.6+(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant-(21.6+(2.16*global.livesystem[1]))}
								player.insert({name = "water-tank", count = 1})
							elseif cnt > 100 and ant < 24978.4-(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant+(21.6+(2.16*global.livesystem[1]))}
								player.remove_item({name = "water-tank", count = 1})
							end
						elseif fluid.name == "biomass-food" then
							local cnt = player.get_item_count("food-tank")
							if cnt < 100 and ant > 21.6+(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant-(21.6+(2.16*global.livesystem[1]))}
								player.insert({name = "food-tank", count = 1})
							elseif cnt > 100 and ant < 24978.4-(2.16*global.livesystem[1]) then
								t.fluidbox[1] = {name=fluid.name, amount=ant+(21.6+(2.16*global.livesystem[1]))}
								player.remove_item({name = "food-tank", count = 1})
							end
						end
					end
				end
			end
		end
	end
end

local function live_penalty(p,player,live)
	local air = player.get_item_count("air-tank")
	local water = player.get_item_count("water-tank")
	local food = player.get_item_count("food-tank")
	if live[4][5] and air > 20 then live[4][5] = false end
	if live[4][6] and water > 20 then live[4][6] = false end
	if live[4][7] and food > 20 then live[4][7] = false end
	if live[4][8] and air > 40 then live[4][8] = false end
	if live[4][9] and water > 40 then live[4][9] = false end
	if live[4][10] and food > 40 then live[4][10] = false end
	if air < 1 and live[4][1] <= 0 or water < 1 and live[4][2] <= 0 or food < 1 and live[4][3] <= 0 then
		player.character.die()
	elseif air < 1 or water < 1 or food < 1 then
		if air < 1 and not live[4][5] then
			player.print({"air-level-is-critical"})
			live[4][5] = true
		end
		if water < 1 and not live[4][6] then
			player.print({"water-level-is-critical"})
			live[4][6] = true
		end
		if food < 1 and not live[4][7] then
			player.print({"food-level-is-critical"})
			live[4][7] = true
		end
		if live[4][1] < 1000 or live[4][2] < 1000 or live[4][3] < 1000 then
			player.character.damage(1, game.forces.neutral, "self")
		end
	elseif air < 20 or water < 20 or food < 20 then
		if air < 20 and not live[4][8] then
			player.print({"air-level-is-low"})
			live[4][8] = true
		end
		if water < 20 and not live[4][9] then
			player.print({"water-level-is-low"})
			live[4][9] = true
		end
		if food < 20 and not live[4][10] then
			player.print({"food-level-is-low"})
			live[4][10] = true
		end
	end
end

local function live_system()
	for p,live in pairs(global.players) do
		local player = game.players[p]
		if player ~= nil and player.connected then
			if player.controller_type == 1 then
				if  player.character.name ~= "player"  then
					live_system_recharge(p,player,live)
					if math.sqrt((player.character.position.x-live[4][4].x)^2+(player.character.position.y-live[4][4].y)^2) ~= 0 then
						live[4][4] = player.character.position
						if player.vehicle or not player.walking_state.walking then live[4][1] = live[4][1]-3
							live[4][2] = live[4][2]-1
						else live[4][1] = live[4][1]-8
							live[4][2] = live[4][2]-3
						end
						live[4][3] = live[4][3]-1
					else
						live[4][1] = live[4][1]-0.3
						live[4][2] = live[4][2]-0.2
						live[4][3] = live[4][3]-0.1
					end
					if player.mining_state.mining then
						live[4][1] = live[4][1]-3
						live[4][2] = live[4][2]-2
						live[4][3] = live[4][3]-1
					end
					if player.crafting_queue_size > 0 then
						live[4][1] = live[4][1]-1
						live[4][2] = live[4][2]-2
						live[4][3] = live[4][3]-3
					end
					if player.character.health < 30 then
						live[4][1] = live[4][1]-3
						live[4][2] = live[4][2]-12
						live[4][3] = live[4][3]-6
					elseif player.character.health < 90 then
						live[4][1] = live[4][1]-3
						live[4][2] = live[4][2]-9
						live[4][3] = live[4][3]-5
					elseif player.character.health < 120 then
						live[4][1] = live[4][1]-3
						live[4][2] = live[4][2]-6
						live[4][3] = live[4][3]-4
					end
					
					if live[4][1] <= 2000 and player.get_item_count("air-tank") > 0 then
						live[4][1] = live[4][1]+2160+(216*global.livesystem[1])
						player.remove_item({name = "air-tank", count = 1})
					elseif live[4][2] <= 2000 and player.get_item_count("water-tank") > 0 then
						live[4][2] = live[4][2]+2160+(216*global.livesystem[2])
						player.remove_item({name = "water-tank", count = 1})
					elseif live[4][3] <= 2000 and player.get_item_count("food-tank") > 0 then
						live[4][3] = live[4][3]+2160+(216*global.livesystem[3])
						player.remove_item({name = "food-tank", count = 1})
					end
					live_penalty(p,player,live)
				elseif live[5] ~= "none" then
					player.character.destroy()
					player.character = game.surfaces[1].create_entity{name = live[5], position = game.surfaces[1].find_non_colliding_position("co01", global.ship[1].position, 1000, 1), force =  game.forces.player}
					if #global.players > global.livesystem[5] then
						player.insert({name = "air-tank", count = 100})
						player.insert({name = "water-tank", count = 100})
						player.insert({name = "food-tank", count = 100})
						player.insert({name = "iron-axe", count = 5})
						show_skills(p)
						global.livesystem[5] = global.livesystem[5] + 1
					else
						live[4][1] = 4160+(216*global.livesystem[1])
						live[4][2] = 4160+(216*global.livesystem[2])
						live[4][3] = 4160+(216*global.livesystem[3])
						player.insert({name = "air-tank", count = 25})
						player.insert({name = "water-tank", count = 25})
						player.insert({name = "food-tank", count = 25})
						player.insert({name = "iron-axe", count = 1})
						drop_skills(p)
					end
				end
			end
		end
	end
end

local function live_research(research)
	if string.sub(research,1,9) == "oxy-upgr-" then
		global.livesystem[1] = global.livesystem[1]+1
	elseif string.sub(research,1,11) == "water-upgr-" then
		global.livesystem[2] = global.livesystem[2]+1
	elseif string.sub(research,1,10) == "food-upgr-" then
		global.livesystem[3] = global.livesystem[3]+1
	end
end



	--group

local function group_main()
	if global.df[3] ~= 0 then
		if global.group[1][1] > 0 and #global.group[4] > 0 then
			global.group[1][1]  = global.group[1][1] - 1
		end
		
		if global.group[1][2] == 0 and global.group[1][1] == 0 then
			global.group[1][2] = 1
		elseif global.group[1][2] == 0 and global.group[1][1] > 0 and 3*#global.group[4] > 2*global.df[1]*#global.bases[2] then
			global.group[1][1] = 0
		end
	end
	
	if global.group[1][2] == 1 then
		repeat
			local well = false
			local roll = math.random(#global.targets[1])
			if global.targets[1][roll].valid then
				global.group[2][2] = global.targets[1][roll].position
				well = true
			else table.remove(global.targets[1], roll) end
		until well
		global.group[2][1] = global.bases[2][math.random(#global.bases[2])][1].position
		global.group[1][2] = 2
	end
	
	if global.group[1][2] == 2 then
		local pos1 = global.group[2][1]
		local pos2 = global.group[2][2]
		if math.sqrt((pos1.x-pos2.x)^2+(pos1.y-pos2.y)^2) > 40 then
			global.group[2][1].x = pos1.x-((pos1.x-pos2.x)/math.sqrt((pos1.x-pos2.x)^2+(pos1.y-pos2.y)^2))*1
			global.group[2][1].y = pos1.y-((pos1.y-pos2.y)/math.sqrt((pos1.x-pos2.x)^2+(pos1.y-pos2.y)^2))*1
		else
			global.group[1][2] = 1
		end
		local target = game.surfaces[1].count_entities_filtered{force = "player", area = {{pos1.x-40,pos1.y-40},{pos1.x+40,pos1.y+40}}, limit=1}
		if target > 0 then
			global.group[1][2] = 1
		else 
			target = game.surfaces[1].find_entities_filtered{force = "player", area = {{pos1.x-80,pos1.y-80},{pos1.x+80,pos1.y+80}}, limit=1}
			if #target > 0 and game.surfaces[1].find_non_colliding_position("hi01", pos1, 5, 1) ~= nil then
				for _,t in pairs(target) do
					if not t.valid then break
					else
						global.group[2][3] = t.position
						if global.group[3][1] ~= nil then
							if global.group[3][1].valid then
								for y,u in ipairs(global.units) do
									if not u[1].valid then
										table.remove(global.units, y)
									elseif u[3] ~= nil then
										table.insert(global.group[4], {u[3][1],1,u[3][3]})
										u[1].destroy()
									end
								end
								global.group[3][1].destroy()
								for i = 1, (global.group - 4) do
									local n = #global.group - i + 1
									if not global.group[n].valid then
										table.remove(global.group, n)
									end
								end
							end
						end
						global.group[3][1] = game.surfaces[1].create_unit_group{position = game.surfaces[1].find_non_colliding_position("su01", pos1, 1000, 1)}
						global.group[3][2] = {}
						local tier = math.ceil(global.df[5]/5)
						for _,b in ipairs(global.group[4]) do
							local rp = find_random_point(global.group[3][1].position, 0.1*#global.group[4], b[1]..tier, 1000, 1)
							if rp ~= nil then
								local ent = game.surfaces[1].create_entity{name = "egg", position = rp, force =  game.forces.neutral}
								table.insert(global.group[3][2], {ent,b})
								ent.health = math.random(2*global.df[1])
							end
						end
						global.group[1][2] = 3
					end
				end
			end
		end
	end
	
	if global.group[1][2] == 3 and #global.group[3][2] > 0 then
		if global.group[1][3] == nil then
			local roll = math.random(5)
			if roll == 1 then global.group[1][3] = 0
			else global.group[1][3] = math.random(30, 150)
			end
		end
		for i,b in ipairs(global.group[3][2]) do
			if not b[1].valid then
				table.remove(global.group[3][2], i)
			elseif b[1].valid and b[1].health >= 100 then
				for u = 1,b[2][2] do
					local tier = math.ceil(global.df[5]/5)
					local ent = game.surfaces[1].create_entity{name = b[2][1]..tier, position = game.surfaces[1].find_non_colliding_position(b[2][1]..tier, b[1].position, 1000, 1), force =  game.forces.enemy}
					table.insert(global.units, {ent, b[2][3], b[2]})
					if global.group[1][3] == 0 then
						ent.set_command({type=defines.command.attack_area, destination = global.group[2][3], radius=15 ,distraction=defines.distraction.by_enemy})
					else
					--[[if string.sub(ent.name,1,4) == "scrg" then
						global.group[3][1].add_member(ent)
					else]]
						local n = 1
						repeat
							local well = false
							if #global.group == n+3 then
								global.group[n+4] = {{},true}
								global.group[n+4][1] = game.surfaces[1].create_unit_group{position = game.surfaces[1].find_non_colliding_position("su01", ent.position, 1000, 1)}
								global.group[n+4][1].add_member(ent)
								well = true
								if #global.group[3][2] <= 1 then
									global.group[n+4][1].set_command({type=defines.command.attack_area, destination = global.group[2][3], radius=15 ,distraction=defines.distraction.by_enemy})
									global.group[n+4][2] = false
								end
							elseif global.group[n+4][2] then
								global.group[n+4][1].add_member(ent)
								well = true
								if #global.group[n+4][1].members == global.group[1][3] or #global.group[3][2] <= 1 then
									global.group[n+4][1].set_command({type=defines.command.attack_area, destination = global.group[2][3], radius=25 ,distraction=defines.distraction.by_enemy})
									global.group[n+4][2] = false
								end
							end
							n = n + 1
						until well
					end
				end
				b[1].die()
				table.remove(global.group[3][2], i)
			end
		end
	elseif global.group[1][2] == 3 and #global.group[3][2] <= 0 then
		global.group[3][1].set_command({type=defines.command.attack_area, destination = global.group[2][3], radius=25 ,distraction=defines.distraction.by_enemy})
		global.group[1] = {120*60+math.random(4*60)+60*20*#global.bases[2],0}
		global.group[2] = {}
		global.group[4] = {}
		--global.group = {{120*60+math.random(60,60*math.ceil(global.df[1]/3))+60*20*#global.bases[2],0},{},{global.group[3][1]},{}}
	end
end



	--enemy-AI
	
local function clear_area(pos)
	if pos ~= nil then
		local ent = game.surfaces[1].find_entities_filtered{area = {{pos.x-5, pos.y-5}, {pos.x+5, pos.y+5}}, type= "tree"}
		for _,e in ipairs(ent) do
			e.destroy()
		end
	end
end

local function add_exp(i,p)
	global.expirience[p][1] = global.expirience[p][1] + i
end

local function unit_die(e)
	local baseidx = nil
	local getres = nil
	local cnt = 0
	local cnt2 = 0
	local pig = 0
	for i = 1,#game.players do
		if game.players[i].connected then pig = pig + 1 end
	end
	local cntpig = 0
	if e.name == "ship-wreak-1" or e.name == "ship-wreak-2" or e.name == "new-ship-sars" or e.name == "new-ship-carcase" then
		for i = 1,#game.players do
			local player = game.players[i]
			player.print("---------------------------------------------")
			player.print({"ship-is-destroyed"})
		end
		game.set_game_state{game_finished=true, player_won=false} 
		return
	elseif e.type == "turret" then
		if string.sub(e.name,1,3) == "co0" or string.sub(e.name,1,3) == "su0" then 
			cnt = math.random(math.ceil(18*global.df[5]))
			cnt2 = math.ceil(21*global.df[5]) - cnt + 1
			getres = 90
		end
	elseif e.type == "unit" then
		if string.sub(e.name,1,4) == "scrg" then
			local tier = math.ceil(global.df[5]/5)
			local pos = e.position
			local ent = game.surfaces[1].create_entity{name = "scourge-boom-explosion"..tier, position = pos, force =  game.forces.enemy}
			local ent2 = game.surfaces[1].find_entities_filtered{area = {{pos.x-3, pos.y-3}, {pos.x+3, pos.y+3}}, force = game.forces.enemy}
			for _,u in ipairs(ent2) do
				if u.valid then u.health = u.health + 2*global.df[5] end		--healing
			end
			cnt = math.random(math.ceil(0.1*global.df[5]))
			cnt2 = math.ceil(0.2*global.df[5]) - cnt + 1
			getres = 10
		elseif e.name == "abomb" then
			local tier = math.ceil(global.df[5]/5)
			local pos = e.position
			local ent = game.surfaces[1].create_entity{name = "baneling-boom-explosion"..tier, position = pos, force =  game.forces.enemy}
			local ent2 = game.surfaces[1].find_entities_filtered{area = {{pos.x-6, pos.y-6}, {pos.x+6, pos.y+6}}, force = game.forces.enemy}
			for _,u in ipairs(ent2) do
				if u.valid then u.health = u.health + 8*global.df[5] end		--healing
			end
		elseif string.sub(e.name,1,4) == "bnlg" then
			local tier = math.ceil(global.df[5]/5)
			local pos = e.position
			local ent = game.surfaces[1].create_entity{name = "baneling-boom-explosion"..tier, position = pos, force =  game.forces.enemy}
			local ent2 = game.surfaces[1].find_entities_filtered{area = {{pos.x-6, pos.y-6}, {pos.x+6, pos.y+6}}, force = game.forces.enemy}
			for _,u in ipairs(ent2) do
				if u.valid then u.health = u.health + 8*global.df[5] end		--healing
			end
			cnt = math.random(math.ceil(0.4*global.df[5]))
			cnt2 = math.ceil(0.5*global.df[5]) - cnt + 1
			getres = 30
		elseif string.sub(e.name,1,4) == "zrlg" or string.sub(e.name,1,4) == "sclg" then 
			cnt = math.random(math.ceil(0.4*global.df[5]))
			cnt2 = math.ceil(0.5*global.df[5]) - cnt + 1
			getres = 30
		elseif string.sub(e.name,1,4) == "hdsk" or string.sub(e.name,1,4) == "roch" then 
			cnt = math.random(math.ceil(1.7*global.df[5]))
			cnt2 = math.ceil(2*global.df[5]) - cnt + 1
			getres = 120
		elseif string.sub(e.name,1,4) == "utsk" or string.sub(e.name,1,4) == "lrkr" then 
			cnt = math.random(math.ceil(5*global.df[5]))
			cnt2 = math.ceil(6*global.df[5]) - cnt + 1
			getres = 300
		elseif string.sub(e.name,1,4) == "dflr" or string.sub(e.name,1,4) == "dvur" then 
			cnt = math.random(math.ceil(7*global.df[5]))
			cnt2 = math.ceil(8*global.df[5]) - cnt + 1
			getres = 300
		elseif e.name == "queen" then 
			cnt = math.random(math.ceil(22*global.df[5]))
			cnt2 = math.ceil(25*global.df[5]) - cnt + 1
			getres = 300
		end
	elseif e.type == "container" then
		if string.sub(e.name,1,3) == "po0" or string.sub(e.name,1,3) == "nu0" or string.sub(e.name,1,3) == "ne0" then 
			cnt = math.random(math.ceil(36*global.df[5]))
			cntpig = math.ceil(10*(41*global.df[5] - cnt + 1)/pig)
			getres = 90
		elseif string.sub(e.name,1,3) == "de0" or string.sub(e.name,1,3) == "mo0" or string.sub(e.name,1,3) == "la0" then 
			cnt = math.random(73*global.df[5])
			cntpig = math.ceil(10*(85*global.df[5] - cnt + 1)/pig)
			getres = 300
		elseif string.sub(e.name,1,3) == "ca0" or string.sub(e.name,1,3) == "ch0" or string.sub(e.name,1,3) == "sp0" or string.sub(e.name,1,3) == "hi0" then 
			cnt = math.random(142*global.df[5])
			cntpig = math.ceil(15*(165*global.df[5] - cnt + 1)/pig)
			getres = 480
		end
	end
	if cnt ~= 0 then
		if cnt2 ~= 0 then
			repeat
				local roll = math.random(#game.players)
				if game.players[roll].connected then
					add_exp(cnt2, roll)
				end
			until game.players[roll].connected
		end
		if cntpig ~= 0 then
			for i = 1,#game.players do
				if game.players[i].connected then add_exp(cntpig, i) end
			end
		end
		if global.ship[1].valid then global.ship[1].insert({name = "enemy-dna", count = cnt}) end
		global.counters = global.counters+1
		if global.df[6] ~= nil then global.df[6] = global.df[6] + cnt + cnt2 + cntpig*pig end
	end
	if getres ~= nil then
		for j,b in pairs(global.bases[2]) do
			if b[1].valid then
				if math.sqrt((e.position.x-b[1].position.x)^2+(e.position.y-b[1].position.y)^2) < 120 then
					baseidx = j
				end
			end
		end
		if baseidx ~= nil then
			global.bases[2][baseidx][4][2] = global.bases[2][baseidx][4][2] + getres
		end
	end
end



	--Control
	
local function ship_create(pos)
	if game.surfaces[1].peaceful_mode then 
		global.df[3] = 0
		game.surfaces[1].peaceful_mode = false
	end
	local posexplosion = {}
	for i=1,50 do
		local pos = find_random_point(pos, 25, "zrlg1", 1000, 1)
		clear_area(pos)
		if math.random(25) == 1 then
			local ent = game.surfaces[1].create_entity{name = "medium-ship-wreck", position = pos, force =  game.forces.neutral}
			ent.health = math.random(150)
			table.insert(posexplosion, pos)
		elseif math.random(10) == 1 then
			local ent = game.surfaces[1].create_entity{name = "small-ship-wreck", position = pos, force =  game.forces.neutral}
			ent.health = math.random(150)
			table.insert(posexplosion, pos)
		--elseif math.random(50) == 1 then
		--	game.surfaces[1].create_entity{name = "big-ship-wreck-grass", position = pos, force =  game.forces.neutral}
		--	table.insert(posexplosion, pos)
		--elseif math.random(5) == 1 then
		--	game.surfaces[1].create_entity{name = "small-ship-wreck-grass", position = pos, force =  game.forces.neutral}
		end
	end
	global.ship[1] = game.surfaces[1].create_entity{name = "ship-wreak-1", position = find_random_point(pos, 1, "ship-wreak-1", 1000, 1), force =  game.forces.player}
	game.forces.player.set_spawn_position(global.ship[1].position,"nauvis")
	global.ship[2] = game.surfaces[1].create_entity{name = "ship-wreak-2", position = find_random_point(global.ship[1].position, 15, "ship-wreak-2", 1000, 1), force =  game.forces.player}
	global.ship[2].set_request_slot({name = "iron-plate", count = 1}, 1)
	global.ship[2].set_request_slot({name = "copper-plate", count = 1}, 3)
	global.ship[2].set_request_slot({name = "iron-plate-block", count = 8}, 2)
	global.ship[2].set_request_slot({name = "copper-plate-block", count = 8}, 4)
	global.ship[2].set_request_slot({name = "steel-plate", count = 8}, 5)
	global.ship[2].set_request_slot({name = "steel-plate-block", count = 100}, 6)
	global.ship[2].set_request_slot({name = "electronic-circuit", count = 3}, 7)
	table.insert(global.targets[1], global.ship[1])
	table.insert(global.targets[1], global.ship[2])
	global.ship[1].health = math.random(50,149)
	global.ship[2].health = math.random(792/math.ceil(global.df[1]/3),1296/math.ceil(global.df[1]/3))
	global.ship[3] = 1
	global.ship[4] = 1500-global.ship[2].health
	table.insert(global.livesystem[4], game.surfaces[1].create_entity{name = "support-tank", position = find_random_point(global.ship[1].position, 5, "check-place", 1000, 1), force =  game.forces.player})
	global.livesystem[4][1].fluidbox[1] = {name="oxygen", amount=math.random(10000,30000)}
	table.insert(global.livesystem[4], game.surfaces[1].create_entity{name = "support-tank", position = find_random_point(global.ship[1].position, 5, "check-place", 1000, 1), force =  game.forces.player})
	global.livesystem[4][2].fluidbox[1] = {name="biomass-food", amount=math.random(2500,7500)}
	table.insert(global.livesystem[4], game.surfaces[1].create_entity{name = "support-tank", position = find_random_point(global.ship[1].position, 5, "check-place", 1000, 1), force =  game.forces.player})
	global.livesystem[4][3].fluidbox[1] = {name="pure-water", amount=math.random(5000,15000)}
	game.forces.enemy.evolution_factor = 0
	global.time = {0,0,0,0,0}
	if #game.players <= 1 then game.show_message_dialog{text = {"msg-intro-hardcorio"}} end
	for _,pos in ipairs(posexplosion) do 
		game.surfaces[1].create_entity{name = "medium-explosion", position = pos, force =  game.forces.enemy}
	end
end

local function new_player_create (idx)
	local player = game.players[idx]
	local pos = player.character.position
	table.insert(global.expirience, {0,{},{}}) --exp\lvl\skills
	for i = 1,7 do
		table.insert(global.expirience[idx][2], 0)
		table.insert(global.expirience[idx][3], 0)
	end
	
	player.color={g=math.random(999)/1000,b=math.random(999)/1000,r=math.random(999)/1000,a=0.9}
	table.insert(global.players, {{},{},{},{4160,4160,4160,pos,false,false,false,false,false,false},"none"}) --oxy/food/water
	if idx == 1 and global.df[2] == "none" then
		global.ship[1] = player.character
		player.gui.top.add({type="frame", name="difficult", caption={"choose-your-destiny"},direction="vertical"})
		player.gui.top.difficult.add{type="table", name="diftable", column_count=2}
		--player.gui.top.diftable.style.horizontal_spacing=30
		local difficultbut = player.gui.top.difficult.diftable.add({type="flow", name="difficultbut",direction="vertical"})
		button("none",{"i-am-a-sucker"},difficultbut,{r = 0.2, g = 0.7, b = 0.9},270,270)
		button("chsd-very-easy",{"very-easy"},difficultbut,{r = 0, g = 0.8, b = 0.8},270,270)
		button("chsd-easy",{"easy"},difficultbut,{r = 0.2, g = 0.5, b = 0.8},270,270)
		button("chsd-normal",{"normal"},difficultbut,{r = 0.3, g = 0.8, b = 0},270,270)
		button("chsd-hard",{"hard"},difficultbut,{r = 0.7, g = 0.5, b = 0.2},270,270)
		button("chsd-hardcorio",{"hardcorio"},difficultbut,{r = 0.8, g = 0.1, b = 0},270,270)
		button("chsd-iddqd",{"iddqd"},difficultbut,{r = 0.8, g = 0, b = 0.6},270,270)
	end
	
	local character = player.gui.center.add({type="frame", name="character", caption={"choose-your-character"},direction="vertical"})
	button("char-support",{"char-support"},character,{r = 0, g = 0.6, b = 0 },230,230)
	button("char-soldier",{"char-soldier"},character,{r = 0.6, g = 0.6, b = 0},230,230)
	button("char-assault",{"char-assault"},character,{r = 0, g = 0.6, b = 0.6},230,230)
	button("char-heavy",{"char-heavy"},character,{r = 0.6, g = 0, b = 0.6},230,230)
	button("char-random",{"char-random"},character,{r = 0, g = 0, b = 0.6},230,230)
	
	player.force.manual_crafting_speed_modifier=0.7+(0.1*global.df[1])
	player.force.manual_mining_speed_modifier=1.7+(0.1*global.df[1])
	player.clear_items_inside()
	disableTechnologies(player)
end



	--base-main

local function base_res(base,index)
	for y,u in ipairs(base[6]) do
		if not u[1].valid then
			table.remove(base[6], y)
		elseif math.random(60) == 1 then
			if not u[2].valid then
				u[2] = game.surfaces[1].create_entity{name = "elerium-ore", position = u[1].position, force =  game.forces.neutral, amount = math.random(3)}
			else
				local cnt = 0
				if math.random(1, u[2].amount) > 250 then cnt = -1
				elseif math.random(1, u[2].amount) < 50 then cnt = 1
				end
				u[2].amount = u[2].amount + cnt
			end
		elseif math.random(9) == 1 and game.surfaces[1].get_pollution({u[1].position.x, u[1].position.y}) > (82-2*global.df[5])*3 then 
			base[4][1] = base[4][1] + (0.9+0.06*global.df[1])
			game.surfaces[1].pollute({u[1].position.x, u[1].position.y}, -(92-2*global.df[5])*3)
		end
	end
	if math.random(10) == 1 then
		for i=1,1+#base[6] do
			base[4][1] = base[4][1] + (0.9+0.06*global.df[1])
		end
	elseif math.random(3) == 1 and game.surfaces[1].get_pollution({base[1].position.x, base[1].position.y}) > 82-2*global.df[5] then 
		base[4][1] = base[4][1] + (0.3+0.02*global.df[1])
		game.surfaces[1].pollute({base[1].position.x, base[1].position.y}, -(92-2*global.df[5]))
	end
	if #base[5] > 0 and base[4][2] < 100 then
		base[4][2] = base[4][2] + (1+(0.05*global.df[1]*#base[5]))
	end
end

local function base_defence(base,index)
	local pig = 0
	for i = 1,#game.players do
		if game.players[i].connected then pig = pig + 1 end
	end
	if base[4][1] > 0 and base[4][2]< 0 then
		base[4][2] = base[4][2] + base[4][1]
		base[4][1] = 0
	end
	if base[3][2] > 0 and not base[3][1].valid then 
		base[3][2] = base[3][2] - 1
	elseif base[3][2] == 0 and not base[3][1].valid then
		base[3][1] = game.surfaces[1].create_entity{name = "queen", position = find_random_point(base[1].position, 10, "ne01", 1000, 1), force =  game.forces.enemy}
		base[3][1].set_command({type=defines.command.wander, radius=25 ,distraction=defines.distraction.by_anything})
		base[3][2] = math.ceil(1080/global.df[1])
	end
	for y,u in ipairs(base[5]) do
		local colony = {}
		if not u[1].valid then
			for q,w in ipairs(u[2]) do
				if w.valid then
					w.die()
				end
			end
			table.remove(base[5], y)
		elseif u[1].valid then
			u[1].health = u[1].health + 20*(3+global.df[1])*(4+pig)*#u[2]		--healing
			for q,w in ipairs(u[2]) do
				if not w.valid then
					table.remove(u[2], q)
				elseif string.sub(w.name,1,3) == "co0" then
					table.insert(colony, w)
				end
			end
			if #u[3] > 0 then
				if #u[4] < global.df[1]/3+#colony and #base[7] < 1.4*global.df[1]*#base[5] then
					local ent = game.surfaces[1].create_entity{name = "egg", position = find_random_point(u[1].position, 5, "su01", 1000, 1), force =  game.forces.neutral}
					ent.health = math.random(2*global.df[1])
					table.insert(u[4], {ent,u[3][1]})
					for q,w in ipairs(colony) do
						local ent = game.surfaces[1].create_entity{name = "egg", position = find_random_point(w.position, 5, "su01", 1000, 1), force =  game.forces.neutral}
						ent.health = math.random(2*global.df[1])
						table.insert(u[4], {ent,u[3][1]})
					end
					table.remove(u[3], 1)
				end
			end
			for q,w in ipairs(u[4]) do
				if not w[1].valid then
					table.remove(u[4], q)
				elseif w[1].health == 100 then
					local tier = math.ceil(global.df[5]/5)
					for i=1,w[2][2] do
						local ent = game.surfaces[1].create_entity{name = w[2][1]..tier, position = find_random_point(w[1].position, 1, w[2][1]..tier, 1000, 1), force =  game.forces.enemy}
						table.insert(base[7], {ent,w[2][4],{w[2][1],1,w[2][3]}})
						ent.set_command({type=defines.command.wander, radius=15 ,distraction=defines.distraction.by_anything})
					end
					w[1].die()
				end
			end
		end
	end
	for y,u in ipairs(base[7]) do
		if not u[1].valid then
			table.remove(base[7], y)
		end
	end
	base[1].health = base[1].health + 20*(3+global.df[1])*(4+pig)*(#base[5]+0.5*#base[6])		--healing
end

local function base_destroy(base,index)
	if base[3][1].valid then base[3][1].die() end
	for y,u in ipairs(base[5]) do
		if u[1].valid then u[1].die() end
		for q,w in ipairs(u[2]) do
			if w.valid then w.die() end
		end
		for q,w in ipairs(u[4]) do
			if w.valid then w.die() end
		end
	end
	for y,u in ipairs(base[6]) do
		if u[1].valid then u[1].die() end
	end
	for y,u in ipairs(base[7]) do
		if u[1].valid then
			if global.df[3] ~= 0 then
				table.insert(global.group[4], u[3])
				u[1].destroy()
			else u[1].die()
			end
		end
	end
	game.forces.enemy.evolution_factor = game.forces.enemy.evolution_factor + 0.002
	table.remove(global.bases[2], index)
end

local function base_peace(base,index)
	if #base[7] > 0 then
		if base[7][1][1].valid then
			base[4][2] = base[4][2] +  base[7][1][2]
			base[7][1][1].destroy()
			table.remove(base[7], 1)
		else table.remove(base[7], 1) end
	end
	if base[3][1].valid then
		base[3][1].destroy()
		base[3][2] = 0
	else base[3][2] = 0 end
end

local function base_ability(base,index,resources,num)
	base[4][1] = base[4][1] - resources
	local tier = math.ceil(global.df[5]/5)
	if num == 1 then
		table.insert(global.group[4], {"zrlg",2,120})
	elseif num == 2 then
		table.insert(global.group[4], {"utsk",1,400})
	elseif num == 3 then
		table.insert(global.group[4], {"dflr",1,500})
	elseif num == 4 then
		repeat
			local well = false
			local roll = math.random(#global.targets[1])
			if global.targets[1][roll].valid then
				local ent = game.surfaces[1].create_entity{name = "abomb", position = base[1].position, force =  game.forces.neutral}
				ent.set_command{type=defines.command.attack, target=global.targets[1][roll], distraction=defines.distraction.by_enemy}
				table.insert(global.units, {ent, 200})
				table.insert(global.targets[2], ent)
				table.insert(global.abomb, ent)
				well = true
			else table.remove(global.targets[1], roll) end
		until well
	end
end

local function base_expand(base,index)
	local lvl = 0
	local cbuilds = 0
	local build = nil
	if string.sub(base[1].name,1,3) == "ne0" then lvl = 1 cbuilds = 8
	elseif string.sub(base[1].name,1,3) == "la0" then lvl = 2 cbuilds = 16
	elseif string.sub(base[1].name,1,3) == "hi0" then lvl = 3 cbuilds = 24 end
	local tier = global.df[5]
	local roll = math.random(5)
	if global.df[3] == 0 and roll == 2 then
		roll = 1
	end
	if roll == 1 and #base[5] < cbuilds then
		local roll = math.random(3*lvl)
		if #base[6] == 0 then roll = 1
		elseif #base[6] >= cbuilds/2 and roll == 1 then roll = math.random(2,3*lvl)
		end
		if global.df[3] == 0 and roll == 6 then roll = math.random(2,5) end
		
		if roll == 1 then build = {200, "ex",base[1].position,25,0}
		elseif roll == 2 then build = {200, "nu0"..tier,base[1].position,25,0}
		elseif roll == 3 then build = {150, "po0"..tier,base[1].position,25,0}
		
		elseif roll == 4 then build = {450, "de0"..tier,base[1].position,25,0}
		elseif roll == 5 then build = {550, "mo0"..tier,base[1].position,25,0}
		elseif roll == 6 then base_ability(base,index,100,1)
		
		elseif roll == 7 then build = {700, "sp0"..tier,base[1].position,25,0}
		elseif roll == 8 then build = {900, "ch0"..tier,base[1].position,25,0}
		elseif roll == 9 then build = {1300, "ca0"..tier,base[1].position,25,0} end
		
	elseif roll == 2 then
		local roll = math.random(lvl)
		
		if roll == 1 then base_ability(base,index,100,1)
		elseif roll == 2 then base_ability(base,index,200,2)
		elseif roll == 3 then
			if math.random(10) == 1 then base_ability(base,index,240,3)
			else base_ability(base,index,90,4)
			end
		end
		
	elseif #base[5] > 0 then
		for i,b in ipairs(base[5]) do
			if #b[2] < lvl then
				local roll = math.ceil(math.random(1+lvl)/2)
				if b[1].valid then
					if b[1].name == "ex" then roll = 1 end
					if roll == 1 then build = {100, "su0"..tier,b[1].position,10,i}
					break
					elseif roll == 2 then build = {200, "co0"..tier,b[1].position,10,i}
					break
					end
				end
			end
		end
	end
	if build ~= nil then
		local rp = find_random_point(build[3], 0.4*build[4]*lvl+0.6*build[4], build[2], 1000, 1)
		clear_area(rp)
		if rp ~= nil and math.sqrt((rp.x-build[3].x)^2+(rp.y-build[3].y)^2) > 6*lvl then
			local ent = game.surfaces[1].create_entity{name = build[2], position = rp, force =  game.forces.enemy}
			base[4][1] = base[4][1] - build[1]
			if build[5] == 0 then
				table.insert(base[5], {ent,{},{},{}})
			else table.insert(base[5][build[5]][2], ent) end
			if build[2] == "ex" then
				local ent2 = game.surfaces[1].create_entity{name = "elerium-ore", position = rp, force =  game.forces.neutral, amount = math.random(10)}
				ent.teleport(ent2.position)
				table.insert(base[6], {ent,ent2})
			end
		end
	end
	if math.random(8) == 1 then
		if #base[5] >= 4 and lvl == 1 then
			base[4][1] = base[4][1] - math.random(550)
			local ent = game.surfaces[1].create_entity{name = "la0"..global.df[5], position = base[1].position, force =  game.forces.enemy}
			for j = 1,50 do clear_area(find_random_point(base[1].position, 100, "dflr1", 15, 1)) end
			base[1].destroy()
			base[1]=ent
		end
		if #base[5] >= 12 and lvl == 2 then
			base[4][1] = base[4][1] - math.random(1500)
			local ent = game.surfaces[1].create_entity{name = "hi0"..global.df[5], position = base[1].position, force =  game.forces.enemy}
			for j = 1,50 do clear_area(find_random_point(base[1].position, 200, "dflr1", 15, 1)) end
			base[1].destroy()
			base[1]=ent
		end
	end
end

local function base_spawn(base,index)
	local unit = nil
	local randb = nil
	repeat 
		randb = math.random(#base[5])
	until base[5][randb][1].valid or #base[5] == 0
	local rspawn = base[5][randb]
	local sname = string.sub(rspawn[1].name,1,3)
	if sname == "po0" and math.random(4) ~= 1 then unit = {60,"zrlg",2,120}
	elseif sname == "po0" then unit = {60,"bnlg",1,120}
	elseif sname == "nu0" and math.random(4) ~= 1 then unit = {60,"scrg",4,120}
	elseif sname == "nu0" then unit = {80,"sclg",1,120}
	elseif sname == "de0" then unit = {225,"hdsk",1,200}
	elseif sname == "mo0" and math.random(3) ~= 1 then unit = {250,"roch",1,200}
	elseif sname == "mo0" then unit = {250,"lrkr",1,200}
	elseif sname == "ch0" then unit = {475,"dvur",1,400}
	elseif sname == "ca0" then unit = {550,"utsk",1,400}
	elseif sname == "sp0" then unit = {650,"dflr",1,500} end
	if #rspawn[3] < 2*global.df[1] and unit ~= nil then
		table.insert(rspawn[3], {unit[2],unit[3],unit[4],unit[1]})
		base[4][2] = base[4][2] - unit[1]
	elseif #rspawn[3] >= 2*global.df[1] and unit ~= nil and global.group[1][2] == 0 then
		base[4][2] = base[4][2] - unit[1]
		if math.random(global.df[1]*2, 30) >= 28 then
			if global.df[3] ~= 0 then
				table.insert(global.group[4], {unit[2],unit[3],unit[4]})
			else base[4][2] = base[4][2] + 2*unit[1]
			end
		end
	end
end

local function base_control(base,index)
	base_res(base,index)
	if base[2][1] then
		base[2][1] = false
		base[2][2] = 120
	end
	if base[2][2] > 0 then
		base[2][2]  = base[2][2]-1
		base_defence(base,index)
	elseif base[2][2] == 0 then
		base_peace(base,index)
	end
	if base[4][1] >= 0 then
		base_expand(base,index)
	end
	if base[4][2] >= 0 and #base[5] > 0 then
		base_spawn(base,index)
	end
end

local function unit_time()
	for y,u in ipairs(global.units) do
		if not u[1].valid then
			table.remove(global.units, y)
		elseif u[2] > 0 and math.random(2) == 1 then u[2] = u[2] - 1
		elseif u[2] <= 0 then
			if u[3] ~= nil then
				table.insert(global.group[4], {string.sub(u[3][1],1,4),1,u[3][3]})
			end
			u[1].destroy()
		end
	end
end

local function flying_text (msg, pos, clr)
	local surface = game.surfaces[1]
	if clr ~= nil then
		surface.create_entity({name="flying-text", position=pos, text=msg, color=clr})
	else 
		surface.create_entity({name="flying-text", position=pos, text=msg})
	end
end

local function ammo_inserting(e,idx)
	local player = game.players[idx]
	local textpos = e.position
	local ammo = nil
	local clr = nil
	local cnt = 0
	local cnt2 = 0
	if e.name == "gun-turret-556x45" then
		local du = player.get_item_count("556x45du")
		local tr = player.get_item_count("556x45tr")
		local ap = player.get_item_count("556x45ap")
		local ep = player.get_item_count("556x45ep")
		
		if du > 0 then ammo = {name = "556x45du", count = du}
		elseif tr > 0 then ammo = {name = "556x45tr", count = tr}
		elseif ap > 0 then ammo = {name = "556x45ap", count = ap}
		elseif ep > 0 then ammo = {name = "556x45ep", count = ep} end
		
		if ammo ~= nil then 
			cnt = math.ceil(ammo.count/(1+player.get_item_count("gun-turret-556x45")))
			if cnt >= 30 then
				cnt = 30
				clr = colr.green
			elseif cnt < 3 and ammo.count <= 3 then
				cnt = ammo.count
				clr = colr.red
			else
				if cnt < 3 then cnt = 3 end
				clr = colr.yellow
			end
			cnt2 = ammo.count - cnt
		end
	elseif e.name == "gun-turret-762x39" then
		local du = player.get_item_count("762x39du")
		local fa = player.get_item_count("762x39fa")
		local ap = player.get_item_count("762x39ap")
		local ep = player.get_item_count("762x39ep")
		
		if du > 0 then ammo = {name = "762x39du", count = du}
		elseif fa > 0 then ammo = {name = "762x39fa", count = fa}
		elseif ap > 0 then ammo = {name = "762x39ap", count = ap}
		elseif ep > 0 then ammo = {name = "762x39ep", count = ep} end
		
		if ammo ~= nil then 
			cnt = math.ceil(ammo.count/(1+player.get_item_count("gun-turret-762x39")))
			if cnt >= 18 then
				cnt = 18
				clr = colr.green
			elseif cnt < 3 and ammo.count <= 3 then
				cnt = ammo.count
				clr = colr.red
			else
				if cnt < 3 then cnt = 3 end
				clr = colr.yellow
			end
			cnt2 = ammo.count - cnt
		end
	elseif e.name == "gun-turret-127x99" then
		local du = player.get_item_count("127x99du")
		local mg = player.get_item_count("127x99mg")
		local he = player.get_item_count("127x99he")
		local ep = player.get_item_count("127x99ep")
		
		if du > 0 then ammo = {name = "127x99du", count = du}
		elseif mg > 0 then ammo = {name = "127x99mg", count = mg}
		elseif he > 0 then ammo = {name = "127x99he", count = he}
		elseif ep > 0 then ammo = {name = "127x99ep", count = ep} end
		
		if ammo ~= nil then 
			cnt = math.ceil(ammo.count/(1+player.get_item_count("gun-turret-127x99")))
			if cnt >= 9 then
				cnt = 9
				clr = colr.green
			elseif cnt < 3 and ammo.count <= 3 then
				cnt = ammo.count
				clr = colr.red
			else
				if cnt < 3 then cnt = 3 end
				clr = colr.yellow
			end
			cnt2 = ammo.count - cnt
		end
	elseif e.name == "turret_missle" then
		local mg = player.get_item_count("105mg")
		local tbc = player.get_item_count("105tbc")
		local he = player.get_item_count("105he")
		
		if mg > 0 then ammo = {name = "105mg", count = mg}
		elseif tbc > 0 then ammo = {name = "105tbc", count = tbc}
		elseif he > 0 then ammo = {name = "105he", count = he} end
		
		if ammo ~= nil then
			cnt = 1
			cnt2 = ammo.count-1
			if cnt2 >= 1 then clr = colr.green else clr = colr.red end
		end
	end
	if ammo ~= nil then
		flying_text({"turret-charged", cnt, game.item_prototypes[ammo.name].localised_name, cnt2 }, textpos, clr)
		game.players[idx].remove_item({name = ammo.name, count = cnt})
		e.get_inventory(1).insert({name = ammo.name, count = cnt})
	else
		flying_text({"out-of-ammo"}, textpos, colr.red)
	end
end

local function build(e,idx)
	if e.type == "mining-drill" or e.type == "basic-mining-drill" or e.type == "ammo-turret" or e.type == "furnace" or e.type == "boiler" or e.type == "generator" or e.type == "radar" or e.type == "container" or e.type == "logistic-container" or e.type == "inserter"  or e.type == "solar-panel"  or e.type == "accumulator"  or e.type == "lab"  or e.type == "player" or e.type == "electric-turret" or e.type == "car" or e.type == "assembling-machine" then
		table.insert(global.targets[1], e)
	end
	if e.name == "support-tank" then
		table.insert(global.livesystem[4], e)
	elseif e.name == "incubator-pump" then
		local incub = game.surfaces[1].create_entity{name = "incubator", position = e.position, force =  game.forces.player}
		e.destroy()
		table.insert(global.fishfarm[1], incub)
	elseif e.name == "feeder" then
		table.insert(global.fishfarm[2], e)	
	elseif e.name == "new-ship-carcase" then
		e.health = 1500
		for y,u in pairs(global.ship[2].get_inventory(1).get_contents()) do
			game.surfaces[1].spill_item_stack(global.ship[2].position, {name = y, count = u})
		end
		global.ship[2].destroy()
		global.ship[2] = e
		global.ship[2].set_request_slot({name = "electronic-circuit", count = 3}, 1)
		global.ship[2].set_request_slot({name = "advanced-circuit", count = 60}, 2)
		global.ship[2].set_request_slot({name = "processing-unit", count = 100}, 3)
		global.ship[2].set_request_slot({name = "lab", count = 60}, 4)
		global.ship[2].set_request_slot({name = "logistic-robot", count = 60}, 5)
		global.ship[2].set_request_slot({name = "construction-robot", count = 60}, 6)
		global.ship[2].set_request_slot({name = "accumulator", count = 5}, 7)
		global.ship[2].set_request_slot({name = "solar-panel", count = 5}, 8)
		global.ship[2].set_request_slot({name = "engine-unit", count = 5}, 9)
		global.ship[2].set_request_slot({name = "electric-engine-unit", count = 5}, 10)
	elseif e.type == "radar" then
		table.insert(global.turrets[1][1], e)
		if e.name == "observer" then
			table.insert(global.observ[1], e)
		end
	elseif e.type == "electric-turret" then
		table.insert(global.lzrs[1], e)
		table.insert(global.lzrs[2], false)
		table.insert(global.lzrs[3], 0)
		table.insert(global.turrets[2][1], e)
	elseif e.type == "ammo-turret" then
		if idx ~= 0 then
			ammo_inserting(e,idx)
		end
		table.insert(global.turrets[2][1], e)
	elseif e.type == "fish" then
		if e.name == "tiny-fish" or e.name == "small-fish" then
			table.insert(global.fishfarm[3], {e, 100, 1000000})
		end
	end
end
			
local function observ_area ()
	for i = 1,2 do
		for j,e in ipairs(global.observ[i]) do
			if not e.valid then
				table.remove(global.observ[i], j)
			else
				if i == 1 and e.energy == 0 then
					table.insert(global.observ[2], e)
					table.remove(global.observ[1], j)
				elseif i == 2 and e.energy > 0 then
					table.insert(global.observ[1], e)
					table.remove(global.observ[2], j)
				end
			end
		end
	end
	for i,e in ipairs(global.observ[1]) do
		local pos = e.position
		local ab = game.surfaces[1].find_entities_filtered{area = {{pos.x-32, pos.y-32}, {pos.x+32, pos.y+32}}, name = "abomb"}
		for j,b in ipairs(ab) do
			b.force = game.forces.enemy
		end
	end
end

local function abom_stealth ()
	for i,e in ipairs(global.abomb[1]) do
		if not e.valid then
			table.remove(global.abomb[1], i)
		else
			e.force = game.forces.neutral
		end
	end
end

local function radars()
	for i,_ in ipairs(global.turrets[1]) do
		for j,e in ipairs(global.turrets[1][i]) do
			if not e.valid then
				table.remove(global.turrets[1][i], j)
			else
				if i == 1 and e.energy == 0 then
					table.insert(global.turrets[1][2], e)
					table.remove(global.turrets[1][1], j)
				elseif i == 2 and e.energy > 0 then
					table.insert(global.turrets[1][1], e)
					table.remove(global.turrets[1][2], j)
				end
			end
		end
	end
	for i,e in ipairs(global.turrets[2][1]) do
		if not e.valid then
			table.remove(global.turrets[2][1], i)
		end
	end
	for i,e in ipairs(global.turrets[2][2]) do
		if not e.valid then
			table.remove(global.turrets[2][2], i)
		end
	end
	if #global.turrets[2][1] > #global.turrets[1][1]*(8-math.ceil(global.df[1]/3)) then
		for i = 1,#global.turrets[2][1]-#global.turrets[1][1]*4 do
			global.turrets[2][1][#global.turrets[2][1]].force = game.forces.neutral
			table.insert(global.turrets[2][2], global.turrets[2][1][#global.turrets[2][1]])
			table.remove(global.turrets[2][1], #global.turrets[2][1])
			break
		end
		for p = 1,#game.players do
			game.players[p].print("------------------------------------------------")
			game.players[p].print({"need-more-working-radars"})
			game.players[p].print("------------------------------------------------")
		end
	end
	if #global.turrets[2][1] < #global.turrets[1][1]*(8-math.ceil(global.df[1]/3)) then
		for i = 1,#global.turrets[1][1]*(8-math.ceil(global.df[1]/3))-#global.turrets[2][1] do
			if #global.turrets[2][2] > 0 then
				global.turrets[2][2][1].force = game.forces.player
				table.insert(global.turrets[2][1], global.turrets[2][2][1])
				table.remove(global.turrets[2][2], 1)
			end
			break
		end
	end
end

local function lasers()
	for i,e in pairs(global.lzrs[1]) do
		if not e.valid then
			table.remove(global.lzrs[1], i)
			table.remove(global.lzrs[2], i)
			table.remove(global.lzrs[3], i)
		elseif e.valid then
			if global.lzrs[2][i] then
				if e.name == "red-laser-turret" and e.energy <= 40000 then
					global.lzrs[2][i] = false
					global.lzrs[3][i] = e.energy
					e.energy = 0
				elseif e.name == "green-laser-turret" and e.energy <= 80000 then
					global.lzrs[2][i] = false
					global.lzrs[3][i] = e.energy
					e.energy = 0
				elseif e.name == "blue-laser-turret" and e.energy <= 120000 then
					global.lzrs[2][i] = false
					global.lzrs[3][i] = e.energy
					e.energy = 0
				elseif e.name == "plasma-turret" and e.energy <= 10000000 then
					global.lzrs[2][i] = false
					global.lzrs[3][i] = e.energy
					e.energy = 0
				end
			elseif global.lzrs[2][i] == false then
				global.lzrs[3][i] = global.lzrs[3][i] + e.energy
				e.energy = 0
				if e.name == "red-laser-turret" and global.lzrs[3][i] >= 750000 then
					global.lzrs[2][i] = true
					e.energy = 3000000
				elseif e.name == "green-laser-turret" and global.lzrs[3][i] >= 1500000 then
					global.lzrs[2][i] = true
					e.energy = 4500000
				elseif e.name == "blue-laser-turret" and global.lzrs[3][i] >= 3000000 then
					global.lzrs[2][i] = true
					e.energy = 6000000
				elseif e.name == "plasma-turret" and global.lzrs[3][i] >= 12000000 then
					global.lzrs[2][i] = true
					e.energy = 15000000
				end
			end
		end
	end
end

local function fish_farm(num)
	local crep = math.ceil(#global.fishfarm[1]/60)
	for k = 1, crep do
		local i = k*num
		local j = global.fishfarm[1][i]
		if j ~= nil then
			if not j.valid then table.remove(global.fishfarm[1], i)
			elseif math.random(2) == 1 then
				local cav = j.get_inventory(1).get_item_count("caviar")
				if cav >= 1 then
					if math.ceil(math.random(3)/2) == 1 then
						local pos = game.surfaces[1].find_non_colliding_position("tiny-fish", j.position, 4, 0.2)
						if pos ~= nil then
							local fish = game.surfaces[1].create_entity{name = "tiny-fish", position = pos, force = game.forces.natural}
							table.insert(global.fishfarm[3], {fish, 100, 1000000}) -- fish, hunger, age
						end
						if math.random(3) == 1 then
							local pos = game.surfaces[1].find_non_colliding_position("tiny-fish", j.position, 4, 0.2)
							if pos ~= nil then
								local fish = game.surfaces[1].create_entity{name = "tiny-fish", position = pos, force = game.forces.natural}
								table.insert(global.fishfarm[3], {fish, 100, 1000000}) -- fish, hunger, age
							end
						end
					end
					j.remove_item({name = "caviar", count = 1})		
				end
			end
		end
	end
	local crep = math.ceil(#global.fishfarm[2]/60)
	for k = 1, crep do
		local i = k*num
		local j = global.fishfarm[2][i]
		if j ~= nil then
			if not j.valid then table.remove(global.fishfarm[2], i)
			elseif math.random(50) == 1 then
				local eat = game.surfaces[1].count_entities_filtered{name = "fish", area = {{j.position.x-2,j.position.y-2},{j.position.x+2,j.position.y+2}}, limit=3}
				if eat >= 1 then
					eat = math.random(eat)
					local cav = j.get_inventory(1).get_item_count("organic-food")
					if cav >= 1 then
						if cav < eat then eat = cav end
						j.remove_item({name = "organic-food", count = eat})
					end
				end
			end
		end
	end
	local crep = math.ceil(#global.fishfarm[3]/60)
	for k = 1, crep do
		local i = k*num
		local j = global.fishfarm[3][i]
		if j ~= nil then
			if not j[1].valid then table.remove(global.fishfarm[3], i)
			else
				if j[2] > 100 then
					local feed = game.surfaces[1].find_entities_filtered{name = "feeder", area = {{j[1].position.x-2,j[1].position.y-2},{j[1].position.x+2,j[1].position.y+2}}, limit = 4}
					for _,f in ipairs(feed) do
						local con = f.get_inventory(1).get_item_count("organic-food")
						if con >= 1 and j[2] > 100 then 
							f.remove_item({name = "organic-food", count = 1})
							j[2] = j[2] - math.random(500,1000)
							j[3] = j[3] - 100
						end
					end
				end
				if j[2] > 200 then
					if j[1].name == "small-fish" then
						local eat = game.surfaces[1].find_entities_filtered{name = "tiny-fish", area = {{j[1].position.x-1,j[1].position.y-1},{j[1].position.x+1,j[1].position.y+1}}, limit = 1}
						if eat ~= nil then
							for _, e in ipairs(eat) do
								if e.valid then 
									e.destroy()
									j[2] = j[2] - math.random(1000,2000)
									j[3] = j[3] - 200
								end
							end
						elseif math.random(3) == 1 then
							j[2] = j[2] - 5
						end
					elseif math.random(3) == 1 then
						j[2] = j[2] - 5
					end
				end
				if j[2] > 400 then
					if math.random(3) == 1 then
						j[2] = j[2] - 15
					elseif j[1].name == "tiny-fish" and math.random(1000) == 1 then
						j[1].destroy()
					end
				end
				if j[2] > 200 then
					j[3] = j[3] - math.random(60,300)
				else
					j[3] = j[3] - math.random(60,3000)
				end
				if j[2] < 500 then j[2] = j[2] + math.random(5) end
				if j[3] < 1 then j[3] = 1 end
				if j[3] < 500000 and math.random(j[3]) == 1 then
					if j[1].name == "tiny-fish" then 
						local pos = game.surfaces[1].find_non_colliding_position("small-fish", j[1].position, 2, 0.2)
						if pos ~= nil then
							local fish = game.surfaces[1].create_entity{name = "small-fish", position = pos, force = game.forces.natural}
							j[1].destroy()
							table.insert(global.fishfarm[3], {fish, j[2] + 100, j[3] + 1000000})
							table.remove(global.fishfarm[3], i)
						end
					elseif j[1].name == "small-fish" then
						local pos = game.surfaces[1].find_non_colliding_position("fish", j[1].position, 2, 0.2)
						if pos ~= nil then
							local fish = game.surfaces[1].create_entity{name = "fish", position = pos, force = game.forces.natural}
							j[1].destroy()
							table.remove(global.fishfarm[3], i)
						end
					end
				end
			end
		end
	end
end

local function skills(p,player)
	if player ~= nil and player.connected then
		if player.controller_type == 1 then
			if player.driving and string.sub(player.vehicle.name,1,8) == "new-tank" then
				local skill = global.expirience[p]
				local tank = player.vehicle
				if skill[2][7] > 60*global.df[1]*1.1^skill[3][7] and skill[3][7] < 100 then
					skill[2][7] = skill[2][7] - 60*global.df[1]*1.1^skill[3][7]
					skill[3][7] = skill[3][7] + 1
					game.players[p].print({"skill-up-"..7,skill[3][7]})
				end
				if math.random(600) == 1 and skill[3][7] < 100 then
					skill[2][7] = skill[2][7] + math.random(global.df[5]*5)
				end
				if skill[1] > 10 and skill[3][7] < 100 then
					skill[2][7] = skill[2][7] + skill[1]
					skill[1] = 0
				end
				if string.sub(tank.name, 9,11) ~= tostring(skill[3][7]) then
					local old = {position = tank.position, speed = tank.speed, orientation = tank.orientation, health = tank.health, itemburn = tank.burner.currently_burning, fuel = tank.burner.remaining_burning_fuel, idx = tank.get_driver(), passengers = tank.get_passenger(), surface = tank.surface, inv1 = tank.get_inventory(1).get_contents(), inv2 = tank.get_inventory(2).get_contents(), inv3 = tank.get_inventory(3).get_contents(), turretorient = tank.relative_turret_orientation}
					tank.destroy()
					tank = old.surface.create_entity{name = "new-tank"..skill[3][7], position = old.position, force =  game.forces.player}
					for y,u in pairs(old.inv1) do
						tank.get_inventory(1).insert({name = y, count = u})
					end
					for y,u in pairs(old.inv2) do
						tank.get_inventory(2).insert({name = y, count = u})
					end
					for y,u in pairs(old.inv3) do
						tank.get_inventory(3).insert({name = y, count = u})
					end
					tank.orientation = old.orientation
					tank.speed = old.speed
					tank.health = old.health
					tank.burner.currently_burning = old.itemburn
					tank.burner.remaining_burning_fuel = old.fuel
					tank.set_driver(old.idx)
					tank.set_passenger(old.passengers)
					tank.relative_turret_orientation = old.turretorient
				end
			else
				local inv = player.get_inventory(defines.inventory.player_guns)
				local skill = global.expirience[p]
				for y = 1,6 do
					if skill[2][y] > 60*global.df[1]*1.1^skill[3][y] and skill[3][y] < 100 then
						skill[2][y] = skill[2][y] - 60*global.df[1]*1.1^skill[3][y]
						skill[3][y] = skill[3][y] + 1
						game.players[p].print({"skill-up-"..y,skill[3][y]})
					end
					for _,u in pairs(global.guns[y]) do
						for j,k in pairs(inv.get_contents()) do
							if string.sub(j,1,string.len(u)) == u then
								if math.random(600) == 1 and skill[3][y] < 100 then
									skill[2][y] = skill[2][y] + math.random(global.df[5]*5)
								end
								if skill[1] > 10 and skill[3][y] < 100 then
									skill[2][y] = skill[2][y] + skill[1]/5
									skill[1] = skill[1] - skill[1]/5
								end
								if string.sub(j, string.len(u)+1,string.len(u)+3) ~= tostring(skill[3][y]) then
									inv.remove({name = j, count = k})
									inv.insert({name = u..skill[3][y], count = k})
								end
								break
							end
						end
					end
				end
			end
		end
	end
end


local function clear_dif (idx)
	game.players[1].gui.left.ch_bar.destroy()
    local player = game.players[1]
	local hidden = player.gui.left.add({type="flow", name="hidden", direction="vertical"})
	button("open-ch-bar",{"open-bar"},player.gui.left.hidden,{r = 0.9, g = 0.6, b = 0.5})
end

local function open_dif (idx)
	game.players[1].gui.left.hidden.destroy()
    local player = game.players[1]
	player.gui.left.add({type="flow", direction="vertical", name="ch_bar"})
	button("hide-ch-bar",{"hide-ch-bar"},player.gui.left.ch_bar,nil,nil,nil,30,0)
	button("cancel-peacemode",{"cancel-peacemode"},player.gui.left.ch_bar,{r = 0.5, g = 0.5, b = 0.7})
	button("change-dif-bott",{"change-difficult"},player.gui.left.ch_bar,{r = 0.7, g = 0.5, b = 0.5})
end

local function botton_dif (idx)
    local player = game.players[idx]
	if player.gui.left.ch_bar.change_difficult == nil then
		local ch_dif = player.gui.left.ch_bar.add({type="frame", name="change_difficult", direction="vertical"})
		if global.df[2] ~= "very-easy" then button("very-easy",{"very-easy"},player.gui.left.ch_bar.change_difficult,{r = 0, g = 0.8, b = 0.8},230,230) end
		if global.df[2] ~= "easy" then button("easy",{"easy"},player.gui.left.ch_bar.change_difficult,{r = 0.2, g = 0.5, b = 0.8},230,230) end
		if global.df[2] ~= "normal" then button("normal",{"normal"},player.gui.left.ch_bar.change_difficult,{r = 0.3, g = 0.8, b = 0},230,230) end
		if global.df[2] ~= "hard" then button("hard",{"hard"},player.gui.left.ch_bar.change_difficult,{r = 0.7, g = 0.5, b = 0.2},230,230) end
		if global.df[2] ~= "hardcorio" then button("hardcorio",{"hardcorio"},player.gui.left.ch_bar.change_difficult,{r = 0.8, g = 0.1, b = 0},230,230) end
		if global.df[2] ~= "iddqd" then button("iddqd",{"iddqd"},player.gui.left.ch_bar.change_difficult,{r = 0.8, g = 0, b = 0.6},230,230) end
	else player.gui.left.ch_bar.change_difficult.destroy ()
	end
end

local function chan_diffic ()
	game.players[1].gui.left.ch_bar.change_difficult.destroy()
	for i = 1,#game.players do
		local player = game.players[i]
		player.print("---------------------------------------------")
		player.print({"you-choose-difficult"})
		player.print({global.df[2]})
		player.print("---------------------------------------------")
		player.force.manual_crafting_speed_modifier=0.7+(0.1*global.df[1])
		player.force.manual_mining_speed_modifier=1.7+(0.1*global.df[1])
	end
end

local function mesage_1()
	for i = 1,#game.players do
		local player = game.players[i]
		player.print("---------------------------------------------")
		player.print({"welcome-to-hardcorio-sc2"})
		player.print({"you-choose-difficult"})
		player.print({global.df[2]})
		
		player.print({"big-thx-to-stix-for-mod"})
		
		player.print("---------------------------------------------")
		player.print({"good-luck"})
		player.print("---------------------------------------------")
	end
end

local function peaceful_cancel()
	global.df[3] = 1
	for i = 1,#game.players do
		local player = game.players[i]
		player.print("---------------------------------------------")
		player.print({"peacemode-canceled"})
		player.print("---------------------------------------------")
	end
end

local function peaceful_activate ()
	if game.surfaces[1].peaceful_mode then 
		global.df[3] = 0
		for i = 1,#game.players do
			local player = game.players[i]
			player.print("---------------------------------------------")
			player.print({"peacemode-enabled"})
			player.print("---------------------------------------------")
		end
		game.surfaces[1].peaceful_mode = false
	end
end

local function peaceful_changes ()
	if global.df[4] == 1 and global.df[3] == 0 and game.players[1].valid then 
		global.df[4] = 0
		local player = game.players[1]
		local left = player.gui.left
		if left.ch_bar == nil then
			left.add({type="flow", direction="vertical", name="ch_bar"})
			button("hide-ch-bar",{"hide-ch-bar"},player.gui.left.ch_bar)
			button("cancel-peacemode",{"cancel-peacemode"},player.gui.left.ch_bar,{r = 0.5, g = 0.5, b = 0.7})
			button("change-dif-bott",{"change-difficult"},player.gui.left.ch_bar,{r = 0.7, g = 0.5, b = 0.5})
		end
	end
end

local function botton(bt, idx)
	if bt.name == "hide-ch-bar" then
		clear_dif (idx)
	elseif bt.name == "open-ch-bar" then
		open_dif (idx)
	elseif bt.name == "cancel-peacemode" then
		global.df[4] = 1
		game.players[idx].gui.left.ch_bar.destroy()
		peaceful_cancel()
	elseif bt.name == "change-dif-bott" then
		botton_dif (idx)
	elseif bt.name == "none" then
		game.players[1].gui.top.difficult.destroy()
		game.set_game_state{game_finished = true, player_won = false}
		return
	elseif bt.name == "chsd-very-easy" then
		global.df[1] = 1
		global.df[2] = "very-easy"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "chsd-easy" then
		global.df[1] = 2
		global.df[2] = "easy"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "chsd-normal" then
		global.df[1] = 3
		global.df[2] = "normal"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "chsd-hard" then
		global.df[1] = 6
		global.df[2] = "hard"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "chsd-hardcorio" then
		global.df[1] = 9
		global.df[2] = "hardcorio"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "chsd-iddqd" then
		global.df[1] = 12
		global.df[2] = "iddqd"
		global.df[4] = 1
		game.players[1].gui.top.difficult.destroy()
		mesage_1()
		ship_create(global.ship[1].position)
	elseif bt.name == "very-easy" then
		global.df[1] = 1
		global.df[2] = "very-easy"
		chan_diffic ()
	elseif bt.name == "easy" then
		global.df[1] = 2
		global.df[2] = "easy"
		chan_diffic ()
	elseif bt.name == "normal" then
		global.df[1] = 3
		global.df[2] = "normal"
		chan_diffic ()
	elseif bt.name == "hard" then
		global.df[1] = 6
		global.df[2] = "hard"
		chan_diffic ()
	elseif bt.name == "hardcorio" then
		global.df[1] = 9
		global.df[2] = "hardcorio"
		chan_diffic ()
	elseif bt.name == "iddqd" then
		global.df[1] = 12
		global.df[2] = "iddqd"
		chan_diffic ()
		
	elseif bt.name == "char-support" then
		global.players[idx][5] = "player-support" global.expirience[idx][3][1] = 20 global.expirience[idx][3][4] = 20
		game.players[idx].print({"you-choose-character"})
		game.players[idx].print({"char-support"})
		game.players[idx].gui.center.character.destroy()
	elseif bt.name == "char-soldier" then
		global.players[idx][5] ="player-soldier" global.expirience[idx][3][4] = 5 global.expirience[idx][3][6] = 20
		game.players[idx].print({"you-choose-character"})
		game.players[idx].print({"char-soldier"})
		game.players[idx].gui.center.character.destroy()
	elseif bt.name == "char-assault" then
		global.players[idx][5] ="player-assault" global.expirience[idx][3][3] = 20 global.expirience[idx][3][6] = 10
		game.players[idx].print({"you-choose-character"})
		game.players[idx].print({"char-assault"})
		game.players[idx].gui.center.character.destroy()
	elseif bt.name == "char-heavy" then
		global.players[idx][5] ="player-heavy" global.expirience[idx][3][2] = 20 global.expirience[idx][3][5] = 20
		game.players[idx].print({"you-choose-character"})
		game.players[idx].print({"char-heavy"})
		game.players[idx].gui.center.character.destroy()
	elseif bt.name == "char-random" then
		local roll = math.random(4)
		if roll == 1 then
			global.players[idx][5] = "player-support" global.expirience[idx][3][1] = 20 global.expirience[idx][3][4] = 20
			game.players[idx].print({"you-choose-character"})
			game.players[idx].print({"char-support"})
		elseif roll == 2 then
			global.players[idx][5] ="player-soldier" global.expirience[idx][3][4] = 5 global.expirience[idx][3][6] = 20
			game.players[idx].print({"you-choose-character"})
			game.players[idx].print({"char-soldier"})
		elseif roll == 3 then
			global.players[idx][5] ="player-assault" global.expirience[idx][3][3] = 20 global.expirience[idx][3][6] = 10
			game.players[idx].print({"you-choose-character"})
			game.players[idx].print({"char-assault"})
		elseif roll == 4 then
			global.players[idx][5] ="player-heavy" global.expirience[idx][3][2] = 20 global.expirience[idx][3][5] = 20
			game.players[idx].print({"you-choose-character"})
			game.players[idx].print({"char-heavy"})
		end
		game.players[idx].gui.center.character.destroy()
	end
end

local function game_goal()
	if global.ship[3] == 1 then
		local inv = global.ship[2].get_inventory(1)
		bonus = 0
		for n,i in pairs(inv.get_contents()) do
			if n == "iron-plate" or n == "copper-plate" then bonus = bonus+1 inv.remove({name = n, count = 1})
			elseif n == "iron-plate-block" or n == "copper-plate-block" or n == "steel-plate" then bonus = bonus+8 inv.remove({name = n, count = 1})
			elseif n == "steel-plate-block" then bonus = bonus+100 inv.remove({name = n, count = 1})
			elseif n == "electronic-circuit" then bonus = bonus+3 inv.remove({name = n, count = 1}) end
		end
		global.ship[2].health = global.ship[2].health+bonus/(100*(global.df[1]*0.4))
		for p=1,#game.players do
			global.ship[5] = "SPACECRAFT CASRCASE"
			global.ship[6] = global.ship[2].health/1500
		end
		if global.ship[2].health >= 1500 then
			global.ship[3] = 2
			for y,u in pairs(inv.get_contents()) do
				game.surfaces[1].spill_item_stack(global.ship[2].position, {name = y, count = u})
			end
			inv.clear()
			inv.setbar(1)
			inv.insert({name = "new-ship-carcase", count = 1})
		end
	end
	if global.ship[3] == 2 and global.ship[2].name == "new-ship-carcase" then
		local inv = global.ship[2].get_inventory(1)
		bonus = 0
		for n,i in pairs(inv.get_contents()) do
			if n == "electronic-circuit" then bonus = bonus+3 inv.remove({name = n, count = 1}) 
			elseif n == "lab" or n == "advanced-circuit" or n == "logistic-robot" or n == "construction-robot" then bonus = bonus+60 inv.remove({name = n, count = 1}) 
			elseif n == "processing-unit" then bonus = bonus+100 inv.remove({name = n, count = 1}) 
			elseif n == "accumulator" or n == "solar-panel" or n == "engine-unit" or n == "electric-engine-unit" then bonus = bonus+5 inv.remove({name = n, count = 1}) end
		end
		global.ship[2].health = global.ship[2].health+bonus/(50*(global.df[1]*0.4))
		for p=1,#game.players do
			global.ship[5] = "SPACECRAFT FRAMEWORK"
			global.ship[6] = global.ship[2].health/3000
		end
		if global.ship[2].health >= 3000 then
			global.ship[3] = 3
			global.ship[4] = 3000
			local ent = game.surfaces[1].create_entity{name = "new-ship-sars", position = global.ship[2].position, force =  game.forces.player}
			table.insert(global.targets[1], ent)
			ent.health = 3000
			for y,u in pairs(inv.get_contents()) do
				game.surfaces[1].spill_item_stack(global.ship[2].position, {name = y, count = u})
			end
			global.ship[2].destroy()
			global.ship[2] = ent
			local inv = global.ship[1].get_inventory(2)
			for n,i in pairs(inv.get_contents()) do
				global.ship[2].insert({name = n, count = i})
			end
			game.forces.player.set_spawn_position(global.ship[1].position,"nauvis")
			global.ship[1].destroy()
			global.ship[1] = ent
		end
	end
	if global.ship[3] == 3 and global.ship[2].health > global.ship[4] then
		local bonus = (global.ship[2].health-global.ship[4])/(100*(global.df[1]*0.4))
		global.ship[2].health = global.ship[4]+bonus
		global.ship[4] = global.ship[2].health
		for p=1,#game.players do
			global.ship[5] = "FINISH ASSEMBLING"
			global.ship[6] = global.ship[2].health/10000
		end
		if global.ship[2].health >= 9999 then
			global.ship[3] = 4
		end
	end
end

		
local function counters()
	for i,player in pairs(game.players) do
		if player.gui.top.hardcorio_main ~= nil then
			player.gui.top.hardcorio_main.destroy()
		end
		player.gui.top.add{type="table", name="hardcorio_main", column_count=2}
		player.gui.top.hardcorio_main.style.horizontal_spacing=30
		player.gui.top.hardcorio_main.add{type="label", name="time_played", caption={"gui-time-played"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="time_played_count", caption=string.format("%d:%02d", global.time[4], global.time[3] % 60), style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="enemy_bases", caption={"gui-enemy-bases"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="enemy_bases_count", caption=#global.bases[2], style="caption_label"}
		--[[player.gui.top.hardcorio_main.add{type="label", name="evolution_factor", caption={"gui-evolution-factor"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="evolution_factor_count", caption=string.format("%0.1f%%", game.forces.enemy.evolution_factor * 100), style="caption_label"}]]
		player.gui.top.hardcorio_main.add{type="label", name="enemy_die", caption={"gui-killed-enemies"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="enemy_die_count", caption=global.counters, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="enemy_dna", caption={"gui-enemy-dna"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="enemy_dna_count", caption=global.ship[1].get_item_count("enemy-dna"), style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="radar", caption={"gui-radar-slots"}, style="caption_label"}
		player.gui.top.hardcorio_main.add{type="label", name="radar_count", caption=#global.turrets[1][1]*(8-math.ceil(global.df[1]/3))-#global.turrets[2][1]-#global.turrets[2][2], style="caption_label"}
		player.gui.top.hardcorio_main.add{type="progressbar", name="oxygen", size = 20, style="hardcorio_progressbar_oxy", value = global.players[i][4][1]/(4160+(216*global.livesystem[1]))}
		local air = player.get_item_count("air-tank")
		local lable_air = player.gui.top.hardcorio_main.add{type="label", name="oxygen-cnt", caption=air, style="caption_label"}
		if air < 20 then
			lable_air.style.font_color = colr.red
			lable_air.caption = lable_air.caption.."  !!!"
		end
		player.gui.top.hardcorio_main.add{type="progressbar", name="water", size = 20, style="hardcorio_progressbar_water", value = global.players[i][4][2]/(4160+(216*global.livesystem[2]))}
		local water = player.get_item_count("water-tank")
		local lable_watar = player.gui.top.hardcorio_main.add{type="label", name="water-cnt", caption=water, style="caption_label"}
		if water < 20 then
			lable_watar.style.font_color = colr.red
			lable_watar.caption = lable_watar.caption.."  !!!"
		end
		player.gui.top.hardcorio_main.add{type="progressbar", name="food", size = 20, style="hardcorio_progressbar_food", value = global.players[i][4][3]/(4160+(216*global.livesystem[3]))}
		local food = player.get_item_count("food-tank")
		local lable_food = player.gui.top.hardcorio_main.add{type="label", name="food-cnt", caption=food, style="caption_label"}
		if food < 20 then
			lable_food.style.font_color = colr.red
			lable_food.caption = lable_food.caption.."  !!!"
		end
	end
end

local function base_create()
	local maxbases = global.df[1] * 4 + 12
	if global.df[2] ~= "none" and #global.bases[2] < maxbases then
		global.bases[3] = global.bases[3] - math.ceil(math.random(global.df[1])^2/6)
		if global.bases[3] <= 0 then
			local rndchunk = math.random(#global.ch)
			local a = global.ch[rndchunk]
			local ac = {x = (a.left_top.x+a.right_bottom.x)/2,y = (a.left_top.y+a.right_bottom.y)/2}
			local bc = 0
			local nbc = 60*20*global.df[1]*#global.bases[2]
			local tilename = game.surfaces[1].get_tile(math.floor(ac.x), math.floor(ac.y)).name
			if tilename == "deepwater" or tilename == "water" then return end
			if math.sqrt((ac.x-global.ship[1].position.x)^2+(ac.y-global.ship[1].position.y)^2) < 250 then return end
			for y,u in pairs(global.bases[2]) do
				if u[1].valid then
					if math.sqrt((ac.x-u[1].position.x)^2+(ac.y-u[1].position.y)^2) < 120 then
						return
					end
					if global.bases[3] <= -nbc and math.sqrt((ac.x-u[1].position.x)^2+(ac.y-u[1].position.y)^2) < 220 then
						bc = bc + 1
					end
				end
			end
			for y,u in pairs(global.targets[1]) do
				if u.valid then
					if math.sqrt((ac.x-u.position.x)^2+(ac.y-u.position.y)^2) < 120 then
						return
					end
					if math.sqrt((ac.x-u.position.x)^2+(ac.y-u.position.y)^2) < 360 then
						bc = bc + 1
					end
				else table.remove(global.targets[1], y)
				end
			end
			if bc > 0 or global.bases[3] <= -10*nbc then
				local rp = {x = (ac.x - 10 + math.random(21)), y = (ac.y - 10 + math.random(21))}
				local ncp =  game.surfaces[1].find_non_colliding_position("check-place2", rp, 100, 1)
				if ncp ~= nil then
					local ent = game.surfaces[1].create_entity{name = "ne0"..global.df[5], position = ncp, force =  game.forces.enemy}
					local ent2 = game.surfaces[1].create_entity{name = "queen", position = ncp, force =  game.forces.enemy}
					table.insert(global.bases[2], {ent,{false,0},{ent2,0},{0-math.random(300,300 + math.ceil(1000/global.df[1])),0},{},{},{},{},{}}) -- base/check/queen/res/spawners/extractors/army
					global.bases[3] = global.bases[3] + nbc + 200
					ent2.destroy()
					for i = 1,#game.players do
						local pos = game.players[i].position
						local sp = {x = (ncp.x - pos.x)/distance(ncp,pos)*20 + pos.x, y = (ncp.y - pos.y)/distance(ncp,pos)*20 + pos.y}
						game.surfaces[1].create_entity{name = "base-scream", position = sp, force =  game.forces.enemy}
					end
				end
			end
		end
	end
end

local function upgrade(ent)
	if ent.valid then
		local newent = game.surfaces[1].create_entity{name = string.sub(ent.name,1,3)..global.df[5], position = ent.position, force =  game.forces.enemy}
		newent.health = ent.health
		ent.destroy()
		ent = newent
	end
end

local function upgrade_base()
	for i = 1, #global.bases[2] do
		if global.bases[2][i][1].valid then
			local ent = game.surfaces[1].create_entity{name = string.sub(global.bases[2][i][1].name,1,3)..global.df[5], position = global.bases[2][i][1].position, force =  game.forces.enemy}
			ent.health = global.bases[2][i][1].health
			global.bases[2][i][1].destroy()
			global.bases[2][i][1] = ent
		end
		for y,u in ipairs(global.bases[2][i][5]) do
			if u[1].valid and string.sub(u[1].name,1,2) ~= "ex" then
				local ent = game.surfaces[1].create_entity{name = string.sub(u[1].name,1,3)..global.df[5], position = u[1].position, force =  game.forces.enemy}
				ent.health = u[1].health
				u[1].destroy()
				u[1] = ent
			end
			for q,def in ipairs(u[2]) do
				if def.valid and tonumber(string.sub(def.name,4,5)) ~= global.df[5] then
					local ent = game.surfaces[1].create_entity{name = string.sub(def.name,1,3)..global.df[5], position = def.position, force =  game.forces.enemy}
					ent.health = def.health
					def.destroy()
					table.insert(u[2], ent)
				end
			end
		end
	end
end

local function difup()
	if global.df[5] < 21 then
		local mad = 0
		local mxd = global.df[5]*5
		for i = 1,mxd do 
			mad = mad + (i)^2
		end
		if global.df[6] >= 2*mad then
			global.df[6] = global.df[6] - 2*mad
			global.df[5] = global.df[5] + 1
			upgrade_base()
		elseif global.df[5] <= 20*game.forces.enemy.evolution_factor then
			global.df[5] = global.df[5] + 1
			upgrade_base()
		end
	elseif global.df[5] == 21 then global.df[6] = nil
	end
end

local function group_live()
	if #global.group > 4 then
		for i = 5, #global.group do
			if global.group[i] ~= nil then 
				if not global.group[i][2] then
					if global.group[i][1].valid then
						if #global.group[i][1].members == 0 then
							global.group[i][1].destroy()
							table.remove(global.group, i)
						end
					else
						table.remove(global.group, i)
					end
				end
			else
				table.remove(global.group, i)
			end
		end
	end
end

local function tick()
	migration ()
	observ_area ()
	lasers()
	radars()
	group_main()
	base_create()
	
	if global.time[5] < 60 then global.time[5] = global.time[5] + 1 else global.time[5] = 1 end
	
	fish_farm(global.time[5])
	
	if #global.bases[2] > 0 then
		if global.bases[2][global.time[5]] ~= nil then
			if not global.bases[2][global.time[5]][1].valid then
				base_destroy(global.bases[2][global.time[5]],global.time[5])
			else base_control(global.bases[2][global.time[5]],global.time[5])
			end
		end
	end
	
	if global.ship[2] ~= nil then
		if global.ship[1].valid and global.ship[2].valid  then 
			game_goal() live_system() counters()  for p = 1, #game.players do skills(p,game.players[p]) end
		end
	end
	
end

local function second()
	unit_time()
	abom_stealth()
	peaceful_activate()
	peaceful_changes()
end

local function minute()
	if global.df[6] ~= nil then 
		difup()
	end
	group_live()
end

local function hour()
end

local function if_can_insert(player, name_item, cnt, textpos, ch_pos_txt)
	local cnt2 = 0
	if ch_pos_txt ~= nil then textpos.y = textpos.y + ch_pos_txt end
	if player.can_insert{name = name_item, count = cnt} then
		player.insert({name = name_item, count = cnt})
		cnt2 = player.get_item_count(name_item)
		flying_text({"item-inserted", cnt, game.item_prototypes[name_item].localised_name, cnt2 }, textpos)
	else
		cnt2 = player.get_item_count(name_item)
		flying_text({"item-not-inserted", cnt, game.item_prototypes[name_item].localised_name, cnt2 }, textpos, colr.red)
	end
end

local function player_mined_item (ent, idx)
	local cnt = 0
	if ent.type == "tree" then
		if math.random(5) == 1 then
			cnt = math.random(5)
			if_can_insert(game.players[idx], "organic-food", cnt, ent.position, 0.5)
		end
	elseif ent.name == "egg" then
		cnt = math.random(10)
		if_can_insert(game.players[idx], "organic-food", cnt, ent.position)
	elseif ent.name == "medium-ship-wreck" then
		cnt = math.random(2,12)
		if_can_insert(game.players[idx], "iron-plate", cnt, ent.position)
		cnt = math.random(14)
		if_can_insert(game.players[idx], "copper-plate", cnt, ent.position, 1)
		cnt = math.random(3)
		if_can_insert(game.players[idx], "steel-plate", cnt, ent.position, 2)
		local roll = math.random(4)
		if roll == 1 then
		cnt = math.random(4)
		if_can_insert(game.players[idx], "iron-gear-wheel", cnt, ent.position, 3)
		elseif roll == 2 then
		cnt = math.random(4)
		if_can_insert(game.players[idx], "pipe", cnt, ent.position, 3)
		elseif roll == 3 then
		cnt = math.random(4)
		if_can_insert(game.players[idx], "electronic-circuit", cnt, ent.position, 3)
		end
	elseif ent.name == "small-ship-wreck" then
		cnt = math.random(5)
		if_can_insert(game.players[idx], "iron-plate", cnt, ent.position)
		cnt = math.random(7)
		if_can_insert(game.players[idx], "copper-plate", cnt, ent.position, 1)
		cnt = math.random(5)
		if_can_insert(game.players[idx], "copper-cable", cnt, ent.position, 2)
		local roll = math.random(10)
		if roll == 1 then
			cnt = math.random(2)
			if_can_insert(game.players[idx], "iron-gear-wheel", cnt, ent.position, 3)
		elseif roll == 2 then
			cnt = math.random(2)
			if_can_insert(game.players[idx], "pipe", cnt, ent.position, 3)
		elseif roll == 3 then 
			cnt = math.random(2)
			if_can_insert(game.players[idx], "electronic-circuit", cnt, ent.position, 3)
		end
	end
end

local function scaning_location(radar)
	if radar.name == "observer" then
		if radar.position ~= global.observ[3][3] then
			global.observ[3][2] = global.observ[3][2] + 1
		end
		global.observ[3][3] = radar.position
	elseif global.observ[3][2] >= 20 then
		if global.observ[3][1] > #global.bases[2] then
			global.observ[3][1] = 1
		end
		if global.observ[3][1] <= #global.bases[2] then
			if #global.turrets[1][1] - #global.observ[1] >= 4 then
				if global.bases[2][global.observ[3][1]][1].valid then
					local ncp = global.bases[2][global.observ[3][1]][1].position
					game.forces.player.chart(game.surfaces[1], {left_top={x=ncp.x-16,y=ncp.y-16},right_bottom={x=ncp.x+16,y=ncp.y+16}})
					global.observ[3][1] = global.observ[3][1] + 1
					global.observ[3][2] = global.observ[3][2] - 20
				end
			end
		end
	end
end

local function trigger_created(e)
	if e.name == "base-check" then
		local pos = e.position
		for i,j in pairs(global.bases[2]) do
			if j[1].valid then
				local pos2 = j[1].position
				if math.sqrt((pos.x-pos2.x)^2+(pos.y-pos2.y)^2) < 100 then global.bases[2][i][2][1] = true end
			end
		end
	elseif e.name == "defiler-trigger" then
		local tier = math.ceil(global.df[5]/5)
		local ent = game.surfaces[1].create_entity{name = "scrg"..tier, position = game.surfaces[1].find_non_colliding_position("scrg"..tier, e.position, 1000, 1), force =  game.forces.enemy}
		repeat
			local well = false
			local roll = math.random(#global.targets[1])
			if global.targets[1][roll].valid then
				ent.set_command{type=defines.command.attack_area, destination = global.targets[1][roll].position, radius=15 ,distraction=defines.distraction.by_enemy}
				table.insert(global.units, {ent, 30})
				well = true
			else table.remove(global.targets[1], roll) end
		until well
	elseif e.name == "devourer-trigger" then
		local pos = e.position
		local ent = game.surfaces[1].find_entities_filtered{area = {{pos.x-2, pos.y-2}, {pos.x+2, pos.y+2}}, force = game.forces.enemy}
		for _,u in ipairs(ent) do
			if u.valid then u.health = u.health + 23*global.df[5] end		--healing
		end
	elseif e.name == "event-detonator" then
		local pos = e.position
		local ent = game.surfaces[1].find_entities_filtered{area = {{pos.x-30, pos.y-30}, {pos.x+30, pos.y+30}}, name= "engineering-bomb"}
		for _,u in ipairs(ent) do
			if u.valid then
				local pos = u.position
				local et1 = game.surfaces[1].count_entities_filtered {area = {{pos.x-2, pos.y-2}, {pos.x+2, pos.y+2}}, type = "player", limit=1}
				local et2 = game.surfaces[1].count_entities_filtered {area = {{pos.x-2, pos.y-2}, {pos.x+2, pos.y+2}}, type = "car", limit=1}
				local et3 = game.surfaces[1].count_entities_filtered {area = {{pos.x-2, pos.y-2}, {pos.x+2, pos.y+2}}, type = "unit", limit=1}
				local et4 = game.surfaces[1].count_entities_filtered {area = {{pos.x-2, pos.y-2}, {pos.x+2, pos.y+2}}, type = "turret", limit=1}
				if et1+et2+et3+et4 > 0 then
					game.surfaces[1].create_entity{name = "event-explosion-cancel", position = pos}
				else
					local water = {{name="water", position = {pos.x-0.5,pos.y-0.5}},{name="water", position = {pos.x-0.5,pos.y+0.5}},{name="water", position = {pos.x+0.5,pos.y-0.5}},{name="water", position = {pos.x+0.5,pos.y+0.5}}}
					game.surfaces[1].set_tiles(water)
					game.surfaces[1].create_entity{name = "medium-explosion", position = {pos.x,pos.y+0.5}, force =  game.forces.enemy}
				end
			end
		end
	end
end

	--[[for testing only

script.on_event(defines.events.on_research_started, function(event)
	event.research.researched = true
end)

local function weapon_change (idx)
	local gun = math.random(200)
	game.players[idx].print(gun)
end
script.on_event(defines.events.on_player_gun_inventory_changed, function(event)
	weapon_change(event.player_index)
end)]]

	--events

script.on_event(defines.events.on_trigger_created_entity, function(event)
	trigger_created(event.entity)
end)

script.on_event(defines.events.on_sector_scanned, function(event)
	scaning_location(event.radar)
end)

script.on_event(defines.events.on_built_entity, function(event)
	build(event.created_entity, event.player_index)
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
	build(event.created_entity, 0)
end)

script.on_event(defines.events.on_chunk_generated, function(event)
	table.insert(global.ch, event.area)
end)

script.on_event(defines.events.on_gui_click, function(event)
	botton(event.element, event.player_index)
end)

script.on_event(defines.events.on_tick, function()
	global.time[1] = global.time[1] + 1
	tick()
	if global.time[1] >= 60 then
		global.time[2] = global.time[2] + 1
		global.time[1] = 0
		second()
	end
	if global.time[2] >= 60 then
		global.time[3] = global.time[3] + 1
		global.time[2] = 0
		minute()
	end
	if global.time[3] >= 60 then
		global.time[4] = global.time[4] + 1
		global.time[3] = 0
		hour()
	end
end)

script.on_event(defines.events.on_entity_died, function(event)
	unit_die(event.entity)
end)

script.on_event(defines.events.on_research_finished, function(event)
	live_research(event.research.name)
end)

script.on_event(defines.events.on_pre_player_mined_item, function(event)
	player_mined_item (event.entity, event.player_index)
end)

script.on_event(defines.events.on_player_created, function(event)
	new_player_create (event.player_index)
end)

script.on_init(function()
	global.migration = 1
	global.guns =
	{
		{"regenerator"},
		{"rpg"},
		{"new-shotgun","plasma-shotgun"},
		{"m82","scopem82","plasma-sniper"},
		{"rpk74","minigun","plasma-gun"},
		{"ak47","m60","laser-rifle","gauss-rifle"}
	}
end)

script.on_load(function()
	if global.migration == 1 or global.migration == 2 then
		for _,e in pairs (global.targets[1]) do
			if e.valid and e.name == "lab" then
				local sp = e.get_inventory(defines.inventory.lab_input).get_contents()
				e.get_inventory(defines.inventory.lab_input).clear()
				for y,u in pairs(sp) do
					e.get_inventory(defines.inventory.lab_input).insert({name = y, count = u})
				end
			end
		end
	end
end)