data:extend(
{
	{
    type = "damage-type",
    name = "piercing"
	},
	{
    type = "damage-type",
    name = "claw"
	},
	{
    type = "damage-type",
    name = "self"
	},
	{
    type = "damage-type",
    name = "sonic"
	},
})
