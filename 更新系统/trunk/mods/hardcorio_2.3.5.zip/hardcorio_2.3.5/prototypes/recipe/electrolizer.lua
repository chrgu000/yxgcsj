data:extend(
{
	--[[{
    type = "recipe",
    name = "electrolize",
    enabled = true,
    ingredients =
    {
	  {"steel-plate", amount=50}
    },
    results = 
	{
	  {"empty-oxy-tank", amount=1}
	}
  },]]
  {
    type = "recipe",
    name = "electrolize",
    icon = "__hardcorio__/graphics/icons/items/hydrogen-f.png",
    icon_size = 32,
	category = "electrolize",
    subgroup = "energy",
    enabled = false,
    energy_required = 1,
    ingredients =
    {
	  {type="fluid", name="water", amount=10},
    },
    results = 
	{
	  {type="fluid", name="hydrogen", amount=2},
	}
  },
  {
    type = "recipe",
    name = "electrolize-oxy",
    icon = "__hardcorio__/graphics/icons/items/oxygen-f.png",
    icon_size = 32,
	category = "electrolize",
    subgroup = "livesupport",
	order = "e-b",
    enabled = false,
    energy_required = 1,
    ingredients =
    {
	  {type="fluid", name="water", amount=10},
    },
    results = 
	{
	  {type="fluid", name="oxygen", amount=1},
	}
  },
  {
    type = "recipe",
    name = "recipe-hydrogen-can",
    icon = "__hardcorio__/graphics/icons/items/hydrogen.png",
    icon_size = 32,
	category = "crafting-with-fluid",
    enabled = false,
    energy_required = 2,
    ingredients =
    {
	  {type="fluid", name="hydrogen", amount=300},
	  {"iron-plate", 1}
    },
    results = 
	{
	  {"hydrogen-can", 1}
	}
  },
  
  {
    type = "recipe",
    name = "electrolizer",
    subgroup = "energy",
    enabled = false,
    ingredients =
    {
      {"iron-plate", 15},
      {"copper-plate", 5},
	  {"electronic-circuit", 5},
    },
    results = 
	{
	  {"electrolizer", 1},
	}
  }
  }
  )