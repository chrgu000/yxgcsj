data:extend(
{
  {
    type = "recipe",
    name = "recipe-gun-turret-127x99",
    enabled = "false",
    energy_required = 5,
    ingredients =
    {
      {"iron-gear-wheel", 5},
      {"copper-plate", 15},
      {"steel-plate", 2},
	  {"electronic-circuit", 7}
    },
    result = "gun-turret-127x99"
  },
  {
    type = "recipe",
    name = "recipe-gun-turret-762x39",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"iron-gear-wheel", 5},
      {"copper-plate", 15},
      {"steel-plate", 3},
	  {"electronic-circuit", 7}
    },
    result = "gun-turret-762x39"
  },  
  {
    type = "recipe",
    name = "recipe-gun-turret-556x45",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"iron-gear-wheel", 5},
      {"copper-plate", 15},
      {"steel-plate", 4},
	  {"electronic-circuit", 7}
    },
    result = "gun-turret-556x45"
  },
     {
    type = "recipe",
    name = "recipe-turret_missle",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"iron-gear-wheel", 5},
      {"copper-plate", 15},
      {"steel-plate", 2},
      {"electronic-circuit", 40},
    },
    result = "turret_missle"
  },
{
    type = "recipe",
    name = "recipe-blue-laser-turret",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 8},
      {"electronic-circuit", 50},
      {"battery", 15},
      {"elerium", 6},
    },
    result = "blue-laser-turret"
  },
  {
    type = "recipe",
    name = "recipe-green-laser-turret",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 12},
      {"electronic-circuit", 50},
      {"battery", 15},
      {"elerium", 4},
    },
    result = "green-laser-turret"
  },
  {
    type = "recipe",
    name = "recipe-red-laser-turret",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 16},
      {"electronic-circuit", 50},
      {"battery", 15},
      {"elerium", 2},
    },
    result = "red-laser-turret"
  },
  
   {
    type = "recipe",
    name = "recipe-plasma-turret",
    enabled = "false",
    energy_required = 30,
    ingredients =
    {
      {"steel-plate", 44},
      {"advanced-circuit", 22},
      {"processing-unit", 5},
      {"elerium", 10},
    },
    result = "plasma-turret"
  },
   
  }
  )