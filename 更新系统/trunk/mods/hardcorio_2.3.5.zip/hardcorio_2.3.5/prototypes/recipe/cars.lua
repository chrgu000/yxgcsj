data:extend(
{
  {
    type = "recipe",
    name = "recipe-hummer",
    enabled = "false",
    energy_required = 100,
    ingredients =
    {
      {"iron-gear-wheel", 75},
	  {"steel-plate", 35},
      {"copper-plate", 90},
	  {"electronic-circuit", 40},
	  {"engine-unit", 1},
    },
    result = "hummer"
  },
  {
    type = "recipe",
    name = "recipe-truck",
    enabled = "false",
    energy_required = 100,
    ingredients =
    {
      {"iron-gear-wheel", 60},
	  {"steel-plate", 40},
      {"copper-plate", 90},
	  {"electronic-circuit", 10},
	  {"engine-unit", 4},
    },
    result = "truck"
  },
  {
    type = "recipe",
    name = "recipe-new-tank",
    enabled = "false",
    energy_required = 180,
    ingredients =
    {
      {"iron-gear-wheel", 617},
	  {"steel-plate", 522},
      {"uranium-fuel-cell", 28},
	  {"advanced-circuit", 72},
	  {"engine-unit", 37},
	  {"alien-artifact", 31},
    },
    result = "new-tank"
  },
  }
  )