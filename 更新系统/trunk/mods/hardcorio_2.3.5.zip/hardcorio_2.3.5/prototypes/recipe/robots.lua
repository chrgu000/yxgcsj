data:extend(
{
  {
    type = "recipe",
    name = "recipe-robot-556x45",
	category = "crafting-with-fluid",
    energy_required = 25,
	enabled = "false",
    ingredients =
    {
	  {"electronic-circuit", 15},
	  {"iron-plate-block", 15},
	  {"copper-plate-block", 10},
	  {type="fluid", name = "hydrogen", amount = 100}
    },
    result = "robot-556x45",
  },
  {
    type = "recipe",
    name = "recipe-robot-762x39",
	category = "crafting-with-fluid",
    energy_required = 25,
	enabled = "false",
    ingredients =
    {
	  {"electronic-circuit", 15},
	  {"iron-plate-block", 15},
	  {"coal", 100},
	  {type="fluid", name = "hydrogen", amount = 100}
    },
    result = "robot-762x39",
  },
  {
    type = "recipe",
    name = "recipe-robot-127x99",
	category = "crafting-with-fluid",
    energy_required = 25,
	enabled = "false",
    ingredients =
    {
	  {"electronic-circuit", 15},
	  {"iron-plate-block", 15},
	  {"explosives", 20},
	  {type="fluid", name = "hydrogen", amount = 100}
    },
    result = "robot-127x99",
  },
  })