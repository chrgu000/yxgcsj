data:extend(
{
	{
    type = "recipe",
    name = "recipe-repair-kit",
    enabled = "false",
	category = "crafting-with-fluid",
    energy_required = 10,
    ingredients =
    {
	  {"steel-plate", 5},
	  {"advanced-circuit", 6},
      {"iron-gear-wheel", 7},
      {type="fluid", name="lubricant", amount=120},	  
    },
    results = 
	{
	  {name="repair-kit", amount=1},
	}
  },
  
	--medi-kit
	
	{
    type = "recipe",
    name = "recipe-medi-kit",
    enabled = "false",
	category = "crafting-with-fluid",
    energy_required = 10,
    ingredients =
    {
	  {"copper-plate", 15},
	  {"iron-plate", 5},
	  {"electronic-circuit", 25},
	  {"sulfur", 15},
    },
    results = 
	{
	  {name="medi-kit", amount=1},
	}
  },

	--shotgun
	
	{
    type = "recipe",
    name = "recipe-sh-ep",
    enabled = "true",
    energy_required = 0.3,
    ingredients =
    {
     {"iron-plate", 1},
	 {"coal", 1},
    },
    results = 
	{
	  {name="sh-ep", amount=1},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-sh-ap",
    enabled = "true",
    energy_required = 0.3,
    ingredients =
    {
     {"iron-plate", 1},
	 {"copper-plate", 1},
	 {"coal", 1},
    },
    results = 
	{
	  {name="sh-ap", amount=1},
	}
  },
  
	--556x45
	
	{
    type = "recipe",
    name = "recipe-556x45ep",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="556x45ep", amount=10},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-556x45ap",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"copper-plate-block", 1},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="556x45ap", amount=10},
	}
  },
  
 {
    type = "recipe",
    name = "recipe-556x45tr",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"sulfur", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="556x45tr", amount=10},
	}
  },
  
   {
    type = "recipe",
    name = "recipe-556x45du",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"uranium-235", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="556x45du", amount=10},
	}
  },
  
	--762x39
	
	{
    type = "recipe",
    name = "recipe-762x39ep",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="762x39ep", amount=6},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-762x39ap",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"copper-plate-block", 1},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="762x39ap", amount=6},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-762x39fa",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"coal", 10},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="762x39fa", amount=6},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-762x39du",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"uranium-235", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="762x39du", amount=6},
	}
  },

	--127x99
  {
    type = "recipe",
    name = "recipe-127x99ep",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 2},
	 {"coal", 5},
    },
    results = 
	{
	  {name="127x99ep", amount=3},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-127x99mg",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"copper-plate-block", 1},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="127x99mg", amount=3},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-127x99he",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"explosives", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="127x99he", amount=3},
	}
  },
  
  {
    type = "recipe",
    name = "recipe-127x99du",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
     {"iron-plate-block", 1},
	 {"uranium-235", 2},
	 {type="fluid", name = "hydrogen", amount = 100}
    },
    results = 
	{
	  {name="127x99du", amount=3},
	}
  },
  
  --105x
  
  	{
    type = "recipe",
    name = "recipe-105he",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 60,
    ingredients =
    {
      {"electronic-circuit", 4},
      {"explosives", 8},
      {"iron-plate", 8},
	 {type="fluid", name = "hydrogen", amount = 500}
    },
    result = "105he"
  },
  
  {
    type = "recipe",
    name = "recipe-105tbc",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {"electronic-circuit", 6},
      {"explosives", 12},
      {"iron-plate", 12},
	 {type="fluid", name = "hydrogen", amount = 800}
    },
    result = "105tbc"
  },
  
  {
    type = "recipe",
    name = "recipe-105mg",
	category = "crafting-with-fluid",
    enabled = "false",
    energy_required = 12,
    ingredients =
    {
      {"electronic-circuit", 4},
      {"explosives", 8},
      {"iron-plate", 8},
	 {type="fluid", name = "hydrogen", amount = 1200}
    },
    result = "105mg"
  },
  
  --power source
  
  {
    type = "recipe",
    name = "recipe-ps40",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 1},
	 {"electronic-circuit", 1},
	 {"iron-plate", 1},
    },
    result = "ps40"
  },
  
  {
    type = "recipe",
    name = "recipe-ps200",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 1},
	 {"electronic-circuit", 1},
	 {"iron-plate", 1},
    },
    result = "ps200"
  },
  
  {
    type = "recipe",
    name = "recipe-ps4000",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 1},
	 {"electronic-circuit", 1},
	 {"iron-plate", 1},
    },
    result = "ps4000"
  },
   {
    type = "recipe",
    name = "recipe-ps3200",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 1},
	 {"electronic-circuit", 1},
	 {"iron-plate", 1},
    },
    result = "ps3200"
  },
  {
    type = "recipe",
    name = "recipe-ps2000",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 1},
	 {"electronic-circuit", 1},
	 {"iron-plate", 1},
    },
    result = "ps2000"
  },
  
  --TANK
  {
    type = "recipe",
    name = "recipe-ps160",
    enabled = "false",
	category = "advanced-crafting",
    energy_required = 10,
    ingredients =
    {
     {"uranium-fuel-cell", 5},
	 {"advanced-circuit", 1},
	 {"iron-plate", 40},
    },
    result = "ps160"
  },
  {
    type = "recipe",
    name = "recipe-125x",
    enabled = "false",
	category = "crafting-with-fluid",
    energy_required = 10,
    ingredients =
    {
     {"uranium-235", 1},
	 {"explosives", 6},
	 {"steel-plate", 1},
	 {type="fluid", name = "hydrogen", amount = 600}
    },
    result = "125x"
  },
  {
    type = "recipe",
    name = "recipe-rockets-1",
    enabled = "false",
    category = "advanced-crafting",
    energy_required = 160,
    ingredients =
    {
     {"advanced-circuit", 16},
     {"uranium-235", 16},
     {"steel-plate", 20},
     {"hydrogen-can", 60}
    },
    result = "rockets-1"
  },
  {
    type = "recipe",
    name = "recipe-rockets-2",
    enabled = "false",
    category = "advanced-crafting",
    energy_required = 160,
    ingredients =
    {
     {"advanced-circuit", 16},
     {"explosives", 32},
     {"steel-plate", 20},
     {"hydrogen-can", 60}
    },
    result = "rockets-2"
  },
  {
    type = "recipe",
    name = "recipe-rockets-3",
    enabled = "false",
    category = "advanced-crafting",
    energy_required = 160,
    ingredients =
    {
     {"advanced-circuit", 16},
     {"uranium-235", 16},
     {"steel-plate", 20},
     {"hydrogen-can", 60}
    },
    result = "rockets-3"
  },
  
  --MINES
  {
    type = "recipe",
    name = "recipe-station-mine",
    enabled = "false",
	category = "crafting-with-fluid",
    energy_required = 5,
    ingredients =
    {
     {"electronic-circuit", 1},
      {"explosives", 1},
      {"iron-plate", 2},
	 {type="fluid", name = "hydrogen", amount = 250}
    },
    result = "station-mine"
  },
  
  
  }
  )