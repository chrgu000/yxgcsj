data:extend(
{
  {
    type = "recipe",
    name = "elerium-processing",
    energy_required = 10,
    enabled = false,
    category = "centrifuging",
    ingredients = {{"elerium-ore", 1}},
    icon = "__hardcorio__/graphics/icons/items/elerium-processing.png",
    icon_size = 32,
    subgroup = "raw-material",
    order = "h[elerium-processing]",
    results =
    {
      {
        name = "elerium",
        probability = 0.75,
        amount_min = 1,
		amount_max = 3
      },
      {
        name = "uranium-235",
        probability = 0.25,
        amount = 1
      },
      {
        name = "uranium-238",
        probability = 0.8,
        amount_min = 1,
		amount_max = 4
      }
    }
  },
  {
    type = "recipe",
    name = "uranium-stone",
    category = "crafting-with-fluid",
	subgroup = "smelting",
	order = "d-a",
    energy_required = 10,
	enabled = "false",
    ingredients = {{ "stone", 10}, { "uranium-235", 1}, {type="fluid", name="sulfuric-acid", amount=10}},
    result = "uranium-stone",
	result_count = 10,
  },
  {
    type = "recipe",
    name = "uranium-brick",
    category = "smelting",
	subgroup = "smelting",
	order = "d-b",
    energy_required = 7,
	enabled = "false",
    ingredients = {{"uranium-stone", 2}},
    result = "uranium-brick"
  },
  {
    type = "recipe",
    name = "uranium-wall",
	enabled = "false",
    ingredients = {{"uranium-brick", 5}},
    result = "uranium-wall"
  },
  {
    type = "recipe",
    name = "uranium-gate",
	enabled = "false",
    ingredients = {{"uranium-wall", 1}, {"steel-plate", 2}, {"advanced-circuit", 2}},
    result = "uranium-gate"
  },
  {
    type = "recipe",
    name = "biomass-food",
    category = "chemistry",
    subgroup = "livesupport",
	order = "e-c",
	enabled = "false",
    energy_required = 5,
    ingredients =
    {
      {type="item", name="organic-food", amount=2},
      {type="fluid", name="pure-water", amount=5},
    },
	results=
    {
	  {type="fluid", name="biomass-food", amount=20},
    },
  },
  {
    type = "recipe",
    name = "water",
    category = "chemistry",
    subgroup = "livesupport",
	order = "e-b",
	enabled = "false",
    energy_required = 10,
    ingredients =
    {
      {type="fluid", name="hydrogen", amount=20},
      {type="fluid", name="oxygen", amount=10},
    },
	results=
    {
	  {type="fluid", name="pure-water", amount=6},
    },
  },
  {
    type = "recipe",
    name = "support-tank",
	enabled = "false",
    energy_required = 15,
    ingredients =
    {
		{"iron-plate", 100},
		 {"copper-plate", 50},
    },
	result = "support-tank"
  },
  
}
)