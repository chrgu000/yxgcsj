data:extend(
{
  {
    type = "recipe",
    name = "recipe-grinder",
    energy_required = 5.5,
	enabled = "false",
    ingredients =
    {
	  {"electric-engine-unit", 21},
      {"advanced-circuit", 13},
	  {"alien-artifact", 5},
	  {"steel-plate", 25}
    },
    result = "grinder",
  },
  
  {
    type = "recipe",
    name = "grind-iron",
    category = "grinding",
    energy_required = 1.5,
	enabled = "false",
    ingredients = {{ "iron-ore", 1}},
    results =
    {
      {
        name = "iron-dust",
        probability = 1,
        amount_min = 1,
		amount_max = 2
      }
    },
    subgroup = "raw-material",
    order = "d-a",
  },
   {
    type = "recipe",
    name = "grind-copper",
    category = "grinding",
    energy_required = 1.5,
	enabled = "false",
    ingredients = {{ "copper-ore", 1}},
    results =
    {
      {
        name = "copper-dust",
        probability = 1,
        amount_min = 1,
		amount_max = 2
      }
    },
    subgroup = "raw-material",
    order = "d-b",
  },
  {
    type = "recipe",
    name = "recipe-steel-dust",
    energy_required = 5,
	enabled = "false",
    ingredients = {{ "iron-dust", 4}, { "coal", 1}},
    result = "steel-dust",
	result_count = 1,
    subgroup = "raw-material",
    order = "d-d",
  },
  {
    type = "recipe",
    name = "smelt-iron-dust",
    category = "smelting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-dust", 1}},
    results =
	{{
		name = "iron-plate",
		probability = 0.7,
		amount = 1,
	}},
    subgroup = "smelting",
    order = "b-a"
  },
  {
    type = "recipe",
    name = "smelt-copper-dust",
    category = "smelting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-dust", 1}},
    results =
	{{
		name = "copper-plate",
		probability = 0.7,
		amount = 1,
	}},
    subgroup = "smelting",
    order = "b-b"
  },
  {
    type = "recipe",
    name = "smelt-steel-dust",
    category = "smelting",
    energy_required = 12.5,
	enabled = "false",
    ingredients = {{ "steel-dust", 1}},
    results =
	{{
		name = "steel-plate",
		probability = 0.7,
		amount = 1,
	}},
    subgroup = "smelting",
    order = "b-c"
  },
  })