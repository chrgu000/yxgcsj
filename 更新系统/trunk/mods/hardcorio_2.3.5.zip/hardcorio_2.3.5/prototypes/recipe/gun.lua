data:extend(
{

	--medi-kit
	
	{
    type = "recipe",
    name = "recipe-regenerator",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 15},
	  {"iron-plate", 25},
	  {"steel-plate", 5},
	  {"electronic-circuit", 20},
    },
    result = "regenerator0"
  },
	
	--shotgun

	{
    type = "recipe",
    name = "recipe-new-shotgun",
    enabled = "true",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 15},
	  {"wood", 20},
	  {"iron-plate", 25}
    },
    result = "new-shotgun0"
  },
   
   {
    type = "recipe",
    name = "recipe-ak47",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 40},
	  {"wood", 20},
	  {"steel-plate", 10}
    },
    result = "ak470"
  },
  
  {
    type = "recipe",
    name = "recipe-rpk74",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 40},
	  {"wood", 20},
	  {"steel-plate", 10}
    },
    result = "rpk740"
  },
  
  {
    type = "recipe",
    name = "recipe-m60",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 20},
	  {"steel-plate", 15}
    },
    result = "m600"
  },
  
  {
    type = "recipe",
    name = "recipe-minigun",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 100},
	  {"electronic-circuit", 35},
	  {"steel-plate", 30},
    },
    result = "minigun0"
  },
  
  {
    type = "recipe",
    name = "recipe-m82",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 15},
	  {"electronic-circuit", 20},
	  {"steel-plate", 20}
    },
    result = "m820"
  },
  {
    type = "recipe",
    name = "recipe-m82s",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 15},
	  {"advanced-circuit", 20},
	  {"steel-plate", 20}
    },
    result = "scopem820"
  },
  
  {
    type = "recipe",
    name = "recipe-rpg",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"copper-plate", 60},
	  {"advanced-circuit", 10},
	  {"steel-plate", 10}
    },
    result = "rpg0"
  },
  
  {
    type = "recipe",
    name = "recipe-laser-rifle",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"elerium", 20},
      {"steel-plate", 15},
	  {"advanced-circuit", 15},
	  {"alien-artifact", 10}
    },
    result = "laser-rifle0"
  },
  
   {
    type = "recipe",
    name = "recipe-gauss-rifle",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"elerium", 20},
      {"steel-plate", 15},
	  {"advanced-circuit", 15},
	  {"alien-artifact", 10}
    },
    result = "gauss-rifle0"
  },
  
  {
    type = "recipe",
    name = "recipe-plasma-shotgun",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"elerium", 20},
      {"steel-plate", 15},
	  {"advanced-circuit", 15},
	  {"alien-artifact", 10}
    },
    result = "plasma-shotgun0"
  },
  
    {
    type = "recipe",
    name = "recipe-plasma-gun",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"elerium", 20},
      {"steel-plate", 15},
	  {"advanced-circuit", 15},
	  {"alien-artifact", 10}
    },
    result = "plasma-gun0"
  },
  
    {
    type = "recipe",
    name = "recipe-plasma-sniper",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"elerium", 20},
      {"steel-plate", 15},
	  {"advanced-circuit", 15},
	  {"alien-artifact", 10}
    },
    result = "plasma-sniper0"
  },
  }
  )