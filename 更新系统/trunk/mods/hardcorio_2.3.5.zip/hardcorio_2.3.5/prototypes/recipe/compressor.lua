data:extend(
{
  {
    type = "recipe",
    name = "recipe-compressor",
    energy_required = 3.5,
	enabled = "false",
    ingredients =
    {
      {"electronic-circuit", 10},
      {"iron-gear-wheel", 10},
	  {"steel-plate", 3},
    },
    result = "compressor",
  },
  
  {
    type = "recipe",
    name = "compressing-iron-ore",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-ore", 10}},
    result = "iron-ore-block",
	result_count = 1,
    subgroup = "compressing",
    order = "a-a"
  },
  {
    type = "recipe",
    name = "compressing-copper-ore",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-ore", 10}},
    result = "copper-ore-block",
	result_count = 1,
    subgroup = "compressing",
    order = "a-b"
  },
  
  {
    type = "recipe",
    name = "compressing-iron-plate",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-plate", 10}},
    result = "iron-plate-block",
	result_count = 1,
    subgroup = "compressing",
    order = "c-a"
  },
  {
    type = "recipe",
    name = "compressing-copper-plate",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-plate", 10}},
    result = "copper-plate-block",
	result_count = 1,
    subgroup = "compressing",
    order = "c-b"
  },
  {
    type = "recipe",
    name = "compressing-steel-plate",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "steel-plate", 10}},
    result = "steel-plate-block",
	result_count = 1,
    subgroup = "compressing",
    order = "c-c"
  },
  
  {
    type = "recipe",
    name = "compressing-iron-dust",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-dust", 10}},
    result = "iron-dust-block",
	result_count = 1,
    subgroup = "compressing",
    order = "b-a"
  },
  {
    type = "recipe",
    name = "compressing-copper-dust",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-dust", 10}},
    result = "copper-dust-block",
	result_count = 1,
    subgroup = "compressing",
    order = "b-b"
  },
  {
    type = "recipe",
    name = "compressing-steel-dust",
    category = "compressing",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "steel-dust", 10}},
    result = "steel-dust-block",
	result_count = 1,
    subgroup = "compressing",
    order = "b-c"
  },
  
  {
    type = "recipe",
    name = "uncompressing-iron-ore",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-ore-block", 1}},
    result = "iron-ore",
	result_count = 10,
    subgroup = "decompressing",
    order = "a-a"
  },
  {
    type = "recipe",
    name = "uncompressing-copper-ore",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-ore-block", 1}},
    result = "copper-ore",
	result_count = 10,
    subgroup = "decompressing",
    order = "a-b"
  },
  {
    type = "recipe",
    name = "uncompressing-iron-plate",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-plate-block", 1}},
    result = "iron-plate",
	result_count = 10,
    subgroup = "decompressing",
    order = "c-a"
  },
  {
    type = "recipe",
    name = "uncompressing-copper-plate",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-plate-block", 1}},
    result = "copper-plate",
	result_count = 10,
    subgroup = "decompressing",
    order = "c-b"
  },
  {
    type = "recipe",
    name = "uncompressing-steel-plate",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "steel-plate-block", 1}},
    result = "steel-plate",
	result_count = 10,
    subgroup = "decompressing",
    order = "c-c"
  },
  
  {
    type = "recipe",
    name = "uncompressing-iron-dust",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "iron-dust-block", 1}},
    result = "iron-dust",
	result_count = 10,
    subgroup = "decompressing",
    order = "b-a"
  },
  
  {
    type = "recipe",
    name = "uncompressing-copper-dust",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "copper-dust-block", 1}},
    result = "copper-dust",
	result_count = 10,
    subgroup = "decompressing",
    order = "b-b"
  },
  {
    type = "recipe",
    name = "uncompressing-steel-dust",
	category = "advanced-crafting",
    energy_required = 2.5,
	enabled = "false",
    ingredients = {{ "steel-dust-block", 1}},
    result = "steel-dust",
	result_count = 10,
    subgroup = "decompressing",
    order = "b-c"
  },
  
  {
    type = "recipe",
    name = "smelt-iron-ore-block",
    category = "smelting",
    energy_required = 35,
	enabled = "false",
    ingredients = {{ "iron-ore-block", 1}},
    result = "iron-plate",
	result_count = 10,
    subgroup = "smelting2",
    order = "a-a"
  },
  {
    type = "recipe",
    name = "smelt-copper-ore-block",
    category = "smelting",
    energy_required = 35,
	enabled = "false",
    ingredients = {{ "copper-ore-block", 1}},
    result = "copper-plate",
	result_count = 10,
    subgroup = "smelting2",
    order = "a-b"
  },
  
  {
    type = "recipe",
    name = "smelt-iron-dust-block",
    category = "smelting",
    energy_required = 25,
	enabled = "false",
    ingredients = {{ "iron-dust-block", 1}},
    result = "iron-plate",
	result_count = 10,
    subgroup = "smelting2",
    order = "a-c"
  },
  {
    type = "recipe",
    name = "smelt-copper-dust-block",
    category = "smelting",
    energy_required = 25,
	enabled = "false",
    ingredients = {{ "copper-dust-block", 1}},
    result = "copper-plate",
	result_count = 10,
    subgroup = "smelting2",
    order = "a-d"
  },
  {
    type = "recipe",
    name = "smelt-steel-dust-block",
    category = "smelting",
    energy_required = 125,
	enabled = "false",
    ingredients = {{ "steel-dust-block", 1}},
    result = "steel-plate",
	result_count = 10,
    subgroup = "smelting2",
    order = "a-e"
  },
  {
    type = "recipe",
    name = "smelt-iron-plate-block",
    category = "smelting",
    energy_required = 35,
	enabled = "false",
    ingredients = {{ "iron-plate-block", 1}},
    result = "steel-plate",
	result_count = 2,
    subgroup = "smelting2",
    order = "a-f"
  },
})