data:extend(
{
	{
    type = "ammo-category",
    name = "laser-ammo"
	},
	
	{
    type = "ammo-category",
    name = "heavy-ammo"
	},

	{
    type = "ammo-category",
    name = "556x45"
	},
	
	{
    type = "ammo-category",
    name = "762x39"
	},
	
	{
    type = "ammo-category",
    name = "127x99"
	},
	
	{
    type = "ammo-category",
    name = "105x"
	},
	
	{
    type = "ammo-category",
    name = "repair-kit"
	},
	
	{
    type = "ammo-category",
    name = "medi-kit"
	},
	
	{
    type = "ammo-category",
    name = "ps40"
	},
	{
    type = "ammo-category",
    name = "ps3200"
	},
	{
    type = "ammo-category",
    name = "ps4000"
	},
	{
    type = "ammo-category",
    name = "ps200"
	},
	{
    type = "ammo-category",
    name = "ps2000"
	},
	{
    type = "ammo-category",
    name = "ps160"
	},
	{
    type = "ammo-category",
    name = "125x"
	},
	{
    type = "ammo-category",
    name = "tank-rockets"
	},
})
