data:extend(
{
  {
    type = "recipe-category",
    name = "electrolize"
  },
  
  {
    type = "recipe-category",
    name = "grinding"
  },
  
    {
    type = "recipe-category",
    name = "compressing"
  },
  
  {
    type = "recipe-category",
    name = "nothing-craft"
  },
}
)
