data:extend(
{
  {
    type = "item",
    name = "organic-food",
    icon = "__hardcorio__/graphics/icons/items/organic-food.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "livesupport",
    order = "c-b",
    stack_size = 100
  },
{
    type = "item",
    name = "support-tank",
    icon = "__hardcorio__/graphics/icons/items/support-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
	place_result = "support-tank",
    order = "b[fluid]-b[support-tank]",
    stack_size = 1
  },
	{
    type = "item",
    name = "air-tank",
    icon = "__hardcorio__/graphics/icons/items/air-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "raw-material",
    order = "1-a",
    stack_size = 100
  },
  {
    type = "item",
    name = "food-tank",
    icon = "__hardcorio__/graphics/icons/items/food-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "raw-material",
    order = "1-b",
    stack_size = 100
  },
  {
    type = "item",
    name = "water-tank",
    icon = "__hardcorio__/graphics/icons/items/water-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "raw-material",
    order = "1-c",
    stack_size = 100
  },
	{
    type = "tool",
    name = "enemy-dna",
    icon = "__hardcorio__/graphics/entity/player/ship/dna.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "a",
    stack_size = 2147483648,
    durability = 1,
    durability_description_key = "description.science-pack-remaining-amount-key",
    durability_description_value = "description.science-pack-remaining-amount-value"
  },
  {
    type = "item",
    name = "iron-plate-block",
    icon = "__hardcorio__/graphics/icons/items/iron-plate-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "b[iron-plate]-b",
    stack_size = 50
  },
  {
    type = "item",
    name = "copper-plate-block",
    icon = "__hardcorio__/graphics/icons/items/copper-plate-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "c[copper-plate]-b",
    stack_size = 50
  },
  {
    type = "item",
    name = "steel-plate-block",
    icon = "__hardcorio__/graphics/icons/items/steel-plate-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "d[steel-plate]-b",
    stack_size = 50
  },
  {
    type = "item",
    name = "iron-dust-block",
    icon = "__hardcorio__/graphics/icons/items/iron-dust-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "e[iron-ore]-d",
    stack_size = 50
  },
  {
    type = "item",
    name = "copper-dust-block",
    icon = "__hardcorio__/graphics/icons/items/copper-dust-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "f[copper-ore]-d",
    stack_size = 50
  },
  {
    type = "item",
    name = "steel-dust-block",
    icon = "__hardcorio__/graphics/icons/items/steel-dust-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "g-d",
    stack_size = 50
  },
  {
    type = "item",
    name = "iron-ore-block",
    icon = "__hardcorio__/graphics/icons/items/iron-ore-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "e[iron-ore]-b",
    stack_size = 50
  },
  {
    type = "item",
    name = "copper-ore-block",
    icon = "__hardcorio__/graphics/icons/items/copper-ore-block.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "f[copper-ore]-b",
    stack_size = 50
  },
  {
    type = "item",
    name = "compressor",
    icon = "__hardcorio__/graphics/icons/items/compressor.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "extraction-machine",
    order = "b[iron-plate]-a",
    place_result = "compressor",
    stack_size = 50
  },
  {
    type = "item",
    name = "iron-dust",
    icon = "__hardcorio__/graphics/icons/items/iron-dust.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "e[iron-ore]-a",
    stack_size = 50
  },
  {
    type = "item",
    name = "copper-dust",
    icon = "__hardcorio__/graphics/icons/items/copper-dust.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "f[copper-ore]-a",
    stack_size = 50
  },
  {
    type = "item",
    name = "steel-dust",
    icon = "__hardcorio__/graphics/icons/items/steel-dust.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "g-a",
    stack_size = 50
  },
  {
    type = "item",
    name = "electrolizer",
    icon = "__hardcorio__/graphics/icons/items/electrolizer.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "electrolizer",
    place_result = "electrolizer",
    stack_size = 50
  },
  {
    type = "item",
    name = "hydrogen-can",
    icon = "__hardcorio__/graphics/icons/items/hydrogen.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    fuel_category = "chemical",
    fuel_value = "20MJ",
    fuel_acceleration_multiplier = 1.4,
    fuel_top_speed_multiplier = 1.1,
    subgroup = "raw-material",
    order = "a",
    stack_size = 60
  },
  {
    type = "item",
    name = "elerium-ore",
    icon = "__hardcorio__/graphics/icons/items/elerium-ore.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-resource",
    order = "z-a",
    stack_size = 100
  },
  {
    type = "tool",
    name = "elerium",
    icon = "__hardcorio__/graphics/icons/items/elerium.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "z-d",
    stack_size = 1000,
    durability = 1,
    durability_description_key = "description.science-pack-remaining-amount-key",
    durability_description_value = "description.science-pack-remaining-amount-value"
  },
  {
    type = "item",
    name = "grinder",
    icon = "__hardcorio__/graphics/icons/items/grinder.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "extraction-machine",
    order = "b[iron-plate]-a",
    place_result = "grinder",
    stack_size = 50
  },
  
  
})
