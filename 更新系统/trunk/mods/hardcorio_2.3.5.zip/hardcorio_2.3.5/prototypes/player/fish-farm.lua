
circuit_connector_definitions["feeder"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 19, main_offset = util.by_pixel(16, 0), shadow_offset = util.by_pixel(21, 4), show_shadow = false },
  }
)

circuit_connector_definitions["incubator"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 0, main_offset = util.by_pixel(4.6, -10), shadow_offset = util.by_pixel(23, 5), show_shadow = false },
  }
)

data:extend(
{
  {
    type = "item",
    name = "tiny-fish",
    icon = "__hardcorio__/graphics/icons/items/tiny-fish.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "livesupport",
    order = "d-a",
	place_result = "tiny-fish",
    stack_size = 50
  },
  {
    type = "item",
    name = "small-fish",
    icon = "__hardcorio__/graphics/icons/items/small-fish.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "livesupport",
    order = "d-b",
	place_result = "small-fish",
    stack_size = 50
  },
  {
    type = "item",
    name = "fish",
    icon = "__hardcorio__/graphics/icons/items/fish.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "livesupport",
    order = "d-c",
	place_result = "fish",
    stack_size = 50
  },
  {
    type = "fish",
    name = "tiny-fish",
    icon = "__hardcorio__/graphics/icons/items/tiny-fish.png",
    icon_size = 32,
    flags = {"placeable-neutral", "not-on-map", "placeable-off-grid"},
    minable = {mining_time = 1, result = "tiny-fish"},
    max_health = 20,
    subgroup = "creatures",
    order = "b-a",
    collision_box = {{-0.75, -0.75}, {0.75, 0.75}},
    selection_box = {{-0.15, -0.09}, {0.15, 0.09}},
    pictures =
    {
      {
        filename = "__base__/graphics/entity/fish/fish-1.png",
        priority = "extra-high",
        width = 22,
        height = 36,
		scale = 0.3
      },
      {
        filename = "__base__/graphics/entity/fish/fish-2.png",
        priority = "extra-high",
        width = 32,
        height = 32,
		scale = 0.3
      }
    },
  },
  
  {
    type = "fish",
    name = "small-fish",
    icon = "__hardcorio__/graphics/icons/items/small-fish.png",
    icon_size = 32,
    flags = {"placeable-neutral", "not-on-map", "placeable-off-grid"},
    minable = {mining_time = 1, result = "small-fish"},
    max_health = 20,
    subgroup = "creatures",
    order = "b-a",
    collision_box = {{-0.75, -0.75}, {0.75, 0.75}},
    selection_box = {{-0.3, -0.18}, {0.3, 0.18}},
    pictures =
    {
      {
        filename = "__base__/graphics/entity/fish/fish-1.png",
        priority = "extra-high",
        width = 22,
        height = 36,
		scale = 0.6
      },
      {
        filename = "__base__/graphics/entity/fish/fish-2.png",
        priority = "extra-high",
        width = 32,
        height = 32,
		scale = 0.6
      }
    },
  },
  
  {
    type = "recipe",
    name = "cutting-tiny-fish",
    icon = "__hardcorio__/graphics/icons/items/cutting-tiny-fish.png",
    icon_size = 32,
    category = "crafting",
    energy_required = 2.5,
	enabled = "false",
    subgroup = "livesupport",
    order = "c-c",
    ingredients = {{ "tiny-fish", 1}},
    results =
    {
      {
        name = "organic-food",
        probability = 0.6,
        amount = 1
      }
    },
  },
  {
    type = "recipe",
    name = "cutting-small-fish",
    icon = "__hardcorio__/graphics/icons/items/cutting-small-fish.png",
    icon_size = 32,
    category = "crafting",
    energy_required = 2.5,
	enabled = "false",
    subgroup = "livesupport",
    order = "c-b",
    ingredients = {{ "small-fish", 1}},
    results =
    {
      {
        name = "organic-food",
        probability = 1,
        amount_min = 2,
		amount_max = 9
      },
      {
        name = "caviar",
        probability = 0.1,
        amount_min = 1,
		amount_max = 2
      }
    },
  },
  {
    type = "recipe",
    name = "cutting-fish",
    icon = "__hardcorio__/graphics/icons/items/cutting-fish.png",
    icon_size = 32,
    category = "crafting",
    energy_required = 2.5,
	enabled = "false",
    subgroup = "livesupport",
    order = "c-a",
    ingredients = {{ "fish", 1}},
    results =
    {
      {
        name = "organic-food",
        probability = 1,
        amount_min = 7,
		amount_max = 18
      },
      {
        name = "caviar",
        probability = 0.65,
        amount_min = 2,
		amount_max = 4
      }
    },
  },
  {
    type = "recipe",
    name = "organic-food",
	enabled = "false",
    ingredients =
    {
		{"caviar", 1},
    },
	results=
    {
	  {type="item", name="organic-food", amount=2},
    },
  },
  
  {
    type = "item",
    name = "caviar",
    icon = "__hardcorio__/graphics/icons/items/caviar.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "livesupport",
    order = "d-a",
    stack_size = 50
  },
  
  {
    type = "recipe",
    name = "feeder",
	enabled = "false",
    energy_required = 5,
    ingredients =
    {
		{"electronic-circuit", 4},
		{"iron-gear-wheel", 3},
		{"iron-plate", 12},
    },
	results=
    {
	  {type="item", name="feeder", amount=1},
    },
  },
  
  {
    type = "recipe",
    name = "incubator",
	enabled = "false",
    energy_required = 5,
    ingredients =
    {
		{"electronic-circuit", 6},
		{"pipe", 4},
		{"iron-plate", 10},
    },
	results=
    {
	  {type="item", name="incubator", amount=1},
    },
  },
  
  {
    type = "item",
    name = "feeder",
    icon = "__hardcorio__/graphics/icons/building/feeder.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "livesupport",
    order = "b[feeder]",
    place_result = "feeder",
    stack_size = 50
  },
  {
    type = "container",
    name = "feeder",
    icon = "__hardcorio__/graphics/icons/building/feeder.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "not-blueprintable"},
    minable = {mining_time = 5, result = "feeder"},
    max_health = 150,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "small-remnants",
	collision_mask = {"ground-tile", "object-layer" },
    collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{ -0.5, -0.6}, {0.5, 0.4}},
    inventory_size = 1,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__hardcorio__/graphics/entity/player/feeder.png",
      priority = "extra-high",
      width = 90,
      height = 72,
      shift = {0.31, -0.11},
	  scale = 1
    },
    circuit_wire_connection_point = circuit_connector_definitions["feeder"].points,
    circuit_connector_sprites = circuit_connector_definitions["feeder"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  
  {
    type = "item",
    name = "incubator",
    icon = "__hardcorio__/graphics/icons/building/incubator.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "livesupport",
    order = "a[incubator]",
    place_result = "incubator-pump",
    stack_size = 50
  },
  {
    type = "offshore-pump",
    name = "incubator-pump",
    icon = "__hardcorio__/graphics/icons/building/incubator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "not-blueprintable", "filter-directions"},
    collision_mask = { "ground-tile", "object-layer" },
    minable = {mining_time = 5, result = "incubator"},
    max_health = 150,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "small-remnants",
    fluid = "water",
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    collision_box = {{ -0.4, -0.45}, {0.4, 0.3}},
    selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
    fluid_box =
    {
      pipe_connections =
      {
        { position = {0, 1} },
      },
    },
    pumping_speed = 1,
    tile_width = 1,
    picture =
    {
      north =
      {
        filename = "__hardcorio__/graphics/entity/player/incubator.png",
        priority = "extra-high",
        width = 90,
        height = 80,
        shift = {0.15, -0.05},
	    scale = 0.5
      },
      east =
      {
        filename = "__hardcorio__/graphics/entity/player/incubator.png",
        priority = "extra-high",
        width = 90,
        height = 80,
        shift = {0.15, -0.05},
	    scale = 0.5
      },
      south =
      {
        filename = "__hardcorio__/graphics/entity/player/incubator.png",
        priority = "extra-high",
        width = 90,
        height = 80,
        shift = {0.15, -0.05},
	    scale = 0.5
      },
      west =
      {
        filename = "__hardcorio__/graphics/entity/player/incubator.png",
        priority = "extra-high",
        width = 90,
        height = 80,
        shift = {0.15, -0.05},
	    scale = 0.5
      }
    },
    placeable_position_visualization =
    {
      filename = "__core__/graphics/cursor-boxes-32x32.png",
      priority = "extra-high-no-scale",
      width = 64,
      height = 64,
      scale = 0.5,
      x = 3*64
    },
  },
  
  {
    type = "container",
    name = "incubator",
    icon = "__hardcorio__/graphics/icons/building/incubator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "not-blueprintable"},
    minable = {mining_time = 5, result = "incubator"},
    subgroup = "raw-material",
    order = "c[incubator]",
    max_health = 150,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "small-remnants",
    collision_box = {{ -0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
    inventory_size = 1,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__hardcorio__/graphics/entity/player/incubator.png",
      priority = "extra-high",
      width = 90,
      height = 80,
      shift = {0.15, -0.05},
	  scale = 0.5
    },
    circuit_wire_connection_point = circuit_connector_definitions["incubator"].points,
    circuit_connector_sprites = circuit_connector_definitions["incubator"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
})