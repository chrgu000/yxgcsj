
circuit_connector_definitions["support-tank"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 27, main_offset = util.by_pixel(33.5/1.5, 18.5/1.5), shadow_offset = util.by_pixel(33.5/1.5, 18.5/1.5), show_shadow = false },
    { variation = 25, main_offset = util.by_pixel(-33.5/1.5, 19.5/1.5), shadow_offset = util.by_pixel(-33.5/1.5, 19.5/1.5), show_shadow = false },
    { variation = 27, main_offset = util.by_pixel(33.5/1.5, 18.5/1.5), shadow_offset = util.by_pixel(33.5/1.5, 18.5/1.5), show_shadow = false },
    { variation = 25, main_offset = util.by_pixel(-33.5/1.5, 19.5/1.5), shadow_offset = util.by_pixel(-33.5/1.5, 19.5/1.5), show_shadow = false },
  }
)

data:extend(
{
  {
    type = "item",
    name = "uranium-stone",
    icon = "__hardcorio__/graphics/icons/building/uranium-stone.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "d[uranium-stone]",
    stack_size = 50
  },
  {
    type = "item",
    name = "uranium-brick",
    icon = "__hardcorio__/graphics/icons/building/uranium-brick.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "e[uranium-brick]",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-wall",
    icon = "__hardcorio__/graphics/icons/building/uranium-wall.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "b[uranium-wall]-a[uranium-wall]",
    place_result = "uranium-wall",
    stack_size = 100
  },
  {
    type = "item",
    name = "uranium-gate",
    icon = "__hardcorio__/graphics/icons/building/uranium-gate.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "b[uranium-wall]-b[uranium-gate]",
    place_result = "uranium-gate",
    stack_size = 50
  },
  {
    type = "wall",
    name = "uranium-wall",
    icon = "__hardcorio__/graphics/icons/building/uranium-wall.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    minable = {mining_time = 1, result = "uranium-wall"},
    fast_replaceable_group = "wall",
    max_health = 350,
    repair_speed_modifier = 8,
    corpse = "uranium-wall-remnants",
    repair_sound = { filename = "__base__/sound/manual-repair-simple.ogg" },
    mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
    vehicle_impact_sound =  { filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
    -- this kind of code can be used for having walls mirror the effect
    -- there can be multiple reaction items
    --attack_reaction =
    --{
      --{
        ---- how far the mirroring works
        --range = 2,
        ---- what kind of damage triggers the mirroring
        ---- if not present then anything triggers the mirroring
        --damage_type = "physical",
        ---- caused damage will be multiplied by this and added to the subsequent damages
        --reaction_modifier = 0.1,
        --action =
        --{
          --type = "direct",
          --action_delivery =
          --{
            --type = "instant",
            --target_effects =
            --{
              --type = "damage",
              ---- always use at least 0.1 damage
              --damage = {amount = 0.1, type = "physical"}
            --}
          --}
        --},
      --}
    --},
    connected_gate_visualization =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      scale = 0.5
    },
    resistances =
    {
      {
        type = "impact",
        decrease = 45,
        percent = 70
      },
      {
        type = "claw",
        percent = 70
      },
      {
        type = "acid",
        percent = 15
      },
      {
        type = "explosion",
        decrease = 15,
        percent = 30
      },
      {
        type = "fire",
        percent = 100
      },
      {
        type = "piercing",
        percent = 100
      },
      {
        type = "physical",
        percent = 100
      }
    },
    pictures =
    {
      single =
      {
        layers = 
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-single.png",
            priority = "extra-high",
            width = 22,
            height = 42,
            shift = {0, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-single-shadow.png",
            priority = "extra-high",
            width = 47,
            height = 32,
            shift = {0.359375, 0.5},
            draw_as_shadow = true
          }
        }
      },
      straight_vertical =
      {
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-vertical-1.png",
              priority = "extra-high",
              width = 22,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
              priority = "extra-high",
              width = 47,
              height = 60,
              shift = {0.390625, 0.625},
              draw_as_shadow = true
            }
          }
        },
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-vertical-2.png",
              priority = "extra-high",
              width = 22,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
              priority = "extra-high",
              width = 47,
              height = 60,
              shift = {0.390625, 0.625},
              draw_as_shadow = true
            }
          }
        },
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-vertical-3.png",
              priority = "extra-high",
              width = 22,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
              priority = "extra-high",
              width = 47,
              height = 60,
              shift = {0.390625, 0.625},
              draw_as_shadow = true
            }
          }
        }
      },
      straight_horizontal =
      {
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-horizontal-1.png",
              priority = "extra-high",
              width = 32,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
              priority = "extra-high",
              width = 59,
              height = 32,
              shift = {0.421875, 0.5},
              draw_as_shadow = true
            }
          }
        },
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-horizontal-2.png",
              priority = "extra-high",
              width = 32,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
              priority = "extra-high",
              width = 59,
              height = 32,
              shift = {0.421875, 0.5},
              draw_as_shadow = true
            }
          }
        },
        {
          layers =
          {
            {
              filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-straight-horizontal-3.png",
              priority = "extra-high",
              width = 32,
              height = 42,
              shift = {0, -0.15625}
            },
            {
              filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
              priority = "extra-high",
              width = 59,
              height = 32,
              shift = {0.421875, 0.5},
              draw_as_shadow = true
            }
          }
        }
      },
      corner_right_down =
      {
        layers =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-corner-right-down.png",
            priority = "extra-high",
            width = 27,
            height = 42,
            shift = {0.078125, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-corner-right-down-shadow.png",
            priority = "extra-high",
            width = 53,
            height = 61,
            shift = {0.484375, 0.640625},
            draw_as_shadow = true
          }
        }
      },
      corner_left_down =
      {
        layers =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-corner-left-down.png",
            priority = "extra-high",
            width = 27,
            height = 42,
            shift = {-0.078125, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-corner-left-down-shadow.png",
            priority = "extra-high",
            width = 53,
            height = 60,
            shift = {0.328125, 0.640625},
            draw_as_shadow = true
          }
        }
      },
      t_up =
      {
        layers =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-t-down.png",
            priority = "extra-high",
            width = 32,
            height = 42,
            shift = {0, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-t-down-shadow.png",
            priority = "extra-high",
            width = 71,
            height = 61,
            shift = {0.546875, 0.640625},
            draw_as_shadow = true
          }
        }
      },
      ending_right =
      {
        layers =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-ending-right.png",
            priority = "extra-high",
            width = 27,
            height = 42,
            shift = {0.078125, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-ending-right-shadow.png",
            priority = "extra-high",
            width = 53,
            height = 32,
            shift = {0.484375, 0.5},
            draw_as_shadow = true
          }
        }
      },
      ending_left =
      {
        layers =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-ending-left.png",
            priority = "extra-high",
            width = 27,
            height = 42,
            shift = {-0.078125, -0.15625}
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-ending-left-shadow.png",
            priority = "extra-high",
            width = 53,
            height = 32,
            shift = {0.328125, 0.5},
            draw_as_shadow = true
          }
        }
      },
      water_connection_patch =
      {
        sheets =
        {
          {
            filename = "__hardcorio__/graphics/entity/player/uranium-wall/wall-patch.png",
            priority = "extra-high",
            width = 52,
            height = 68,
            shift = util.by_pixel(0, -2),
          },
          {
            filename = "__base__/graphics/entity/stone-wall/wall-patch-shadow.png",
            priority = "extra-high",
            draw_as_shadow = true,
            width = 74,
            height = 96,
            shift = util.by_pixel(6, 13),
          }
        }
      }
    },

    wall_diode_green = util.conditional_return(not data.is_demo,
        {
          filename = "__base__/graphics/entity/gate/wall-diode-green.png",
          width = 21,
          height = 22,
          shift = {0, -0.78125}
        }),
    wall_diode_green_light = util.conditional_return(not data.is_demo,
        {
          minimum_darkness = 0.3,
          color = {g=1},
          shift = {0, -0.78125},
          size = 1,
          intensity = 0.3
        }),
    wall_diode_red = util.conditional_return(not data.is_demo,
    {
      filename = "__base__/graphics/entity/gate/wall-diode-red.png",
      width = 21,
      height = 22,
      shift = {0, -0.78125}
    }),
    wall_diode_red_light = util.conditional_return(not data.is_demo,
    {
      minimum_darkness = 0.3,
      color = {r=1},
      shift = {0, -0.78125},
      size = 1,
      intensity = 0.3
    }),

    circuit_wire_connection_point = circuit_connector_definitions["gate"].points,
    circuit_connector_sprites = circuit_connector_definitions["gate"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance,
    default_output_signal = data.is_demo and {type = "virtual", name = "signal-green"} or {type = "virtual", name = "signal-G"}
  },
  {
    type = "corpse",
    name = "uranium-wall-remnants",
    icon = "__base__/graphics/icons/wall-remnants.png",
    icon_size = 32,
    flags = {"placeable-neutral", "not-on-map"},
    subgroup="remnants",
    order="d[remnants]-c[wall]",
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selectable_in_game = false,
    time_before_removed = 60 * 60 * 15, -- 15 minutes
    final_render_layer = "remnants",
    animation =
    {
      {
        width = 36,
        height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-01.png"
      },
      {
        width = 38,
        height = 35,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-02.png"
      },
      {
        width = 35,
        height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-03.png"
      },
      {
        width = 41,
        height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-04.png"
      },
      {
        width = 35,
        height = 35,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-05.png"
      },
      {
        width = 50,
        height = 37,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-06.png"
      },
      {
        width = 54,
        height = 40,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-07.png"
      },
      {
        width = 43,
        height = 45,
        frame_count = 1,
        direction_count = 1,
        filename = "__hardcorio__/graphics/entity/player/uranium-wall/remains/wall-remain-08.png"
      }
    }
  },

  {
    type = "gate",
    name = "uranium-gate",
    icon = "__hardcorio__/graphics/icons/building/uranium-gate.png",
    icon_size = 32,
    flags = {"placeable-neutral","placeable-player", "player-creation"},
    fast_replaceable_group = "wall",
    minable = {hardness = 0.2, mining_time = 0.5, result = "uranium-gate"},
    max_health = 350,
    repair_speed_modifier = 6,
    corpse = "small-remnants",
    collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    opening_speed = 0.0666666,
    activation_distance = 3,
    timeout_to_close = 5,
    resistances =
    {
      {
        type = "impact",
        decrease = 45,
        percent = 70
      },
      {
        type = "claw",
        percent = 70
      },
      {
        type = "acid",
        percent = 15
      },
      {
        type = "explosion",
        decrease = 15,
        percent = 30
      },
      {
        type = "fire",
        percent = 100
      },
      {
        type = "piercing",
        percent = 100
      },
      {
        type = "physical",
        percent = 100
      }
    },
    vertical_animation =
    {
      layers =
      {
        {
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-vertical.png",
          line_length = 8,
          width = 21,
          height = 60,
          frame_count = 16,
          shift = {0.015625, -0.40625}
        },
        { 
          filename = "__base__/graphics/entity/gate/gate-vertical-shadow.png",
          line_length = 8,
          width = 41,
          height = 50,
          frame_count = 16,
          shift = {0.328125, 0.3},
          draw_as_shadow = true
        }
      }
    },
    horizontal_animation =
    {
      layers =
      {
        { 
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-horizontal.png",
          line_length = 8,
          width = 32,
          height = 36,
          frame_count = 16,
          shift = {0, -0.21875}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-horizontal-shadow.png",
          line_length = 8,
          width = 62,
          height = 28,
          frame_count = 16,
          shift = {0.4375, 0.46875},
          draw_as_shadow = true
        }
      }
    },
    vertical_base =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/gate/gate-base-vertical.png",
          width = 32,
          height = 32
        },
        {
          filename = "__base__/graphics/entity/gate/gate-base-vertical-mask.png",
          width = 32,
          height = 32,
          apply_runtime_tint = true
        }
      }
    },
    horizontal_rail_animation_left =
    {
      layers =
      {
        {
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-rail-horizontal-left.png",
          line_length = 8,
          width = 32,
          height = 47,
          frame_count = 16,
          shift = {0, -0.140625 + 0.125}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-rail-horizontal-shadow-left.png",
          line_length = 8,
          width = 73,
          height = 27,
          frame_count = 16,
          shift = {0.078125, 0.171875 + 0.125},
          draw_as_shadow = true
        }
      }
    },
    horizontal_rail_animation_right =
    {
      layers =
      {
        {
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-rail-horizontal-right.png",
          line_length = 8,
          width = 32,
          height = 43,
          frame_count = 16,
          shift = {0, -0.203125 + 0.125}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-rail-horizontal-shadow-right.png",
          line_length = 8,
          width = 73,
          height = 28,
          frame_count = 16,
          shift = {0.60938, 0.2875 + 0.125},
          draw_as_shadow = true
        }
      }
    },
    vertical_rail_animation_left =
    {
      layers =
      {
        { 
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-rail-vertical-left.png",
          line_length = 8,
          width = 22,
          height = 54,
          frame_count = 16,
          shift = {0, -0.46875}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-rail-vertical-shadow-left.png",
          line_length = 8,
          width = 47,
          height = 48,
          frame_count = 16,
          shift = {0.27, -0.16125 + 0.5},
          draw_as_shadow = true
        }
      }
    },
    vertical_rail_animation_right =
    {
      layers =
      {
        {
          filename = "__hardcorio__/graphics/entity/player/uranium-wall/gate-rail-vertical-right.png",
          line_length = 8,
          width = 22,
          height = 55,
          frame_count = 16,
          shift = {0, -0.453125}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-rail-vertical-shadow-right.png",
          line_length = 8,
          width = 47,
          height = 47,
          frame_count = 16,
          shift = {0.27, 0.803125 - 0.5},
          draw_as_shadow = true
        }
      }
    },
    vertical_rail_base =
    {
      filename = "__base__/graphics/entity/gate/gate-rail-base-vertical.png",
      line_length = 8,
      width = 64,
      height = 64,
      frame_count = 16,
      shift = {0, 0},
    },
    horizontal_rail_base =
    {
      filename = "__base__/graphics/entity/gate/gate-rail-base-horizontal.png",
      line_length = 8,
      width = 64,
      height = 45,
      frame_count = 16,
      shift = {0, -0.015625 + 0.125},
    },
    vertical_rail_base_mask =
    {
      filename = "__base__/graphics/entity/gate/gate-rail-base-mask-vertical.png",
      width = 63,
      height = 39,
      shift = {0.015625, -0.015625},
      apply_runtime_tint = true
    },
    horizontal_rail_base_mask =
    {
      filename = "__base__/graphics/entity/gate/gate-rail-base-mask-horizontal.png",
      width = 53,
      height = 45,
      shift = {0.015625, -0.015625 + 0.125},
      apply_runtime_tint = true
    },
    horizontal_base =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/gate/gate-base-horizontal.png",
          width = 32,
          height = 23,
          shift = {0, 0.125}
        },
        {
          filename = "__base__/graphics/entity/gate/gate-base-horizontal-mask.png",
          width = 32,
          height = 23,
          apply_runtime_tint = true,
          shift = {0, 0.125}
        }
      }
    },
    wall_patch =
    {
      north =
      {
        layers =
        {
          {
            filename = "__base__/graphics/entity/gate/wall-patch-north.png",
            width = 22,
            height = 35,
            shift = {0, -0.62 + 1}
          },
          {
            filename = "__base__/graphics/entity/gate/wall-patch-north-shadow.png",
            width = 46,
            height = 31,
            shift = {0.3, 0.20 + 1},
            draw_as_shadow = true
          }
        }
      },
      east =
      {
        layers =
        {
          {
            filename = "__base__/graphics/entity/gate/wall-patch-east.png",
            width = 11,
            height = 40,
            shift = {0.328125 - 1, -0.109375}
          },
          {
            filename = "__base__/graphics/entity/gate/wall-patch-east-shadow.png",
            width = 38,
            height = 32,
            shift = {0.8125 - 1, 0.46875},
            draw_as_shadow = true
          }
        }
      },
      south =
      {
        layers =
        {
          {
            filename = "__base__/graphics/entity/gate/wall-patch-south.png",
            width = 22,
            height = 40,
            shift = {0, -0.125}
          },
          {
            filename = "__base__/graphics/entity/gate/wall-patch-south-shadow.png",
            width = 48,
            height = 25,
            shift = {0.3, 0.95},
            draw_as_shadow = true
          }
        }
      },
      west =
      {
        layers =
        {
          {
            filename = "__base__/graphics/entity/gate/wall-patch-west.png",
            width = 11,
            height = 40,
            shift = {-0.328125 + 1, -0.109375}
          },
          {
            filename = "__base__/graphics/entity/gate/wall-patch-west-shadow.png",
            width = 46,
            height = 32,
            shift = {0.1875 + 1, 0.46875},
            draw_as_shadow = true
          }
        }
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    open_sound =
    {
      variations = { filename = "__base__/sound/gate1.ogg", volume = 0.5 },
      aggregation =
      {
        max_count = 1,
        remove = true
      }
    },
    close_sound =
    {
      variations = { filename = "__base__/sound/gate1.ogg", volume = 0.5 },
      aggregation =
      {
        max_count = 1,
        remove = true
      }
    }
  },
  
{
    type = "storage-tank",
    name = "support-tank",
    icon = "__hardcorio__/graphics/icons/items/support-tank.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 3, result = "support-tank"},
    max_health = 500,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      }
    },
    fluid_box =
    {
      base_area = 250,
      pipe_covers = pipecoverspictures(),
      pipe_connections =
      {
        { position = {-1/1.5, -2/1.5} },
        { position = {2/1.5, 1/1.5} },
        { position = {1/1.5, 2/1.5} },
        { position = {-2/1.5, -1/1.5} },
      },
    },
    two_direction_only = true,
    window_bounding_box = {{-0.125/1.5, 0.6875/1.5}, {0.1875/1.5, 1.1875/1.5}},
    pictures =
    {
      picture =
      {
        sheets =
        {
          {
            filename = "__base__/graphics/entity/storage-tank/storage-tank.png",
            priority = "extra-high",
            frames = 2,
            width = 110,
            height = 108,
            shift = util.by_pixel(0, 4),
            scale = 1/1.5,
            hr_version = {
              filename = "__base__/graphics/entity/storage-tank/hr-storage-tank.png",
              priority = "extra-high",
              frames = 2,
              width = 219,
              height = 215,
              shift = util.by_pixel(-0.25, 3.75),
              scale = 0.5/1.5
            }
          },
          {
            filename = "__base__/graphics/entity/storage-tank/storage-tank-shadow.png",
            priority = "extra-high",
            frames = 2,
            width = 146,
            height = 77,
            shift = util.by_pixel(30, 22.5),
            scale = 1/1.5,
            draw_as_shadow = true,
            hr_version = {
              filename = "__base__/graphics/entity/storage-tank/hr-storage-tank-shadow.png",
              priority = "extra-high",
              frames = 2,
              width = 291,
              height = 153,
              shift = util.by_pixel(29.75, 22.25),
              scale = 0.5/1.5,
              draw_as_shadow = true
            }
          }
        }
      },
      fluid_background =
      {
        filename = "__base__/graphics/entity/storage-tank/fluid-background.png",
        priority = "extra-high",
        width = 32,
        height = 15
      },
      window_background =
      {
        filename = "__base__/graphics/entity/storage-tank/window-background.png",
        priority = "extra-high",
        width = 17,
        height = 24
      },
      flow_sprite =
      {
        filename = "__base__/graphics/entity/pipe/fluid-flow-low-temperature.png",
        priority = "extra-high",
        width = 160,
        height = 20
      },
      gas_flow =
      {
        filename = "__base__/graphics/entity/pipe/steam.png",
        priority = "extra-high",
        line_length = 10,
        width = 24,
        height = 15,
        frame_count = 60,
        axially_symmetrical = false,
        direction_count = 1,
        animation_speed = 0.25,
        hr_version =
        {
          filename = "__base__/graphics/entity/pipe/hr-steam.png",
          priority = "extra-high",
          line_length = 10,
          width = 48,
          height = 30,
          frame_count = 60,
          axially_symmetrical = false,
          animation_speed = 0.25,
          direction_count = 1
        }
      }
    },
    flow_length_in_ticks = 360,
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
          filename = "__base__/sound/storage-tank.ogg",
          volume = 0.8
      },
      apparent_volume = 1.5,
      max_sounds_per_type = 3
    },

    circuit_wire_connection_points = circuit_connector_definitions["support-tank"].points,
    circuit_connector_sprites = circuit_connector_definitions["support-tank"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },

{
    type = "item",
    name = "ship-wreak-1",
    icon = "__base__/graphics/icons/ship-wreck/big-ship-wreck-2.png",
    icon_size = 32,
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "defensive-structure",
    order = "a-a",
    place_result = "ship-wreak-1",
    stack_size = 5
  },
{
    type = "lab",
    name = "ship-wreak-1",
    icon = "__base__/graphics/icons/ship-wreck/big-ship-wreck-2.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-blueprintable", "not-deconstructable"},
    max_health = 350,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.4, -1.2}, {1.4, 1.2}},
    selection_box = {{-1.4, -1.2}, {1.4, 1.2}},
    on_animation =
    {
      filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-2.png",
      width = 164,
      height = 129,
      shift = {-0.5, 0.6},
      frame_count = 1,
      line_length = 1,
      animation_speed = 1,
    },
    off_animation =
    {
      filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-2.png",
      width = 164,
      height = 129,
	  frame_count = 1,
      shift = {-0.5, 0.6}
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_usage = "100kW",
    inputs =
    {
	  "science-pack-1",
      "enemy-dna",
	  "elerium",
    },
    module_slots = 0
  },
  {
    type = "item",
    name = "ship-wreak-2",
    icon = "__base__/graphics/icons/ship-wreck/big-ship-wreck-1.png",
    icon_size = 32,
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "defensive-structure",
    order = "a-a",
    place_result = "ship-wreak-2",
    stack_size = 5
  },
  {
    type = "logistic-container",
    name = "ship-wreak-2",
    icon = "__base__/graphics/icons/ship-wreck/big-ship-wreck-1.png",
    icon_size = 32,
    flags = {"not-repairable", "not-blueprintable", "not-deconstructable"},
    max_health = 1500,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "small-remnants",
    collision_box = {{-2.2, -1.5}, {2.2, 1.5}},
    selection_box = {{-2.2, -1.5}, {2.2, 1.5}},
    inventory_size = 1,
	dying_explosion = "medium-explosion",
    logistic_mode = "requester",
    logistic_slots_count = 12,
    picture =
    {
      filename = "__base__/graphics/entity/ship-wreck/big-ship-wreck-1.png",
      width = 256,
      height = 212,
      shift = {0.7, 0},
      priority = "extra-high"
    }
  },
  {
    type = "item",
    name = "new-ship-carcase",
    icon = "__hardcorio__/graphics/icons/building/new-ship-carcase.png",
    icon_size = 32,
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "defensive-structure",
    order = "a-a",
    place_result = "new-ship-carcase",
    stack_size = 5
  },
  {
    type = "logistic-container",
    name = "new-ship-carcase",
    icon = "__hardcorio__/graphics/icons/building/new-ship-carcase.png",
    icon_size = 32,
    flags = {"not-repairable", "not-blueprintable", "not-deconstructable"},
    max_health = 3000,
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "small-remnants",
    collision_box = {{-4, -2.7}, {3.5, 2}},
    selection_box = {{-4, -2.7}, {3.5, 2}},
    inventory_size = 1,
	dying_explosion = "medium-explosion",
    logistic_mode = "requester",
    logistic_slots_count = 12,
    picture =
    {
      filename = "__hardcorio__/graphics/entity/player/new-ship-carcase.png",
      width = 539,
      height = 454,
	  scale=0.7,
      shift = {0, -1},
      priority = "extra-high"
    }
  },
    {
    type = "item",
    name = "new-ship-sars",
    icon = "__hardcorio__/graphics/icons/building/new-ship-carcase.png",
    icon_size = 32,
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "defensive-structure",
    order = "a-a",
    place_result = "new-ship-sars",
    stack_size = 5
  },
  {
    type = "lab",
    name = "new-ship-sars",
    icon = "__hardcorio__/graphics/icons/building/new-ship-carcase.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-blueprintable", "not-deconstructable"},
    max_health = 10000,
    collision_box = {{-4, -2.7}, {3.5, 2}},
    selection_box = {{-4, -2.7}, {3.5, 2}},
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    on_animation =
    {
      filename = "__hardcorio__/graphics/entity/player/new-ship-sars.png",
      width = 539,
      height = 454,
	  scale=0.7,
      shift = {0, -1},
      frame_count = 1,
      line_length = 1,
      animation_speed = 1,
    },
    off_animation =
    {
      filename = "__hardcorio__/graphics/entity/player/new-ship-sars.png",
      width = 539,
      height = 454,
	  scale=0.7,
      shift = {0, -1},
	  frame_count = 1,
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_usage = "1000kW",
    inputs =
    {
	  "science-pack-1",
      "enemy-dna",
	  "elerium",
    },
    module_slots = 0
  },
  
  {
    type = "furnace",
    name = "compressor",
    icon = "__hardcorio__/graphics/icons/building/compressor.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "compressor"},
    max_health = 150,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      }
    },
	collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
	selection_box = {{ -0.9, -0.9}, {0.9, 0.9}},
	animation =
	{
			filename = "__hardcorio__/graphics/entity/player/building/compressor.png",
		priority = "medium",
		width = 100,
		scale = 0.66,
		height = 120,
		frame_count = 11,
		line_length = 11,
		shift = {0.1, -0.1},
		animation_speed = 0.8
	},
    crafting_categories = {"compressing"},
	module_specification =
    {
      module_slots = 2,
      module_info_icon_shift = {0, 0.7}
    },
	allowed_effects = {"consumption", "speed", "pollution"},
	result_inventory_size = 1,
	source_inventory_size = 1,
    crafting_speed = 0.8,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.03
    },
    energy_usage = "180kW",
    ingredient_count = 1,
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t1-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t1-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    },
  },
  
   {
    type = "assembling-machine",
    name = "electrolizer",
    icon = "__hardcorio__/graphics/icons/building/electrolizer.png",
    icon_size = 32,
    flags = {"placeable-neutral","placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "electrolizer"},
    max_health = 300,
    corpse = "small-remnants",
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      }
    },
    animation =
    {
      north =
      {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-up.png",
        width = 46,
        height = 56,
        frame_count = 1,
        shift = {0.09375, 0.03125}
      },
      west =
      {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-left.png",
        width = 56,
        height = 44,
        frame_count = 1,
        shift = {0.3125, 0.0625}
      },
      south =
      {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-down.png",
        width = 61,
        height = 58,
        frame_count = 1,
        shift = {0.421875, -0.125},
      },
      east =
      {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-right.png",
        width = 51,
        height = 56,
        frame_count = 1,
        shift = {0.265625, -0.21875}
      }
    },
    working_visualisations =
    {
      {
        north_position = {0, 0},
        west_position = {0, 0},
        south_position = {0, 0},
        east_position = {0, 0},
        north_animation =
        {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-up.png",
          width = 46,
          height = 56,
          frame_count = 8,
          shift = {0.09375, 0.03125},
          animation_speed = 0.5,
          run_mode = "backward"
        },
        west_animation =
        {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-left.png",
          width = 56,
          height = 44,
          frame_count = 8,
          shift = {0.3125, 0.0625},
          animation_speed = 0.5,
          run_mode = "backward"
        },
        south_animation =
        {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-down.png",
          width = 61,
          height = 58,
          frame_count = 8,
          shift = {0.421875, -0.125},
          animation_speed = 0.5,
          run_mode = "backward"
        },
        east_animation =
        {
			filename = "__hardcorio__/graphics/entity/player/building/liquid-handler-right.png",
          width = 51,
          height = 56,
          frame_count = 8,
          shift = {0.265625, -0.21875},
          animation_speed = 0.5,
          run_mode = "backward"
        }
      }
    },
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.01 / 2.5
    },
    energy_usage = "100kW",
    ingredient_count = 10,
    crafting_categories = {"electrolize"},
    fluid_boxes =
    {
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 16,
        base_level = -1,
        pipe_connections = {{ type="input", position = {0, 1} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 16,
        pipe_connections = {{ position = {0, -1} }},
        off_when_no_fluid_recipe = true
      }
    }
  },
  {
    type = "resource",
    name = "elerium-ore",
    icon = "__hardcorio__/graphics/icons/building/elerium-ore.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-off-grid"},
    order="a-b-a",
    minable =
    {
      hardness = 0.9,
      mining_particle = "copper-ore-particle",
      mining_time = 40,
      result = "elerium-ore",
      fluid_amount = 100,
      required_fluid = "sulfuric-acid"
    },
    collision_box = {{ -0.5, -0.5}, {0.5, 0.5}},
    selection_box = {{ -0.7, -0.7}, {0.7, 0.7}},
    stage_counts = {100, 60, 40, 20, 10, 5, 2, 1},
    stages =
    {
      sheet =
      {
        filename = "__hardcorio__/graphics/entity/elerium-ore/elerium-ore.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        frame_count = 8,
        variation_count = 8,
        scale = 1.5,
        hr_version = {
          filename = "__hardcorio__/graphics/entity/elerium-ore/hr-elerium-ore.png",
          priority = "extra-high",
          width = 128,
          height = 128,
          frame_count = 8,
          variation_count = 8,
          scale = 0.75
        }
      }
    },
    stages_effect =
    {
      sheet =
      {
        filename = "__hardcorio__/graphics/entity/elerium-ore/elerium-ore-glow.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        frame_count = 8,
        variation_count = 8,
        scale = 1.5,
        blend_mode = "additive",
        flags = {"light"},
        hr_version = {
          filename = "__hardcorio__/graphics/entity/elerium-ore/hr-elerium-ore-glow.png",
          priority = "extra-high",
          width = 128,
          height = 128,
          frame_count = 8,
          variation_count = 8,
          scale = 0.75,
          blend_mode = "additive",
          flags = {"light"},
        }
      }
    },
    effect_animation_period = 5,
    effect_animation_period_deviation = 1,
    effect_darkness_multiplier = 3.6,
    min_effect_alpha = 0.2,
    max_effect_alpha = 0.3,
    map_color = {r=0, g=1, b=0, a=0.7},
    map_grid = false
  },
  
  {
    type = "furnace",
    name = "grinder",
    icon = "__hardcorio__/graphics/icons/building/grinder.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "grinder"},
    max_health = 150,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      }
    },
	collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
	selection_box = {{ -0.9, -0.9}, {0.9, 0.9}},
	animation =
	{
		filename = "__hardcorio__/graphics/entity/player/building/grinder.png",
		priority = "medium",
		width = 65,
		height = 78,
		scale = 0.9,
		frame_count = 11,
		line_length = 11,
		shift = {0.0, -0.0},
		animation_speed = 0.8
	},
    crafting_categories = {"grinding"},
	module_specification =
    {
      module_slots = 4,
      module_info_icon_shift = {0, 0.7}
    },
	allowed_effects = {"consumption", "speed", "productivity", "pollution"},
	result_inventory_size = 1,
	source_inventory_size = 1,
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.05
    },
    energy_usage = "360kW",
    ingredient_count = 1,
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t1-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t1-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    },
  },
})
