data:extend(
{
  {
    type = "player",
    name = "player-soldier",
    icon = "__base__/graphics/icons/player.png",
    icon_size = 32,
    flags = {"pushable", "placeable-off-grid",  "not-repairable", "not-on-map"},
    max_health = 300,
    alert_when_damaged = false,
    healing_per_tick = 0.045,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -1.4}, {0.4, 0.2}},
    crafting_categories = {"crafting"},
    mining_categories = {"basic-solid"},
    character_corpse = "character-corpse",
    inventory_size = 70,
    build_distance = 6,
    drop_item_distance = 3,
    reach_distance = 6,
    item_pickup_distance = 1,
    loot_pickup_distance = 2,
    reach_resource_distance = 2.7,
    ticks_to_keep_gun = 400,
    ticks_to_keep_aiming_direction = 100,
    ticks_to_stay_in_combat = 400,
    damage_hit_tint = {r = 1, g = 0, b = 0, a = 0},
    running_speed = 0.15,
    distance_per_frame = 0.1,
    maximum_corner_sliding_distance = 0.7,
    subgroup = "creatures",
    order="a",
    eat =
    {
      {
        filename = "__base__/sound/eat.ogg",
        volume = 1
      }
    },
    heartbeat =
    {
      {
        filename = "__base__/sound/heartbeat.ogg"
      }
    },

    animations =
    {
      {
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- heavy-armor is not in the demo
        armors = data.is_demo and {"light-armor"} or {"light-armor", "heavy-armor"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level2addon.idle,
            playeranimations.level2addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level2addon.idle_gun,
            playeranimations.level2addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level2addon.mining_hands,
            playeranimations.level2addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level2addon.mining_tool,
            playeranimations.level2addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level2addon.running_gun,
            playeranimations.level2addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level2addon.running,
            playeranimations.level2addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- modular armors are not in the demo
        armors = data.is_demo and {} or {"modular-armor", "power-armor", "power-armor-mk2"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level3addon.idle,
            playeranimations.level3addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level3addon.idle_gun,
            playeranimations.level3addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level3addon.mining_hands,
            playeranimations.level3addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level3addon.mining_tool,
            playeranimations.level3addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level3addon.running_gun,
            playeranimations.level3addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level3addon.running,
            playeranimations.level3addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      }
    },
    light =
    {
      {
        minimum_darkness = 0.3,
        intensity = 0.4,
        size = 25,
        color = {r=1.0, g=1.0, b=1.0}
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "extra-high",
          flags = { "light" },
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0, -13},
        size = 2,
        intensity = 0.6
      },
    },
    mining_speed = 0.01,
    mining_with_hands_particles_animation_positions = {29, 63},
    mining_with_tool_particles_animation_positions = {28},
    running_sound_animation_positions = {5, 16}
  },
  
  {
    type = "player",
    name = "player-assault",
    icon = "__base__/graphics/icons/player.png",
    icon_size = 32,
    flags = {"pushable", "placeable-off-grid",  "not-repairable", "not-on-map"},
    max_health = 300,
    alert_when_damaged = false,
    healing_per_tick = 0.03,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -1.4}, {0.4, 0.2}},
    crafting_categories = {"crafting"},
    mining_categories = {"basic-solid"},
    character_corpse = "character-corpse",
    inventory_size = 60,
    build_distance = 6,
    drop_item_distance = 3,
    reach_distance = 6,
    item_pickup_distance = 1,
    loot_pickup_distance = 2,
    reach_resource_distance = 2.7,
    ticks_to_keep_gun = 600,
    ticks_to_keep_aiming_direction = 100,
    ticks_to_stay_in_combat = 600,
    damage_hit_tint = {r = 1, g = 0, b = 0, a = 0},
    running_speed = 0.16,
    distance_per_frame = 0.1,
    maximum_corner_sliding_distance = 0.7,
    subgroup = "creatures",
    order="a",
    eat =
    {
      {
        filename = "__base__/sound/eat.ogg",
        volume = 1
      }
    },
    heartbeat =
    {
      {
        filename = "__base__/sound/heartbeat.ogg"
      }
    },

    animations =
    {
      {
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- heavy-armor is not in the demo
        armors = data.is_demo and {"light-armor"} or {"light-armor", "heavy-armor"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level2addon.idle,
            playeranimations.level2addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level2addon.idle_gun,
            playeranimations.level2addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level2addon.mining_hands,
            playeranimations.level2addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level2addon.mining_tool,
            playeranimations.level2addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level2addon.running_gun,
            playeranimations.level2addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level2addon.running,
            playeranimations.level2addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- modular armors are not in the demo
        armors = data.is_demo and {} or {"modular-armor", "power-armor", "power-armor-mk2"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level3addon.idle,
            playeranimations.level3addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level3addon.idle_gun,
            playeranimations.level3addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level3addon.mining_hands,
            playeranimations.level3addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level3addon.mining_tool,
            playeranimations.level3addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level3addon.running_gun,
            playeranimations.level3addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level3addon.running,
            playeranimations.level3addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      }
    },
    light =
    {
      {
        minimum_darkness = 0.3,
        intensity = 0.4,
        size = 25,
        color = {r=1.0, g=1.0, b=1.0}
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "extra-high",
          flags = { "light" },
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0, -13},
        size = 2,
        intensity = 0.6
      },
    },
    mining_speed = 0.01,
    mining_with_hands_particles_animation_positions = {29, 63},
    mining_with_tool_particles_animation_positions = {28},
    running_sound_animation_positions = {5, 16}
  },
  
  {
    type = "player",
    name = "player-support",
    icon = "__base__/graphics/icons/player.png",
    icon_size = 32,
    flags = {"pushable", "placeable-off-grid",  "not-repairable", "not-on-map"},
    max_health = 300,
    alert_when_damaged = false,
    healing_per_tick = 0.03,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -1.4}, {0.4, 0.2}},
    crafting_categories = {"crafting"},
    mining_categories = {"basic-solid"},
    character_corpse = "character-corpse",
    inventory_size = 90,
    build_distance = 9,
    drop_item_distance = 3,
    reach_distance = 6,
    item_pickup_distance = 1,
    loot_pickup_distance = 2,
    reach_resource_distance = 2.7,
    ticks_to_keep_gun = 600,
    ticks_to_keep_aiming_direction = 100,
    ticks_to_stay_in_combat = 600,
    damage_hit_tint = {r = 1, g = 0, b = 0, a = 0},
    running_speed = 0.14,
    distance_per_frame = 0.1,
    maximum_corner_sliding_distance = 0.7,
    subgroup = "creatures",
    order="a",
    eat =
    {
      {
        filename = "__base__/sound/eat.ogg",
        volume = 1
      }
    },
    heartbeat =
    {
      {
        filename = "__base__/sound/heartbeat.ogg"
      }
    },

    animations =
    {
      {
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- heavy-armor is not in the demo
        armors = data.is_demo and {"light-armor"} or {"light-armor", "heavy-armor"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level2addon.idle,
            playeranimations.level2addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level2addon.idle_gun,
            playeranimations.level2addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level2addon.mining_hands,
            playeranimations.level2addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level2addon.mining_tool,
            playeranimations.level2addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level2addon.running_gun,
            playeranimations.level2addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level2addon.running,
            playeranimations.level2addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- modular armors are not in the demo
        armors = data.is_demo and {} or {"modular-armor", "power-armor", "power-armor-mk2"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level3addon.idle,
            playeranimations.level3addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level3addon.idle_gun,
            playeranimations.level3addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level3addon.mining_hands,
            playeranimations.level3addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level3addon.mining_tool,
            playeranimations.level3addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level3addon.running_gun,
            playeranimations.level3addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level3addon.running,
            playeranimations.level3addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      }
    },
    light =
    {
      {
        minimum_darkness = 0.3,
        intensity = 0.4,
        size = 35,
        color = {r=1.0, g=1.0, b=1.0}
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "extra-high",
          flags = { "light" },
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.1, -16},
        size = 2.5,
        intensity = 0.6
      },
    },
    mining_speed = 0.012,
    mining_with_hands_particles_animation_positions = {29, 63},
    mining_with_tool_particles_animation_positions = {28},
    running_sound_animation_positions = {5, 16}
  },
  
  {
    type = "player",
    name = "player-heavy",
    icon = "__base__/graphics/icons/player.png",
    icon_size = 32,
    flags = {"pushable", "placeable-off-grid",  "not-repairable", "not-on-map"},
    max_health = 450,
    alert_when_damaged = false,
    healing_per_tick = 0.03,
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -1.4}, {0.4, 0.2}},
    crafting_categories = {"crafting"},
    mining_categories = {"basic-solid"},
    character_corpse = "character-corpse",
    inventory_size = 80,
    build_distance = 6,
    drop_item_distance = 3,
    reach_distance = 6,
    item_pickup_distance = 1,
    loot_pickup_distance = 2,
    reach_resource_distance = 2.7,
    ticks_to_keep_gun = 600,
    ticks_to_keep_aiming_direction = 100,
    ticks_to_stay_in_combat = 600,
    damage_hit_tint = {r = 1, g = 0, b = 0, a = 0},
    running_speed = 0.13,
    distance_per_frame = 0.1,
    maximum_corner_sliding_distance = 0.7,
    subgroup = "creatures",
    order="a",
    eat =
    {
      {
        filename = "__base__/sound/eat.ogg",
        volume = 1
      }
    },
    heartbeat =
    {
      {
        filename = "__base__/sound/heartbeat.ogg"
      }
    },

    animations =
    {
      {
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- heavy-armor is not in the demo
        armors = data.is_demo and {"light-armor"} or {"light-armor", "heavy-armor"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level2addon.idle,
            playeranimations.level2addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level2addon.idle_gun,
            playeranimations.level2addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level2addon.mining_hands,
            playeranimations.level2addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level2addon.mining_tool,
            playeranimations.level2addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level2addon.running_gun,
            playeranimations.level2addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level2addon.running,
            playeranimations.level2addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      },
      {
        -- modular armors are not in the demo
        armors = data.is_demo and {} or {"modular-armor", "power-armor", "power-armor-mk2"},
        idle =
        {
          layers =
          {
            playeranimations.level1.idle,
            playeranimations.level1.idle_mask,
            playeranimations.level3addon.idle,
            playeranimations.level3addon.idle_mask,
            playeranimations.level1.idle_shadow,
          }
        },
        idle_with_gun =
        {
          layers =
          {
            playeranimations.level1.idle_gun,
            playeranimations.level1.idle_gun_mask,
            playeranimations.level3addon.idle_gun,
            playeranimations.level3addon.idle_gun_mask,
            playeranimations.level1.idle_gun_shadow,
          }
        },
        mining_with_hands =
        {
          layers =
          {
            playeranimations.level1.mining_hands,
            playeranimations.level1.mining_hands_mask,
            playeranimations.level3addon.mining_hands,
            playeranimations.level3addon.mining_hands_mask,
            playeranimations.level1.mining_hands_shadow,
          }
        },
        mining_with_tool =
        {
          layers =
          {
            playeranimations.level1.mining_tool,
            playeranimations.level1.mining_tool_mask,
            playeranimations.level3addon.mining_tool,
            playeranimations.level3addon.mining_tool_mask,
            playeranimations.level1.mining_tool_shadow,
          }
        },
        running_with_gun =
        {
          layers =
          {
            playeranimations.level1.running_gun,
            playeranimations.level1.running_gun_mask,
            playeranimations.level3addon.running_gun,
            playeranimations.level3addon.running_gun_mask,
            playeranimations.level1.running_gun_shadow,
          }
        },
        running =
        {
          layers =
          {
            playeranimations.level1.running,
            playeranimations.level1.running_mask,
            playeranimations.level3addon.running,
            playeranimations.level3addon.running_mask,
            playeranimations.level1.running_shadow,
          }
        }
      }
    },
    light =
    {
      {
        minimum_darkness = 0.3,
        intensity = 0.4,
        size = 25,
        color = {r=1.0, g=1.0, b=1.0}
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "extra-high",
          flags = { "light" },
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0, -13},
        size = 2,
        intensity = 0.6
      },
    },
    mining_speed = 0.01,
    mining_with_hands_particles_animation_positions = {29, 63},
    mining_with_tool_particles_animation_positions = {28},
    running_sound_animation_positions = {5, 16}
  },
})
