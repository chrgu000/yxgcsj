data:extend(
{
	{
    type = "capsule",
    name = "robot-556x45",
    icon = "__base__/graphics/icons/defender.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    capsule_action =
    {
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 15,
        projectile_creation_distance = 0.6,
        range = 10,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "robot-556x45p",
              starting_speed = 0.3
            }
          }
        }
      }
    },
   subgroup = "556x45",
    order = "c-e",
    stack_size = 1
  },
	
	{
    type = "projectile",
    name = "robot-556x45p",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            show_in_tooltip = true,
            entity_name = "robot-556x45",
          },
        }
      }
    },
    enable_drawing_with_mask = true,
    animation = {
      layers = {
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/defender-capsule.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 28,
          height = 20,
          priority = "high"
        },
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/defender-capsule-mask.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 28,
          height = 20,
          priority = "high",
          apply_runtime_tint = true,
        },
      },
    },
    shadow =
    {
      filename = "__base__/graphics/entity/combat-robot-capsule/defender-capsule-shadow.png",
      flags = { "no-crop" },
      frame_count = 1,
      width = 26,
      height = 20,
      priority = "high"
    },
    smoke = capsule_smoke,
  },
	
	{
    type = "combat-robot",
    name = "robot-556x45",
    icon = "__base__/graphics/icons/defender.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-repairable", "placeable-off-grid", "not-on-map"},
    subgroup="capsule",
    order="e-a-a",
    max_health = 300,
    alert_when_damaged = false,
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      },
	  {
        type = "acid",
        percent = 30
      }
    },
    collision_box = {{0, 0}, {0, 0}},
	collision_mask = {"not-colliding-with-itself"},
	selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    distance_per_frame = 0.13,
    time_to_live = 60 * 3600,
    follows_player = true,
    friction = 0.01,
    range_from_player = 5.0,
    speed = 0.01,
    destroy_action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
            type = "create-entity",
            entity_name = "explosion"
        }
      }
    },
	attack_parameters =
    {
    type = "projectile",
    range = 20,
    cooldown = 6,
	sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/m60.wav",
          volume = 0.4
        }
      },
    ammo_type =
    {
      category = "556x45",
      action =
      {
		type = "direct",
		action_delivery =
		{
			{
			type = "instant",
			source_effects =
			{
				{
				type = "damage",
				damage = { amount = 0.28, type = "explosion"}
				}
			}	
			},
			{
			type = "projectile",
			projectile = "p556x45ap",
			starting_speed = 3,
			max_range = 24
			},
		}
	}}},
    idle =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot.png",
          priority = "high",
          line_length = 16,
          width = 32,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, 0.015625},
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot.png",
            priority = "high",
            line_length = 16,
            width = 56,
            height = 59,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, 0.25),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 18,
          height = 16,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.125},
          apply_runtime_tint = true,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 28,
            height = 21,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -4.75),
            apply_runtime_tint = true,
            scale = 0.5
          }
        },
      }
    },
    shadow_idle =
    {
      filename = "__base__/graphics/entity/defender-robot/defender-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 43,
      height = 23,
      frame_count = 1,
      direction_count = 16,
      shift = {0.859375, 0.609375},
      hr_version = {
        filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 88,
        height = 50,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(25.5, 19),
        scale = 0.5
      }
    },
    in_motion =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot.png",
          priority = "high",
          line_length = 16,
          width = 32,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, 0.015625},
          y = 33,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot.png",
            priority = "high",
            line_length = 16,
            width = 56,
            height = 59,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, 0.25),
            y = 59,
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 18,
          height = 16,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.125},
          apply_runtime_tint = true,
          y = 16,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 28,
            height = 21,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -4.75),
            apply_runtime_tint = true,
            y = 21,
            scale = 0.5
          }
        },
      }
    },
    shadow_in_motion =
    {
      filename = "__base__/graphics/entity/defender-robot/defender-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 43,
      height = 23,
      frame_count = 1,
      direction_count = 16,
      shift = {0.859375, 0.609375},
      hr_version = {
        filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 88,
        height = 50,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(25.5, 19),
        scale = 0.5
      }
    }
  },

	{
    type = "capsule",
    name = "robot-762x39",
    icon = "__base__/graphics/icons/distractor.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    capsule_action =
    {
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 15,
        projectile_creation_distance = 0.6,
        range = 10,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "robot-762x39p",
              starting_speed = 0.3
            }
          }
        }
      }
    },
	subgroup = "762x39",
    order = "c-e",
    stack_size = 1
  },
	
	{
    type = "projectile",
    name = "robot-762x39p",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            show_in_tooltip = true,
            entity_name = "robot-762x39",
          },
        }
      }
    },
    enable_drawing_with_mask = true,
    animation = {
      layers = {
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/distractor-capsule.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 36,
          height = 30,
          priority = "high"
        },
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/distractor-capsule-mask.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 36,
          height = 30,
          priority = "high",
          apply_runtime_tint = true,
        },
      },
    },
    shadow =
    {
      filename = "__base__/graphics/entity/combat-robot-capsule/distractor-capsule-shadow.png",
      flags = { "no-crop" },
      frame_count = 1,
      width = 40,
      height = 26,
      priority = "high"
    },
    smoke = capsule_smoke
  },
	
	{
    type = "combat-robot",
    name = "robot-762x39",
    icon = "__base__/graphics/icons/distractor.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-repairable", "placeable-off-grid", "not-on-map"},
    subgroup="capsule",
    order="e-a-a",
    max_health = 300,
    alert_when_damaged = false,
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      },
	  {
        type = "acid",
        percent = 30
      }
    },
    collision_box = {{0, 0}, {0, 0}},
	collision_mask = {"not-colliding-with-itself"},
	selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    distance_per_frame = 0.13,
    time_to_live = 60 * 3600,
    follows_player = true,
    friction = 0.01,
    range_from_player = 5.0,
    speed = 0.01,
    destroy_action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
            type = "create-entity",
            entity_name = "explosion"
        }
      }
    },
	attack_parameters =
    {
    type = "projectile",
    range = 24,
    cooldown = 12,
	sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/ak47.wav",
          volume = 0.4
        }
      },
    ammo_type =
    {
      category = "762x39",
      action =
      {
		type = "direct",
		action_delivery =
		{
			{
			type = "instant",
			source_effects =
			{
				{
				type = "damage",
				damage = { amount = 0.46, type = "explosion"}
				}
			}	
			},
			{
			type = "projectile",
			projectile = "p762x39fa",
			starting_speed = 3,
			max_range = 28
			},
		}
	}}},
    idle =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/distractor-robot/distractor-robot.png",
          priority = "high",
          line_length = 16,
          width = 38,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.078125},
          hr_version = {
            filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot.png",
            priority = "high",
            line_length = 16,
            width = 72,
            height = 62,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -2.5),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/distractor-robot/distractor-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 24,
          height = 21,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.203125},
          apply_runtime_tint = true,
          hr_version = {
            filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 42,
            height = 37,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -6.25),
            apply_runtime_tint = true,
            scale = 0.5
          }
        }
      }
    },
    shadow_idle =
    {
      filename = "__base__/graphics/entity/distractor-robot/distractor-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 40,
      height = 25,
      frame_count = 1,
      direction_count = 16,
      shift = {0.9375, 0.609375},
      hr_version = {
        filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 97,
        height = 59,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(32.5, 19.25),
        scale = 0.5
      }
    },
    in_motion =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/distractor-robot/distractor-robot.png",
          priority = "high",
          line_length = 16,
          width = 38,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.078125},
          y = 33,
          hr_version = {
            filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot.png",
            priority = "high",
            line_length = 16,
            width = 72,
            height = 62,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -2.5),
            y = 62,
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/distractor-robot/distractor-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 24,
          height = 21,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.203125},
          apply_runtime_tint = true,
          y = 21,
          hr_version = {
            filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 42,
            height = 37,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -6.25),
            apply_runtime_tint = true,
            y = 37,
            scale = 0.5
          }
        }
      }
    },
    shadow_in_motion =
    {
      filename = "__base__/graphics/entity/distractor-robot/distractor-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 40,
      height = 25,
      frame_count = 1,
      direction_count = 16,
      shift = {0.9375, 0.609375},
      hr_version = {
        filename = "__base__/graphics/entity/distractor-robot/hr-distractor-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 97,
        height = 59,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(32.5, 19.25),
        scale = 0.5
      }
    }
  },
	{
    type = "capsule",
    name = "robot-127x99",
    icon = "__base__/graphics/icons/destroyer.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    capsule_action =
    {
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 15,
        projectile_creation_distance = 0.6,
        range = 10,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "robot-127x99p",
              starting_speed = 0.3
            }
          }
        }
      }
    },
   subgroup = "127x99",
    order = "c-e",
    stack_size = 1
  },
	
	{
    type = "projectile",
    name = "robot-127x99p",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            show_in_tooltip = true,
            entity_name = "robot-127x99",
          },
        }
      }
    },
    enable_drawing_with_mask = true,
    animation = {
      layers = {
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/destroyer-capsule.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 42,
          height = 34,
          priority = "high"
        },
        {
          filename = "__base__/graphics/entity/combat-robot-capsule/destroyer-capsule-mask.png",
          flags = { "no-crop" },
          frame_count = 1,
          width = 42,
          height = 34,
          priority = "high",
          apply_runtime_tint = true,
        },
      },
    },
    shadow =
    {
      filename = "__base__/graphics/entity/combat-robot-capsule/destroyer-capsule-shadow.png",
      flags = { "no-crop" },
      frame_count = 1,
      width = 48,
      height = 32,
      priority = "high"
    },
    smoke = capsule_smoke
  },
	
	{
    type = "combat-robot",
    name = "robot-127x99",
    icon = "__base__/graphics/icons/destroyer.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-repairable", "placeable-off-grid", "not-on-map"},
    subgroup="capsule",
    order="e-a-a",
    max_health = 300,
    alert_when_damaged = false,
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      },
	  {
        type = "acid",
        percent = 30
      }
    },
    collision_box = {{0, 0}, {0, 0}},
	collision_mask = {"not-colliding-with-itself"},
	selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    distance_per_frame = 0.13,
    time_to_live = 60 * 3600,
    follows_player = true,
    friction = 0.01,
    range_from_player = 5.0,
    speed = 0.01,
    destroy_action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
            type = "create-entity",
            entity_name = "explosion"
        }
      }
    },
	attack_parameters =
    {
    type = "projectile",
    range = 28,
    cooldown = 100,
	sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/m82.wav",
          volume = 0.4
        }
      },
    ammo_type =
    {
      category = "127x99",
      action =
      {
		type = "direct",
		action_delivery =
		{
			{
			type = "instant",
			source_effects =
			{
				{
				type = "damage",
				damage = { amount = 3, type = "explosion"}
				}
			}	
			},
			{
			type = "projectile",
			projectile = "p127x99he",
			starting_speed = 3,
			max_range = 32
			},
		}
	}}},
    idle =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot.png",
          priority = "high",
          line_length = 32,
          width = 45,
          height = 39,
          y = 39,
          frame_count = 1,
          direction_count = 32,
          shift = {0.078125, -0.546875},
          hr_version = {
            filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot.png",
            priority = "high",
            line_length = 32,
            width = 88,
            height = 77,
            y = 77,
            frame_count = 1,
            direction_count = 32,
            shift = util.by_pixel(2.5, -17.25),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot-mask.png",
          priority = "high",
          line_length = 32,
          width = 27,
          height = 21,
          y = 21,
          frame_count = 1,
          direction_count = 32,
          shift = {0.078125, -0.734375},
          apply_runtime_tint = true,
          hr_version = {
            filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot-mask.png",
            priority = "high",
            line_length = 32,
            width = 52,
            height = 42,
            y = 42,
            frame_count = 1,
            direction_count = 32,
            shift = util.by_pixel(2.5, -23),
            apply_runtime_tint = true,
            scale = 0.5
          }
        },
      }
    },
    shadow_idle =
    {
      filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot-shadow.png",
      priority = "high",
      line_length = 32,
      width = 48,
      height = 32,
      frame_count = 1,
      direction_count = 32,
      shift = {0.78125, 0},
      hr_version = {
        filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot-shadow.png",
        priority = "high",
        line_length = 32,
        width = 108,
        height = 66,
        frame_count = 1,
        direction_count = 32,
        shift = util.by_pixel(23.5, 1),
        scale = 0.5
      }
    },
    in_motion =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot.png",
          priority = "high",
          line_length = 32,
          width = 45,
          height = 39,
          frame_count = 1,
          direction_count = 32,
          shift = {0.078125, -0.546875},
          hr_version = {
            filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot.png",
            priority = "high",
            line_length = 32,
            width = 88,
            height = 77,
            frame_count = 1,
            direction_count = 32,
            shift = util.by_pixel(2.5, -17.25),
            scale = 0.5
          }
        },
        {
          filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot-mask.png",
          priority = "high",
          line_length = 32,
          width = 27,
          height = 21,
          frame_count = 1,
          direction_count = 32,
          shift = {0.078125, -0.734375},
          apply_runtime_tint = true,
          hr_version = {
            filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot-mask.png",
            priority = "high",
            line_length = 32,
            width = 52,
            height = 42,
            frame_count = 1,
            direction_count = 32,
            shift = util.by_pixel(2.5, -23),
            apply_runtime_tint = true,
            scale = 0.5
          }
        }
      }
    },
    shadow_in_motion =
    {
      filename = "__base__/graphics/entity/destroyer-robot/destroyer-robot-shadow.png",
      priority = "high",
      line_length = 32,
      width = 48,
      height = 32,
      frame_count = 1,
      direction_count = 32,
      shift = {0.78125, 0},
      hr_version = {
        filename = "__base__/graphics/entity/destroyer-robot/hr-destroyer-robot-shadow.png",
        priority = "high",
        line_length = 32,
        width = 108,
        height = 66,
        frame_count = 1,
        direction_count = 32,
        shift = util.by_pixel(23.5, 1),
        scale = 0.5
      }
    }
  },
 {
    type = "combat-robot",
    name = "fake-robot",
    icon = "__base__/graphics/icons/defender.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-repairable", "placeable-off-grid", "not-on-map"},
    subgroup="capsule",
    order="e-a-a",
    max_health = 300,
    alert_when_damaged = false,
	resistances = 
    {
	  {
        type = "physical",
        percent = 100,
      },
	  {
        type = "fire",
		percent = 100,
      },
	  {
        type = "piercing",
        percent = 100,
      },
	  {
        type = "acid",
        percent = 30
      }
    },
    collision_box = {{0, 0}, {0, 0}},
	collision_mask = {"not-colliding-with-itself"},
	selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    distance_per_frame = 0.13,
    time_to_live = 60 * 3600,
    follows_player = true,
    friction = 1.5,
    range_from_player = 10,
    speed = 0.75,
    destroy_action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
            type = "create-entity",
            entity_name = "explosion"
        }
      }
    },
	attack_parameters =
    {
    type = "projectile",
    range = 3,
    cooldown = 100,
    ammo_type =
    {
     category = "105x",
     action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
          {
            type = "nested-result",
            affects_target = true,
            action =
            {
              type = "area",
              radius = 4,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects = 
                {
                  type = "damage",
                  damage = { amount = 50, type = "fire"}
                }
              }
            },
          },
          {
            type = "create-entity",
            entity_name = "medium-explosion"
          },
          {
            type = "damage",
            damage = { amount = 300, type = "explosion"}
          }
        }
      }
    }}},
    idle =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot.png",
          priority = "high",
          line_length = 16,
          width = 32,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, 0.015625*0.6},
          scale = 0.6,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot.png",
            priority = "high",
            line_length = 16,
            width = 56,
            height = 59,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, 0.25*0.6),
            scale = 0.5*0.6
          }
        },
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 18,
          height = 16,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.125*0.6},
          scale = 0.6,
          apply_runtime_tint = true,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 28,
            height = 21,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -4.75*0.6),
            apply_runtime_tint = true,
            scale = 0.5*0.6
          }
        },
      }
    },
    shadow_idle =
    {
      filename = "__base__/graphics/entity/defender-robot/defender-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 43,
      height = 23,
      frame_count = 1,
      direction_count = 16,
      shift = {0.859375*0.6, 0.609375*0.6},
      scale = 0.6,
      hr_version = {
        filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 88,
        height = 50,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(25.5*0.6, 19*0.6),
        scale = 0.5*0.6
      }
    },
    in_motion =
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot.png",
          priority = "high",
          line_length = 16,
          width = 32,
          height = 33,
          frame_count = 1,
          direction_count = 16,
          shift = {0, 0.015625*0.6},
          scale = 0.6,
          y = 33,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot.png",
            priority = "high",
            line_length = 16,
            width = 56,
            height = 59,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, 0.25*0.6),
            y = 59,
            scale = 0.5*0.6
          }
        },
        {
          filename = "__base__/graphics/entity/defender-robot/defender-robot-mask.png",
          priority = "high",
          line_length = 16,
          width = 18,
          height = 16,
          frame_count = 1,
          direction_count = 16,
          shift = {0, -0.125*0.6},
          scale = 0.6,
          apply_runtime_tint = true,
          y = 16,
          hr_version = {
            filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-mask.png",
            priority = "high",
            line_length = 16,
            width = 28,
            height = 21,
            frame_count = 1,
            direction_count = 16,
            shift = util.by_pixel(0, -4.75*0.6),
            apply_runtime_tint = true,
            y = 21,
            scale = 0.5*0.6
          }
        },
      }
    },
    shadow_in_motion =
    {
      filename = "__base__/graphics/entity/defender-robot/defender-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 43,
      height = 23,
      frame_count = 1,
      direction_count = 16,
      shift = {0.859375*0.6, 0.609375*0.6},
      scale = 0.6,
      hr_version = {
        filename = "__base__/graphics/entity/defender-robot/hr-defender-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 88,
        height = 50,
        frame_count = 1,
        direction_count = 16,
        shift = util.by_pixel(25.5*0.6, 19*0.6),
        scale = 0.5*0.6
      }
    }
  }, 
  
}
)
