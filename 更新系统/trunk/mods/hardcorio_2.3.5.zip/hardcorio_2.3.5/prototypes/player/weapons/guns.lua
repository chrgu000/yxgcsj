for i = 0,100 do
	local gun_flags = {"goes-to-main-inventory", "hidden"}
	if i == 0 then gun_flags = {"goes-to-main-inventory"} end
	
	
	data:extend({

	--medi-kit
	{
    type = "gun",
    name = "regenerator"..i,
    icon = "__hardcorio__/graphics/icons/weapons/regenerator.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "armor",
    order = "f-a",
     attack_parameters =
    {
      type = "projectile",
      ammo_category = "medi-kit",
      cooldown = 5,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.3-0.0015*i,
      projectile_creation_distance = 0,
      range = 10,
	  sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/heal.wav",
          volume = 0.7
        }
      }
    },
    stack_size = 1,
	},
	
	--shotgun
	{
    type = "gun",
    name = "new-shotgun"..i,
    icon = "__hardcorio__/graphics/icons/weapons/shotgun.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "127x33",
    order = "a-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "shotgun-shell",
      cooldown = 60,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.3-0.0015*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 16,
      sound =
      {
        {
          filename = "__base__/sound/pump-shotgun.ogg",
          volume = 0.7
        }
      }
    },
    stack_size = 1
	},
	
	--5.56
	{
    type = "gun",
    name = "m60"..i,
    icon = "__hardcorio__/graphics/icons/weapons/m60.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "556x45",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "556x45",
      cooldown = 6,
	  damage_modifier = (1+(i/1000*i))*2,
      movement_slow_down_factor = 0.6-0.003*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 25,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/m60.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "minigun"..i,
    icon = "__hardcorio__/graphics/icons/weapons/minigun.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "556x45",
    order = "b-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "556x45",
      cooldown = 2,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.9-0.0045*i,
	  shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 25,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/minigun.wav",
          volume = 0.7
        }
      }
    },
    stack_size = 1
	},
	
	--7.62
	{
    type = "gun",
    name = "ak47"..i,
    icon = "__hardcorio__/graphics/icons/weapons/ak47.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "762x39",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "762x39",
	  damage_modifier = (1+(i/1000*i))*1.5,
      cooldown = 10,
      movement_slow_down_factor = 0.3-0.0015*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 30,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/ak47.wav",
          volume = 0.7
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "rpk74"..i,
    icon = "__hardcorio__/graphics/icons/weapons/rpk74.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "762x39",
    order = "b-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "762x39",
      cooldown = 5,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.6-0.003*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 30,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/rpk74.wav",
          volume = 0.7
        }
      }
    },
    stack_size = 1
	},
	
	--12.7
	{
    type = "gun",
    name = "m82"..i,
    icon = "__hardcorio__/graphics/icons/weapons/m82.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "127x99",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "127x99",
	  warmup = 40-math.floor(0.2*i),
      cooldown = 60,
	  damage_modifier = (1+(i/1000*i))*2,
      movement_slow_down_factor = 0.25-0.0015*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 50,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/m82.wav",
          volume = 0.9
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "scopem82"..i,
    icon = "__hardcorio__/graphics/icons/weapons/m82s.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "127x99",
    order = "b-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "127x99",
	  warmup = 40-math.floor(0.2*i),
      cooldown = 90,
	  damage_modifier = (1+(i/1000*i))*3,
      movement_slow_down_factor = 0.25-0.0015*i,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0,1.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 50,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/m82.wav",
          volume = 0.9
        }
      }
    },
    stack_size = 1
	},
	
	--105
	{
    type = "gun",
    name = "rpg"..i,
    icon = "__hardcorio__/graphics/icons/weapons/rpg.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "grenade",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "105x",
      cooldown = 200-i,
	  damage_modifier = 1+(i/2000*i),
      movement_slow_down_factor = 0.6-0.003*i,
      projectile_creation_distance = 0,
      range = 40+0.5*i,
      sound =
      {
        {
          filename = "__hardcorio__/sound/player/weapons/rpg.wav",
          volume = 1
        }
      }
    },
    stack_size = 1
	},
	
	--energy
	{
    type = "gun",
    name = "laser-rifle"..i,
    icon = "__hardcorio__/graphics/icons/weapons/laser-rifle.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "laser",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps40",
      cooldown = 1,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.4-0.002*i,
      projectile_creation_distance = 0,
      range = 14,
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "gauss-rifle"..i,
    icon = "__hardcorio__/graphics/icons/weapons/gauss-rifle.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "laser",
    order = "c-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps2000",
      cooldown = 59,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.25-0.0015*i,
      projectile_creation_distance = 0,
      range = 30,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/ps3200.wav",
          volume = 0.8
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "plasma-shotgun"..i,
    icon = "__hardcorio__/graphics/icons/weapons/plasma-shotgun.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "plasma",
    order = "b-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps3200",
      cooldown = 30,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.3-0.0015*i,
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 30,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/ps3200.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "plasma-gun"..i,
    icon = "__hardcorio__/graphics/icons/weapons/plasma-gun.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "plasma",
    order = "c-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps200",
      cooldown = 2,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.9-0.0045*i,
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 40,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/ps200.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "plasma-sniper"..i,
    icon = "__hardcorio__/graphics/icons/weapons/plasma-sniper.png",
    icon_size = 32,
    flags = gun_flags,
    subgroup = "plasma",
    order = "d-a",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps4000",
	  warmup = 40-math.floor(0.2*i),
      cooldown = 60,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.6-0.003*i,
      projectile_creation_distance = 0,
      projectile_center = {0, -1},
      range = 80,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/ps4000.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	
	{
    type = "gun",
    name = "tank-cannon"..i,
    icon = "__hardcorio__/graphics/entity/player/tank/Tank-Cannon.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "c-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "125x",
      cooldown = 60,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.9,
      projectile_creation_distance = 0,
      projectile_center = {0, 0.3},
      range = 55,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/cannon.wav",
          volume = 0.8
        }
      }
    },
    stack_size = 1
	},
	{
    type = "gun",
    name = "tank-laser"..i,
    icon = "__hardcorio__/graphics/entity/player/tank/Tank-Laser.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "b-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "ps160",
      cooldown = 2,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.9,
      projectile_creation_distance = 0,
      projectile_center = {0, 0.3},
      range = 20,
    },
    stack_size = 1
	},
	{
    type = "gun",
    name = "tank-launcher"..i,
    icon = "__hardcorio__/graphics/entity/player/tank/Tank-Launcher.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "d-e",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "tank-rockets",
	  warmup = 20-math.floor(0.2*i),
      cooldown = 50,
	  damage_modifier = 1+(i/1000*i),
      movement_slow_down_factor = 0.9,
      projectile_creation_distance = 0,
      projectile_center = {0, 0.3},
      range = 50 + 0.5*i,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/rpg.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	{
    type = "gun",
    name = "tank-repair"..i,
    icon = "__hardcorio__/graphics/icons/weapons/repair-gun.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "a-c",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "repair-kit",
      cooldown = 120-1*i,
	  damage_modifier = 1+(i/1000*i),
      range = 0,
	  sound =
      {
        {
          filename = "__core__/sound/manual-repair-advanced-1.ogg",
          volume = 0.8
        },
        {
          filename = "__core__/sound/manual-repair-advanced-2.ogg",
          volume = 0.8
        },
      }
    },
    stack_size = 1
	}
})
end
data:extend({
	{
    type = "gun",
    name = "car-launcher",
    icon = "__hardcorio__/graphics/entity/player/tank/Tank-Launcher.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "d-d",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "tank-rockets",
      cooldown = 100,
      movement_slow_down_factor = 0.9,
      projectile_creation_distance = 0,
      range = 70,
	  sound =
      {
        {
        filename = "__hardcorio__/sound/player/weapons/rpg.wav",
          volume = 0.5
        }
      }
    },
    stack_size = 1
	},
	{
    type = "gun",
    name = "truck-repair",
    icon = "__hardcorio__/graphics/icons/weapons/repair-gun.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "cars",
    order = "a-b",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "repair-kit",
      cooldown = 120,
      range = 0,
	  sound =
      {
        {
          filename = "__core__/sound/manual-repair-advanced-1.ogg",
          volume = 0.8
        },
        {
          filename = "__core__/sound/manual-repair-advanced-2.ogg",
          volume = 0.8
        },
      }
    },
    stack_size = 1
	}
})
