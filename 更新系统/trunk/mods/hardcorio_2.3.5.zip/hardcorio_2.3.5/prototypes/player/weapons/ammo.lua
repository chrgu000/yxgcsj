data:extend(
{

	{
    type = "ammo",
    name = "repair-kit",
    icon = "__hardcorio__/graphics/icons/ammo/repair-kit.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "repair-kit",
	  target_type = "direction",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "repair-kit",
            starting_speed = 0.1,
            max_range = 0.1,
            source_effects =
            {
				{
                    type = "damage",
                    damage = {amount = -40, type = "self"}
                }
            }
          }
        }
    },
    magazine_size = 10,
    subgroup = "cars",
    order = "a-a",
    stack_size = 1
	},

	{
    type = "ammo",
    name = "medi-kit",
    icon = "__hardcorio__/graphics/icons/ammo/medi-kit.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "medi-kit",
	  target_type = "direction",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "medi-kit",
            starting_speed = 0.1,
            max_range = 0.1,
            source_effects =
            {
			  {
                  type = "damage",
                  damage = {amount = -1, type = "physical"}
              },
			  {
			  	type = "create-entity",
			  	entity_name = "medi-kit-target",
			  },
              --[[type = "create-explosion",
              entity_name = "explosion-gunshot"]]
            }
          }
        }
    },
    magazine_size = 100,
    subgroup = "armor",
    order = "f-b",
    stack_size = 1
	},

	--shotgun
	
	{
    type = "ammo",
    name = "sh-ep",
    icon = "__hardcorio__/graphics/icons/ammo/shotgun-shell-ep.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "shotgun-shell",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 20,
          action_delivery =
          {
            type = "projectile",
            projectile = "sh-ep-pr",
            starting_speed = 1.5,
			direction_deviation = 0.3,
            range_deviation = 0.3,
            max_range = 16,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 1,
    subgroup = "127x33",
    order = "b-a",
    stack_size = 8
	},
	
	{
    type = "ammo",
    name = "sh-ap",
    icon = "__hardcorio__/graphics/icons/ammo/shotgun-shell-ap.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "shotgun-shell",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 5,
          action_delivery =
          {
            type = "projectile",
            projectile = "sh-ap-pr",
            starting_speed = 1.5,
			direction_deviation = 0.1,
            range_deviation = 0.1,
            max_range = 16,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 1,
    subgroup = "127x33",
    order = "b-b",
    stack_size = 8
	},
	
	--556x45

	{
    type = "ammo",
    name = "556x45ep",
    icon = "__hardcorio__/graphics/icons/ammo/556x45ep.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "556x45",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p556x45ep",
            starting_speed = 3,
            direction_deviation = 0.15,
			range_deviation = 0.15,
            max_range = 20,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "556x45",
    order = "c-a",
    stack_size = 10
  },
  
  {
    type = "ammo",
    name = "556x45ap",
    icon = "__hardcorio__/graphics/icons/ammo/556x45ap.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "556x45",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p556x45ap",
            starting_speed = 3,
            direction_deviation = 0.15,
			range_deviation = 0.15,
            max_range = 20,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "556x45",
    order = "c-b",
    stack_size = 10
  },

  {
    type = "ammo",
    name = "556x45tr",
    icon = "__hardcorio__/graphics/icons/ammo/556x45tr.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "556x45",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p556x45tr",
            starting_speed = 3,
            direction_deviation = 0.075,
			range_deviation = 0.075,
            max_range = 20,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "556x45",
    order = "c-c",
    stack_size = 10
  },
 
  {
    type = "ammo",
    name = "556x45du",
    icon = "__hardcorio__/graphics/icons/ammo/556x45du.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "556x45",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p556x45du",
            starting_speed = 3,
            direction_deviation = 0.15,
			range_deviation = 0.15,
            max_range = 24,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "556x45",
    order = "c-d",
    stack_size = 10
  },
  
	--762x39

	{
    type = "ammo",
    name = "762x39ep",
    icon = "__hardcorio__/graphics/icons/ammo/762x39ep.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "762x39",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p762x39ep",
            starting_speed = 3,
            direction_deviation = 0.075,
			range_deviation = 0.075,
            max_range = 24,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "762x39",
    order = "c-a",
    stack_size = 6
  },
  
	{
    type = "ammo",
    name = "762x39ap",
    icon = "__hardcorio__/graphics/icons/ammo/762x39ap.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "762x39",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p762x39ap",
            starting_speed = 3,
            direction_deviation = 0.075,
			range_deviation = 0.075,
            max_range = 24,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "762x39",
    order = "c-b",
    stack_size = 6
  },
  
  {
    type = "ammo",
    name = "762x39fa",
    icon = "__hardcorio__/graphics/icons/ammo/762x39fa.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "762x39",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p762x39fa",
            starting_speed = 3,
            direction_deviation = 0.075,
			range_deviation = 0.075,
            max_range = 24,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "762x39",
    order = "c-c",
    stack_size = 6
  },
  
  {
    type = "ammo",
    name = "762x39du",
    icon = "__hardcorio__/graphics/icons/ammo/762x39du.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "762x39",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p762x39du",
            starting_speed = 3,
            direction_deviation = 0.075,
			range_deviation = 0.075,
            max_range = 28,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 10,
    subgroup = "762x39",
    order = "c-d",
    stack_size = 6
  },
	
	--127x99
	
	{
    type = "ammo",
    name = "127x99ep",
    icon = "__hardcorio__/graphics/icons/ammo/127x99ep.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "127x99",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p127x99ep",
            starting_speed = 4,
            max_range = 50,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 3,
    subgroup = "127x99",
    order = "c-a",
    stack_size = 3
	},
	
	{
    type = "ammo",
    name = "127x99mg",
    icon = "__hardcorio__/graphics/icons/ammo/127x99mg.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "127x99",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p127x99mg",
            starting_speed = 4,
            max_range = 50,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 3,
    subgroup = "127x99",
    order = "c-b",
    stack_size = 3
	},
	
	{
    type = "ammo",
    name = "127x99he",
    icon = "__hardcorio__/graphics/icons/ammo/127x99he.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "127x99",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p127x99he",
            starting_speed = 4,
            max_range = 50,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 3,
    subgroup = "127x99",
    order = "c-c",
    stack_size = 3
	},
	
	{
    type = "ammo",
    name = "127x99du",
    icon = "__hardcorio__/graphics/icons/ammo/127x99du.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "127x99",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p127x99du",
            starting_speed = 4,
            max_range = 50,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 3,
    subgroup = "127x99",
    order = "c-d",
    stack_size = 3
	},
  
  --RPG
  
  	{
    type = "ammo",
    name = "105he",
    icon = "__hardcorio__/graphics/icons/ammo/105he.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "105x",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p105he",
            starting_speed = 0.5,
            max_range = 90,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 1,
    subgroup = "grenade",
    order = "c-a",
    stack_size = 1
	},
	
	{
    type = "ammo",
    name = "105tbc",
    icon = "__hardcorio__/graphics/icons/ammo/105tbc.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "105x",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p105tbc",
            starting_speed = 0.5,
            max_range = 90,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 1,
    subgroup = "grenade",
    order = "c-b",
    stack_size = 1
	},
	
	{
    type = "ammo",
    name = "105mg",
    icon = "__hardcorio__/graphics/icons/ammo/105mg.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "105x",
      target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "p105mg",
            starting_speed = 0.5,
            max_range = 90,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 1,
    subgroup = "grenade",
    order = "c-c",
    stack_size = 1
	},
	
	--laser
	
	{
    type = "ammo",
    name = "ps40",
    icon = "__hardcorio__/graphics/icons/ammo/ps40.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
		{
		  type = "projectile",
		  category = "ps40",
		  target_type = "position",
		  action =
		  {
		  {
			type = "line",
			range = 14,
			width = 1,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			  source_effects =
			  {
			    type = "create-explosion",
			    entity_name = "red-lightning-bolt"
			  },
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 2, type="fire"}
			  }
			}
		  }
		}
	},
	magazine_size = 2000,
    subgroup = "laser",
    order = "b-b",
    stack_size = 1
	},
	
	{
    type = "ammo",
    name = "ps2000",
    icon = "__hardcorio__/graphics/icons/ammo/ps2000.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
		{
		  type = "projectile",
		  category = "ps2000",
		  target_type = "position",
		  action =
		  {
		  {
			type = "line",
			range = 30,
			width = 1,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			  source_effects =
			  {
			    type = "create-explosion",
			    entity_name = "green-lightning-bolt"
			  },
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 100, type="fire"}
			  }
			}
		  }
		}
	},
	magazine_size = 40,
    subgroup = "laser",
    order = "c-b",
    stack_size = 1
	},
	
	--plasma

	{
    type = "ammo",
    name = "ps3200",
    icon = "__hardcorio__/graphics/icons/ammo/ps3200.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "ps3200",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 18,
          action_delivery =
          {
            type = "projectile",
            projectile = "ps3200pr",
            starting_speed = 1,
			direction_deviation = 0.3,
            range_deviation = 0.3,
            max_range = 30,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 25,
    subgroup = "plasma",
    order = "b-b",
    stack_size = 1
	},
	
	{
    type = "ammo",
    name = "ps200",
    icon = "__hardcorio__/graphics/icons/ammo/ps200.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "ps200",
	  target_type = "position",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "ps3200pr",
			direction_deviation = 0.2,
            range_deviation = 0.2,
            starting_speed = 1,
            max_range = 40,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 400,
    subgroup = "plasma",
    order = "c-b",
    stack_size = 1
	},
	
	{
    type = "ammo",
    name = "ps4000",
    icon = "__hardcorio__/graphics/icons/ammo/ps4000.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "ps4000",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "ps4000pr",
            starting_speed = 3,
            max_range = 80,
            --[[source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            }]]
          }
        }
    },
    magazine_size = 20,
    subgroup = "plasma",
    order = "d-b",
    stack_size = 1
	},

	--TANK
	
	{
    type = "ammo",
    name = "ps160",
    icon = "__hardcorio__/graphics/icons/ammo/ps160.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
		{
		  type = "projectile",
		  category = "ps160",
		  target_type = "position",
		  action =
		  {
		  {
			type = "line",
			range = 20,
			width = 1.5,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			  source_effects =
			  {
			    type = "create-explosion",
			    entity_name = "tank-lightning-bolt"
			  },
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 5, type="fire"}
			  }
			}
		  }
		}
	},
	magazine_size = 800,
    subgroup = "cars",
    order = "b-a",
    stack_size = 1
	},
	{
    type = "explosion",
    name = "tank-lightning-bolt",
    flags = {"not-on-map"},
    animation_speed = 10,
    rotate = true,
    beam = true,
    animations =
    {
	  {
        filename = "__hardcorio__/graphics/entity/player/tank-laser1.png",
        priority = "low",
        width = 15,
        height = 15,
        frame_count = 6,
      },
      {
        filename = "__hardcorio__/graphics/entity/player/tank-laser2.png",
        priority = "low",
        width = 15,
        height = 15,
        frame_count = 6,
      }
    },
  },
  {
    type = "ammo",
    name = "125x",
    icon = "__hardcorio__/graphics/icons/ammo/cannon-shell.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "125x",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "125x",
            starting_speed = 1,
			direction_deviation = 0.15,
            range_deviation = 0.15,
            max_range = 55,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-hit"
            }
          }
        }
    },
    magazine_size = 1,
    subgroup = "cars",
    order = "c-a",
    stack_size = 15
	},
	{
    type = "ammo",
    name = "rockets-1",
    icon = "__hardcorio__/graphics/icons/ammo/rokets-1.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "tank-rockets",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 2,
          action_delivery =
          {
            type = "projectile",
            projectile = "rockets-1p",
            starting_speed = 0.3,
			direction_deviation = 0.1,
            range_deviation = 0.1,
            max_range = 100,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-hit"
            }
          }
        }
    },
    magazine_size = 16,
    subgroup = "cars",
    order = "d-c",
    stack_size = 1
	},
	{
    type = "ammo",
    name = "rockets-2",
    icon = "__hardcorio__/graphics/icons/ammo/rokets-2.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "tank-rockets",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 2,
          action_delivery =
          {
            type = "projectile",
            projectile = "rockets-2p",
            starting_speed = 0.3,
			direction_deviation = 0.2,
            range_deviation = 0.2,
            max_range = 100,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-hit"
            }
          }
        }
    },
    magazine_size = 16,
    subgroup = "cars",
    order = "c-a",
    stack_size = 1
	},
	{
    type = "ammo",
    name = "rockets-3",
    icon = "__hardcorio__/graphics/icons/ammo/rokets-3.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "tank-rockets",
	  target_type = "position",
      action =
        {
          type = "direct",
		  repeat_count = 2,
          action_delivery =
          {
            type = "projectile",
            projectile = "rockets-3p",
            starting_speed = 0.3,
			direction_deviation = 0.2,
            range_deviation = 0.2,
            max_range = 100,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-hit"
            }
          }
        }
    },
    magazine_size = 16,
    subgroup = "cars",
    order = "d-b",
    stack_size = 1
	},
	
	--MINES
	{
    type = "item",
    name = "station-mine",
    icon = "__base__/graphics/icons/land-mine.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "127x33",
    order = "f",
    place_result = "station-mine",
    stack_size = 50
  },
	
})
