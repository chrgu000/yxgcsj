data:extend(
{
	
	{
    type = "projectile",
    name = "repair-kit",
    flags = {"not-on-map"},
    acceleration = 0,
    --[[action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius = 3,
			  entity_flags = {"pushable", "player-creation"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = -40, type = "self"}
                }
				}
              }
            }
		  }
		}}
      }
    },]]
    animation =
    {
      filename = "__hardcorio__/graphics/entity/empty.png",
      frame_count = 1,
	  scale = 0.2,
      width = 1,
      height = 1,
      priority = "high"
    }
	},

	--medi-kit
	
	{
    type = "projectile",
    name = "medi-kit",
    flags = {"not-on-map"},
    acceleration = 0,
    --[[action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius = 4,
			  entity_flags = {"pushable"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = -1, type = "physical"}
                },
				{
					type = "create-entity",
					entity_name = "medi-kit-target",
				},
				}
              }
            }
		  }
		}}
      }
    },]]
    animation =
    {
      filename = "__hardcorio__/graphics/entity/empty.png",
      frame_count = 1,
	  scale = 0.2,
      width = 1,
      height = 1,
      priority = "high"
    }
	},
	
	{
    type = "explosion",
    name = "medi-kit-target",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/heal.png",
        priority = "extra-high",
		scale = 0.5,
        width = 35,
        height = 35,
        frame_count = 1,
        animation_speed = 0.5,
		shift = {0, 0}
      },
    },
  },
	
	--shotgun
	
	{
    type = "projectile",
    name = "sh-ep-pr",
    flags = {"not-on-map"},
	--collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    acceleration = 0,
    direction_only = false,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 6, type = "physical"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/empty.png",
      frame_count = 1,
	  scale = 0.2,
      width = 1,
      height = 1,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "sh-ap-pr",
    flags = {"not-on-map"},
	--collision_box = {{-1, -1}, {1, 1}},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 14, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 10, type = "piercing"}
                },
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.7,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},

	--556x45

	{
    type = "projectile",
    name = "p556x45ep",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 8, type = "physical"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.3,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p556x45ap",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 3, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 5, type = "piercing"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.3,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p556x45tr",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 3, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 5, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.5,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p556x45du",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 4, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 4, type = "piercing"}
                },
				{
                    type = "damage",
                    damage = {amount = 4, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.3,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	--762x39

	{
    type = "projectile",
    name = "p762x39ep",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 15, type = "physical"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.6,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p762x39ap",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 5, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 10, type = "piercing"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.6,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p762x39fa",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 10, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 5, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.6,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p762x39du",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 7, type = "physical"}
                },
				{
                    type = "damage",
                    damage = {amount = 7, type = "piercing"}
                },
				{
                    type = "damage",
                    damage = {amount = 7, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.6,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},


	--127x99
	
	{
    type = "projectile",
    name = "p127x99ep",
    flags = {"not-on-map"},
    acceleration = -0.05,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 40, type = "physical"}
                }
				}
              }
            },
			{
              type = "area",
              radius =1,
			  entity_flags = {"breaths-air"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 80, type = "physical"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.7,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p127x99mg",
    flags = {"not-on-map"},
    acceleration = -0.03,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 40, type = "physical"}
                }
				}
              }
            },
			{
              type = "area",
              radius =1,
			  entity_flags = {"breaths-air"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 80, type = "piercing"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.7,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p127x99he",
    flags = {"not-on-map"},
    acceleration = -0.05,
	action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "explosion-he",
			offset = {0, -5}
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius = 1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 40, type = "physical"}
                }
				}
              }
            },
			{
              type = "area",
              radius = 1,
			  entity_flags = {"breaths-air"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 80, type = "explosion"}
                }
				}
              }
            }
		  }
		}
        }
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.7,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "p127x99du",
    flags = {"not-on-map"},
    acceleration = -0.05,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "target-hit",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 50, type = "physical"}
                }
				}
              }
            },
			{
              type = "area",
              radius =1,
			  entity_flags = {"breaths-air"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 50, type = "piercing"}
                },
				{
                    type = "damage",
                    damage = {amount = 50, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/bullet/bullet.png",
      frame_count = 1,
	  scale = 0.7,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
  {
    type = "explosion",
    name = "explosion-he",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__base__/graphics/entity/explosion/explosion-1.png",
        priority = "extra-high",
        width = 64,
        height = 59,
        frame_count = 16,
        animation_speed = 0.5,
		scale = 0.5
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-2.png",
        priority = "extra-high",
        width = 64,
        height = 57,
        frame_count = 16,
        animation_speed = 0.5,
		scale = 0.5
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-3.png",
        priority = "extra-high",
        width = 64,
        height = 49,
        frame_count = 16,
        animation_speed = 0.5,
		scale = 0.5
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-4.png",
        priority = "extra-high",
        width = 64,
        height = 51,
        frame_count = 16,
        animation_speed = 0.5,
		scale = 0.5
      }
    },
    light = {intensity = 0.3, size = 10, color = {r=1.0, g=1.0, b=1.0}},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1,
    sound =
    {
      aggregation =
      {
        max_count = 1,
        remove = true
      },
      variations =
      {
        {
          filename = "__base__/sound/fight/small-explosion-1.ogg",
          volume = 0.35
        },
        {
          filename = "__base__/sound/fight/small-explosion-2.ogg",
          volume = 0.35
        }
      }
    }
  },
  
  {
    type = "explosion",
    name = "target-hit",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__base__/graphics/entity/explosion/explosion-1.png",
        priority = "extra-high",
		scale = 0.1,
        width = 64,
        height = 59,
        frame_count = 16,
        animation_speed = 0.5,
		shift = {0, 1}
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-2.png",
        priority = "extra-high",
		scale = 0.1,
        width = 64,
        height = 57,
        frame_count = 16,
        animation_speed = 0.5,
		shift = {0, 1}
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-3.png",
        priority = "extra-high",
		scale = 0.1,
        width = 64,
        height = 49,
        frame_count = 16,
        animation_speed = 0.5,
		shift = {0, 1}
      },
      {
        filename = "__base__/graphics/entity/explosion/explosion-4.png",
        priority = "extra-high",
		scale = 0.1,
        width = 64,
        height = 51,
        frame_count = 16,
        animation_speed = 0.5,
		shift = {0, 1}
      }
    },
    smoke = "target-smoke",
    smoke_count = 1,
    smoke_slow_down_factor = 1,
  },
  
  {
    type = "trivial-smoke",
    name = "target-smoke",
    animation =
    {
      filename = "__base__/graphics/entity/smoke-fast/smoke-fast.png",
      priority = "high",
      width = 50,
      height = 50,
      frame_count = 16,
      animation_speed = 2,
	  shift = {0, 1}
    }
  },

	--RPG
	{
    type = "projectile",
    name = "p105he",
    flags = {"not-on-map"},
    acceleration = 0.01,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "rokets-1-splash"
          },
          {
            type = "nested-result",
            action =
            {
			{
              type = "area",
              radius = 1,
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                    type = "damage",
                    damage = {amount = 40*3, type = "explosion"}
                }
              }
            },
			{
              type = "area",
              radius = 2.5,
              entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                    type = "damage",
                    damage = {amount = 40*3, type = "physical"}
                }
              }
            },
			{
              type = "area",
              radius = 4.5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                    type = "damage",
                    damage = {amount = 40*3, type = "fire"}
                }
              }
            },
			{
              type = "area",
              radius = 6.5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                    type = "damage",
                    damage = {amount = 40*3, type = "fire"}
                }
              }
            }
		   }
          }
        }
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  scale = 0.5,
      width = 10,
      height = 30,
      priority = "high"
    }
	},
	
	{
    type = "projectile",
    name = "p105tbc",
    flags = {"not-on-map"},
    acceleration = 0.01,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "fake-robot",
          },{
            type = "create-entity",
            entity_name = "fake-robot",
          },{
            type = "create-entity",
            entity_name = "fake-robot",
          },
        }
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  scale = 0.5,
      width = 10,
      height = 30,
      priority = "high"
    }
	},
	
	{
    type = "projectile",
    name = "p105mg",
    flags = {"not-on-map"},
    acceleration = 0.02,
    action =
    {
      type = "area",
      radius = 6,
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "create-sticker",
          sticker = "smoke-sticker"
        }
      }
    },
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  scale = 0.5,
      width = 10,
      height = 30,
      priority = "high"
    }
	},
	{
    type = "sticker",
    name = "smoke-sticker",
    flags = {"not-on-map"},
    --icon = "__base__/graphics/icons/slowdown-sticker.png",
    --icon_size = 32,
    flags = {},
    animation =
    {
      filename = "__base__/graphics/entity/slowdown-sticker/slowdown-sticker.png",
      priority = "extra-high",
      width = 11,
      height = 11,
      frame_count = 13,
      animation_speed = 0.4
    },
    duration_in_ticks = 10 * 60,
    target_movement_modifier = 0.4
  },
	
	--plasma
	
	{
    type = "projectile",
    name = "ps3200pr",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "plasma-explosion3200",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1.5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 14, type = "fire"}
                },
				{
                    type = "damage",
                    damage = {amount = 6, type = "physical"}
                },
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/plasma-bullet.png",
      frame_count = 1,
	  scale = 0.5,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "projectile",
    name = "ps4000pr",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "plasma-explosion3200",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =2,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 120, type = "physical"}
                },
				}
              }
            },
			{
              type = "area",
              radius =2,
			  entity_flags = {"breaths-air"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 360, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/plasma-bullet.png",
      frame_count = 1,
	  scale = 1,
      width = 3,
      height = 50,
      priority = "high",
	  shift = {0, 1}
    }
	},
	
	{
    type = "explosion",
    name = "plasma-explosion3200",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1.1,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1.2,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
	  {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1.3,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1.4,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        shift = {0, 1},
		scale = 1.5,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      }
	  
    },
    light = {intensity = 1, size = 10},
    sound =
    {
      {
        filename = "__hardcorio__/sound/player/weapons/plasma-explosion.wav",
        volume = 0.3
      }
    }
  },
  {
    type = "projectile",
    name = "ps15000pr",
    flags = {"not-on-map"},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "plasma-explosion15000",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 175, type = "fire"}
                },
				{
                    type = "damage",
                    damage = {amount = 30, type = "physical"}
                },
				}
              }
            }
		  }
		}}
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/plasma-bullet.png",
      frame_count = 1,
	  scale = 2,
      width = 3,
      height = 50,
      priority = "high"
    }
	},
	
	{
    type = "explosion",
    name = "plasma-explosion15000",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4.2,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4.4,
		line_length = 8,
        frame_count = 32,
        animation_speed = 1.4
      },
	  {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4.6,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4.8,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      },
      {
        filename = "__hardcorio__/graphics/entity/plasma-explosion2.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 5,
		line_length = 8,
        frame_count = 40,
        animation_speed = 1.4
      }
	  
    },
    light = {intensity = 1, size = 20},
    sound =
    {
      {
        filename = "__hardcorio__/sound/player/weapons/plasma-explosion.wav",
        volume = 1
      }
    }
  },
  {
    type = "projectile",
    name = "125x",
    flags = {"not-on-map"},
	collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
    acceleration = 0.1,
    piercing_damage = 300,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "medium-explosion",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =2,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 180, type = "piercing"}
                }
				}
              }
            },
			{
              type = "area",
              radius =5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 100, type = "fire"}
                }
				}
              }
            },
			{
			  type = "area",
			  radius = 3,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
			  action_delivery =
			  {
				type = "instant",
				target_effects =
				{
				  type = "create-sticker",
				  sticker = "tank-sticker"
				}
			  }
			},
		  }
		}}
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/empty.png",
      frame_count = 1,
      width = 1,
      height = 1,
      priority = "low"
    }
	},
	{
    type = "sticker",
    name = "tank-sticker",
    flags = {"not-on-map"},
    --icon = "__base__/graphics/icons/slowdown-sticker.png",
    --icon_size = 32,
    flags = {},
    animation =
    {
      filename = "__base__/graphics/entity/slowdown-sticker/slowdown-sticker.png",
      priority = "extra-high",
      width = 11,
      height = 11,
      frame_count = 13,
      animation_speed = 0.4
    },
    duration_in_ticks = 4 * 60,
    target_movement_modifier = 0.3
  },
	
	{
    type = "projectile",
    name = "rockets-1p",
    flags = {"not-on-map"},
    acceleration = 0.01,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "rokets-1-splash",
        },
		{
        type = "nested-result",
        action =
          {
			{
              type = "area",
              radius =1,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              collision_mask = { "player-layer" },
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 50, type = "explosion"}
                }
				}
              }
            },
			{
              type = "area",
              radius =3,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 50, type = "physical"}
                }
				}
              }
            },
			{
              type = "area",
              radius =5,
			  entity_flags = {"placeable-enemy", "placeable-neutral"},
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
				{
                    type = "damage",
                    damage = {amount = 100, type = "fire"}
                }
				}
              }
            }
		  }
		}}
      }
    },
    light = {intensity = 0.5, size = 4},
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    shadow =
    {
      filename = "__base__/graphics/entity/rocket/rocket-shadow.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    smoke =
    {
      {
        name = "smoke-fast",
        deviation = {0.15, 0.15},
        frequency = 1,
        position = {0, 0},
        slow_down_factor = 1,
        starting_frame = 3,
        starting_frame_deviation = 5,
        starting_frame_speed = 0,
        starting_frame_speed_deviation = 5
      }
    }
  },
  {
    type = "explosion",
    name = "rokets-1-splash",
    flags = {"not-on-map"},
	animations =
    {
      {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.2,
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.4,
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.6,
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.8,
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4,
        frame_count = 64,
        line_length = 8,
		animation_speed = 1,
      },
    },
    light = {intensity = 1, size = 20},
	sound =
    {
      {
        filename = "__hardcorio__/sound/player/weapons/cannon-explosion.wav",
        volume = 1
      }
    }
  },
  
  {
    type = "projectile",
    name = "rockets-2p",
    flags = {"not-on-map"},
    acceleration = 0.01,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "station-mine",
        },
		}
      }
    },
    light = {intensity = 0.5, size = 4},
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    shadow =
    {
      filename = "__base__/graphics/entity/rocket/rocket-shadow.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    smoke =
    {
      {
        name = "smoke-fast",
        deviation = {0.15, 0.15},
        frequency = 1,
        position = {0, 0},
        slow_down_factor = 1,
        starting_frame = 3,
        starting_frame_deviation = 5,
        starting_frame_speed = 0,
        starting_frame_speed_deviation = 5
      }
    }
  },
  
  {
    type = "projectile",
    name = "rockets-3p",
    flags = {"not-on-map"},
    acceleration = 0.01,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
		{
		{
            type = "create-entity",
            entity_name = "rocket-laser",
        },
		}
      }
    },
    light = {intensity = 0.5, size = 4},
    animation =
    {
      filename = "__base__/graphics/entity/rocket/rocket.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    shadow =
    {
      filename = "__base__/graphics/entity/rocket/rocket-shadow.png",
      frame_count = 1,
	  shift = { 0, 1 },
      width = 10,
      height = 30,
      priority = "high"
    },
    smoke =
    {
      {
        name = "smoke-fast",
        deviation = {0.15, 0.15},
        frequency = 1,
        position = {0, 0},
        slow_down_factor = 1,
        starting_frame = 3,
        starting_frame_deviation = 5,
        starting_frame_speed = 0,
        starting_frame_speed_deviation = 5
      }
    }
  },
  {
    type = "turret",
    name = "rocket-laser",
    icon = "__hardcorio__/graphics/icons/enemy/base.png",
    icon_size = 32,
    flags = { "placeable-player", "placeable-neutral", "not-repairable", "not-blueprintable", "not-deconstructable", "not-on-map" },
    order="s-a",
    max_health = 150,
    alert_when_damaged = false,
	resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } },
    subgroup="enemies",
	collision_mask = {"not-colliding-with-itself"},
	dying_explosion = "explosion",
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
	selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
	folded_animation = {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    folded_speed = 10,
    folded_animation = {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    prepare_range = 15,
    preparing_speed = 10,
    preparing_animation = {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    prepared_speed = 10,
    prepared_animation = {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    starting_attack_speed = 10,
    starting_attack_animation = {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    folding_speed = 10,
    folding_animation =  {filename = "__base__/graphics/entity/combat-robot/defender.png", shift = { 0, -1.2 },priority = "high",scale = 0.8,width = 37,height = 34,frame_count = 1,axially_symmetrical = false,direction_count = 1,animation_speed = 0.1},
    attack_parameters = {
	type = "projectile",
    ammo_category = "laser",
    cooldown = 3,
    range = 10,
    ammo_type =
    {
		category = "laser-turret",
		action =
		  {
		  {
			type = "line",
			range = 14,
			width = 1.5,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			source_effects =
			{
			{
			  type = "create-explosion",
			  entity_name = "green-lightning-bolt"
			},
			{
            type = "damage",
            damage = { amount = 0.5, type = "explosion"}
			}
			},
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 2, type="fire"}
			  }
			}
		  },
	    }
      }
    },
	call_for_help_radius = 40
  },
  
  --MINES
  {
    type = "land-mine",
    name = "station-mine",
    icon = "__base__/graphics/icons/land-mine.png",
    icon_size = 32,
    flags =
    {
      "placeable-player",
      "player-creation",
      "placeable-off-grid"
    },
    max_health = 50,
	resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } },
    collision_box = {{-0.2,-0.2}, {0.2, 0.2}},
	selection_box = {{-0.2,-0.2}, {0.2, 0.2}},
    dying_explosion = "explosion-hit",
	minable = {mining_time = 1, result = "station-mine"},
    picture_safe =
    {
      filename = "__base__/graphics/entity/land-mine/land-mine.png",
      priority = "medium",
	  scale = 0.3,
      width = 32,
      height = 32
    },
    picture_set =
    {
      filename = "__base__/graphics/entity/land-mine/land-mine-set.png",
      priority = "medium",
	  scale = 0.3,
      width = 32,
      height = 32
    },
    trigger_radius = 1,
	trigger_flags = {"placeable-enemy"},
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
          {
            type = "nested-result",
            affects_target = true,
            action =
			{
              {
                type = "area",
                radius = 3,
                entity_flags = {"placeable-enemy", "placeable-neutral"},
                collision_mask = { "player-layer", "floor-layer" },
                action_delivery =
                {
                  type = "instant",
                  target_effects = 
                  {
                    type = "damage",
                    damage = { amount = 50, type = "explosion"}
                  }
                }
              },
			  {
                type = "area",
                radius = 2.5,
                entity_flags = {"placeable-enemy", "placeable-neutral"},
                collision_mask = { "player-layer", "floor-layer" },
                action_delivery =
                {
                  type = "instant",
                  target_effects = 
                  {
                    type = "damage",
                    damage = { amount = 250, type = "fire"}
                  }
                }
              }
			}
          },
          {
            type = "create-entity",
            entity_name = "rokets-1-splash"
          },
          {
            type = "damage",
            damage = { amount = 1000, type = "explosion"}
          }
        }
      }
    },
  },
})
