local turret_5mm_extension = {
	filename = "__hardcorio__/graphics/entity/player/5mmTurret/fold.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.2}
}

local turret_5mm_animation = {
	filename = "__hardcorio__/graphics/entity/player/5mmTurret/phased.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = { 0, -0.2}			
}

local turret_7mm_extension = {
	filename = "__hardcorio__/graphics/entity/player/7mmTurret/fold.png",
	priority = "medium",
	width = 96,
	height = 96,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, 0}
}

local turret_7mm_animation = {
  filename = "__hardcorio__/graphics/entity/player/7mmTurret/phased.png",
  priority = "medium",
  width = 96,
  height = 96,
  direction_count = 72,
  frame_count = 1,
  line_length = 8,
  axially_symmetrical = false,
  shift = {0, 0}
}

local turret_12mm_extension = {
	filename = "__hardcorio__/graphics/entity/player/12mmTurret/fold.png",
	priority = "medium",
	width = 96,
	height = 96,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, 0}
}

local turret_12mm_animation = {
	filename = "__hardcorio__/graphics/entity/player/12mmTurret/phased.png",
	priority = "medium",
	width = 96,
	height = 96,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = { 0, 0},			
}

local turret_missle_extension = {
	filename = "__hardcorio__/graphics/entity/player/Turret_Missle/fold.png",
	priority = "medium",
	width = 88,
	height = 88,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.3},
}

local turret_missle_animation = {
	filename = "__hardcorio__/graphics/entity/player/Turret_Missle/phased.png",
	priority = "medium",
	width = 88,
	height = 88,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = { 0, -0.3},			
}

local turret_red_laser_extension = {
    filename = "__hardcorio__/graphics/entity/player/turret_red_laser/fold.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.3},
}

local turret_red_laser_animation = {
	filename = "__hardcorio__/graphics/entity/player/turret_red_laser/phased.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = {0, -0.3}
}

local turret_green_laser_extension = {
    filename = "__hardcorio__/graphics/entity/player/turret_green_laser/fold.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.3},
}

local turret_green_laser_animation = {
	filename = "__hardcorio__/graphics/entity/player/turret_green_laser/phased.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = {0, -0.3}
}

local turret_blue_laser_extension = {
    filename = "__hardcorio__/graphics/entity/player/turret_blue_laser/fold.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.3},
}

local turret_blue_laser_animation = {
	filename = "__hardcorio__/graphics/entity/player/turret_blue_laser/phased.png",
	priority = "medium",
	width = 64,
	height = 64,
	direction_count = 72,
	frame_count = 1,
	line_length = 8,
	axially_symmetrical = false,
	shift = {0, -0.3}
}

local turret_plasma_extension =
{
	filename = "__hardcorio__/graphics/entity/player/turret_plasma/fold.png",
	priority = "medium",
	width = 96,
	height = 96,
	direction_count = 4,
	frame_count = 1,
	axially_symmetrical = false,
	shift = { 0, -0.3},
}
local turret_plasma_animation = {
filename = "__hardcorio__/graphics/entity/player/turret_plasma/phased.png",
  priority = "medium",
  width = 96,
  height = 96,
  direction_count = 72,
  frame_count = 1,
  line_length = 8,
  axially_symmetrical = false,
  shift = {0, -0.3}
}

data:extend(
{


  {
    type = "item",
    name = "gun-turret-556x45",
    icon = "__hardcorio__/graphics/entity/player/5mmTurret/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "556x45",
    order = "a-a",
    place_result = "gun-turret-556x45",
    stack_size = 5
  },
  {
    type = "ammo-turret",
    name = "gun-turret-556x45",
    icon = "__hardcorio__/graphics/entity/player/5mmTurret/icon.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {mining_time = 0.5, result = "gun-turret-556x45"},
    max_health = 400,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.015,
    preparing_speed = 0.08,
    folding_speed = 0.08,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    inventory_size = 3,
    automated_ammo_count = 10,
	prepare_range = 20,
	preparing_animation = turret_5mm_extension,
	prepared_animation = turret_5mm_animation,
	folding_animation = turret_5mm_extension,
    folded_animation = turret_5mm_extension,
    base_picture =
    {
      filename = "__hardcorio__/graphics/entity/player/5mmTurret/gun-turret-base.png",
      priority = "high",
      width = 64,
      height = 64,
	  frame_count = 1,
      shift = { 0, -0.2}
    },
	
    attack_parameters = 
    {
      type = "projectile",
      ammo_category = "556x45",
      cooldown = 6,
      projectile_center = {0, -0.6},
      projectile_creation_distance = 1.2,
      shell_particle = 
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 1},
        creation_distance = -1,
        starting_frame_speed = 0.2,
        starting_frame_speed_deviation = 0.1
      },
      range = 16,
      sound =
      {
          filename = "__hardcorio__/sound/player/weapons/m60.wav",
          volume = 0.5
      }
    },
	call_for_help_radius = 40
  },
  
  {
    type = "item",
    name = "gun-turret-762x39",
    icon = "__hardcorio__/graphics/entity/player/7mmTurret/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "762x39",
    order = "a-a",
    place_result = "gun-turret-762x39",
    stack_size = 5
  },
  {
    type = "ammo-turret",
    name = "gun-turret-762x39",
    icon = "__hardcorio__/graphics/entity/player/7mmTurret/icon.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {mining_time = 0.5, result = "gun-turret-762x39"},
    max_health = 300,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.015,
    preparing_speed = 0.08,
    folding_speed = 0.08,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    inventory_size = 3,
    automated_ammo_count = 6,
	prepare_range = 25,
    preparing_animation = turret_7mm_extension,
    prepared_animation = turret_7mm_animation,
    folding_animation = turret_7mm_extension,
    folded_animation = turret_7mm_extension,
    base_picture =
    {
      filename = "__hardcorio__/graphics/entity/player/7mmTurret/turret-base.png",
      priority = "high",
      width = 96,
      height = 96,
	  frame_count = 1,
      shift = { 0, 0 }
    },
    attack_parameters = 
    {
      type = "projectile",
      ammo_category = "762x39",
      cooldown = 12,
      projectile_center = {0, -0.6},
      projectile_creation_distance = 1.2,
      shell_particle = 
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 1},
        creation_distance = -1,
        starting_frame_speed = 0.2,
        starting_frame_speed_deviation = 0.1
      },
      range = 20,
      sound =
      {
          filename = "__hardcorio__/sound/player/weapons/ak47.wav",
          volume = 0.7
      }
    },
	call_for_help_radius = 40
  },  
  
  {
    type = "item",
    name = "gun-turret-127x99",
    icon = "__hardcorio__/graphics/entity/player/12mmTurret/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "127x99",
    order = "a-a",
    place_result = "gun-turret-127x99",
    stack_size = 5
  },
  {
    type = "ammo-turret",
    name = "gun-turret-127x99",
    icon = "__hardcorio__/graphics/entity/player/12mmTurret/icon.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {mining_time = 0.5, result = "gun-turret-127x99"},
    max_health = 200,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.015,
    preparing_speed = 0.08,
    folding_speed = 0.08,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    inventory_size = 3,
    automated_ammo_count = 3,
	prepare_range = 35,
	preparing_animation = turret_12mm_extension,
	prepared_animation = turret_12mm_animation,
	folding_animation = turret_12mm_extension,
    folded_animation = turret_12mm_extension,
    base_picture =
    {
      filename = "__hardcorio__/graphics/entity/player/12mmTurret/turret-base.png",
      priority = "high",
      width = 96,
      height = 96,
	  frame_count = 1,
      shift = { 0, 0 }
    },
    attack_parameters = 
    {
      type = "projectile",
      ammo_category = "127x99",
      cooldown = 100,
	  damage_modifier = 1,
      projectile_center = {0, -0.6},
      projectile_creation_distance = 1.2,
      shell_particle = 
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 1},
        creation_distance = -1,
        starting_frame_speed = 0.2,
        starting_frame_speed_deviation = 0.1
      },
      range = 30,
      sound =
      {
          filename = "__hardcorio__/sound/player/weapons/m82.wav",
          volume = 0.7
      }
    },
	call_for_help_radius = 40
  },
  
  {
    type = "item",
    name = "turret_missle",
    icon = "__hardcorio__/graphics/entity/player/Turret_Missle/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "grenade",
    order = "a-a",
    place_result = "turret_missle",
    stack_size = 5
  },
  {
    type = "ammo-turret",
    name = "turret_missle",
    icon = "__hardcorio__/graphics/entity/player/Turret_Missle/icon.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {mining_time = 0.5, result = "turret_missle"},
    max_health = 200,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.015,
    preparing_speed = 0.08,
    folding_speed = 0.08,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    inventory_size = 1,
    automated_ammo_count = 1,
	prepare_range = 45,
	preparing_animation = turret_missle_extension,
	prepared_animation = turret_missle_animation,
	folding_animation = turret_missle_extension,
    folded_animation = turret_missle_extension,
    base_picture =
    {
      filename = "__hardcorio__/graphics/entity/player/Turret_Missle/turret-base.png",
      priority = "high",
      width = 88,
      height = 88,
	  frame_count = 1,
	  shift = { 0, -0.3},
    },
	
    attack_parameters = 
    {
      type = "projectile",
      ammo_category = "105x",
      cooldown = 60,
      projectile_center = {0, -0.6},
      projectile_creation_distance = 1.2,
      range = 35,
      sound =
      {
          filename = "__hardcorio__/sound/player/weapons/rpg.wav",
          volume = 1
      }
    },
	call_for_help_radius = 40
  },
 
  {
    type = "item",
    name = "red-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_red_laser/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "laser",
    order = "a-a",
    place_result = "red-laser-turret",
    stack_size = 5
  },
  
  {
    type = "electric-turret",
    name = "red-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_red_laser/icon.png",
    icon_size = 32,
    flags = { "placeable-player", "placeable-enemy", "player-creation"},
    minable = { mining_time = 0.5, result = "red-laser-turret" },
    max_health = 400,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.01,
    preparing_speed = 0.05,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    folding_speed = 0.05,
	energy_source =
    {
      type = "electric",
      buffer_capacity = "3000kJ",
      input_flow_limit = "620kW",
      drain = "20kW",
      usage_priority = "primary-input"
    },
	prepare_range = 20,
    preparing_animation = turret_red_laser_extension,
    prepared_animation = turret_red_laser_animation,
    folding_animation = turret_red_laser_extension,
    folded_animation = turret_red_laser_extension,
    base_picture =
    {
    filename = "__hardcorio__/graphics/entity/player/turret_red_laser/turret-base.png",
      priority = "high",
      width = 64,
      height = 64,
	  frame_count = 1,
      shift = { 0, -0.3 }
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "laser",
      cooldown = 1,
      projectile_creation_distance = 0.18,
	  projectile_center = {0, 0.45},
      range = 15,
	  ammo_type =
		{
		  type = "projectile",
		  category = "laser-turret",
		  energy_consumption = "40kJ",
		  target_type = "direction",
		  action =
		  {
		  {
			type = "line",
			range = 18,
			width = 1,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			source_effects =
			{
			  type = "create-explosion",
			  entity_name = "red-lightning-bolt"
			},
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 1, type="fire"}
			  }
			}
		  },
	    }
	  },
	},
	call_for_help_radius = 40
  }, 
  {
    type = "explosion",
    name = "red-lightning-bolt",
    flags = {"not-on-map"},
    animation_speed = 10,
    rotate = true,
    beam = true,
    animations =
    {
	  {
        filename = "__hardcorio__/graphics/entity/player/red-laser1.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      },
      {
        filename = "__hardcorio__/graphics/entity/player/red-laser2.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      }
    },
  },
 
 {
    type = "item",
    name = "green-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_green_laser/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "laser",
    order = "a-b",
    place_result = "green-laser-turret",
    stack_size = 5
  },
  
  {
    type = "electric-turret",
    name = "green-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_green_laser/icon.png",
    icon_size = 32,
    flags = { "placeable-player", "placeable-enemy", "player-creation"},
    minable = { mining_time = 0.5, result = "green-laser-turret" },
    max_health = 300,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.01,
    preparing_speed = 0.05,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    folding_speed = 0.05,
	energy_source =
    {
      type = "electric",
      buffer_capacity = "4500kJ",
      input_flow_limit = "920kW",
      drain = "20kW",
      usage_priority = "primary-input"
    },
	prepare_range = 30,
    preparing_animation = turret_green_laser_extension,
    prepared_animation = turret_green_laser_animation,
    folding_animation = turret_green_laser_extension,
    folded_animation = turret_green_laser_extension,
    base_picture =
    {
    filename = "__hardcorio__/graphics/entity/player/turret_green_laser/turret-base.png",
      priority = "high",
      width = 64,
      height = 64,
	  frame_count = 1,
      shift = { 0, -0.3 }
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "laser",
      cooldown = 1,
      projectile_creation_distance = 0.18,
	  projectile_center = {0, 0.45},
      range = 22,
	  ammo_type =
		{
		  type = "projectile",
		  category = "laser-turret",
		  energy_consumption = "80kJ",
		  target_type = "direction",
		  action =
		  {
		  {
			type = "line",
			range = 25,
			width = 1,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			source_effects =
			{
			  type = "create-explosion",
			  entity_name = "green-lightning-bolt"
			},
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 1, type="fire"}
			  }
			}
		  },
		  }
		},
	},
	call_for_help_radius = 40
 }, 
 {
    type = "explosion",
    name = "green-lightning-bolt",
    flags = {"not-on-map"},
    animation_speed = 10,
    rotate = true,
    beam = true,
    animations =
    {
	  {
        filename = "__hardcorio__/graphics/entity/player/green-laser1.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      },
      {
        filename = "__hardcorio__/graphics/entity/player/green-laser2.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      }
    },
  },
  
  {
    type = "item",
    name = "blue-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_blue_laser/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "laser",
    order = "a-c",
    place_result = "blue-laser-turret",
    stack_size = 5
  },
  
  {
    type = "electric-turret",
    name = "blue-laser-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_blue_laser/icon.png",
    icon_size = 32,
    flags = { "placeable-player", "placeable-enemy", "player-creation"},
    minable = { mining_time = 0.5, result = "blue-laser-turret" },
    max_health = 200,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.01,
    preparing_speed = 0.05,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    folding_speed = 0.05,
	energy_source =
    {
      type = "electric",
      buffer_capacity = "6000kJ",
      input_flow_limit = "1220kW",
      drain = "20kW",
      usage_priority = "primary-input"
    },
	prepare_range = 40,
    preparing_animation = turret_blue_laser_extension,
    prepared_animation = turret_blue_laser_animation,
    folding_animation = turret_blue_laser_extension,
    folded_animation = turret_blue_laser_extension,
    base_picture =
    {
    filename = "__hardcorio__/graphics/entity/player/turret_blue_laser/turret-base.png",
      priority = "high",
      width = 64,
      height = 64,
	  frame_count = 1,
      shift = { 0, -0.3 }
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "laser",
      cooldown = 1,
      projectile_creation_distance = 0.18,
	  projectile_center = {0, 0.45},
      range = 30,
	  ammo_type =
		{
		  type = "projectile",
		  category = "laser-turret",
		  energy_consumption = "120kJ",
		  target_type = "direction",
		  action =
		  {
		  {
			type = "line",
			range = 35,
			width = 1,
			entity_flags = {"placeable-enemy", "placeable-neutral"},
			source_effects =
			{
			  type = "create-explosion",
			  entity_name = "blue-lightning-bolt"
			},
			action_delivery =
			{
			  type = "instant",
			  target_effects =
			  {
				type = "damage",
				damage = { amount = 1, type="fire"}
			  }
			}
		  },
		  }
		},
	},
	call_for_help_radius = 40
 }, 
 {
    type = "explosion",
    name = "blue-lightning-bolt",
    flags = {"not-on-map"},
    animation_speed = 10,
    rotate = true,
    beam = true,
    animations =
    {
	  {
        filename = "__hardcorio__/graphics/entity/player/blue-laser1.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      },
      {
        filename = "__hardcorio__/graphics/entity/player/blue-laser2.png",
        priority = "low",
        width = 5,
        height = 5,
        frame_count = 6,
      }
    },
  },
  
  {
    type = "item",
    name = "plasma-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_plasma/icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "plasma",
    order = "a-d",
    place_result = "plasma-turret",
    stack_size = 5
  },
  
    {
    type = "electric-turret",
    name = "plasma-turret",
    icon = "__hardcorio__/graphics/entity/player/turret_plasma/icon.png",
    icon_size = 32,
    flags = { "placeable-player", "placeable-enemy", "player-creation"},
    minable = { mining_time = 0.5, result = "plasma-turret" },
    max_health = 400,
    corpse = "big-remnants",
    collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
    selection_box = {{-0.75, -0.75}, {0.75, 0.75}},
    rotation_speed = 0.01,
    preparing_speed = 0.05,
    dying_explosion = "medium-explosion",
	resistances = 
    {
	  { type = "fire", percent = 100 },{ type = "physical", percent = 100 },{ type = "piercing", percent = 100 },
    },
    folding_speed = 0.05,
	energy_source =
    {
      type = "electric",
      buffer_capacity = "100000kJ",
      input_flow_limit = "500kW",
      drain = "20kW",
      usage_priority = "primary-input"
    },
	prepare_range = 40,
    preparing_animation = turret_plasma_extension,
    prepared_animation = turret_plasma_animation,
    folding_animation = turret_plasma_extension,
    folded_animation = turret_plasma_extension,
    base_picture =
    {
    filename = "__hardcorio__/graphics/entity/player/turret_plasma/turret-base.png",
      priority = "high",
      width = 96,
      height = 96,
	  frame_count = 1,
      shift = { 0, -0.3 }
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "electric",
      cooldown = 100,
	  damage_modifier = 0.5,
      projectile_center = {0, 0.8},
      projectile_creation_distance = 1.2,
      range = 35,
		ammo_type =
    {
      category = "laser-turret",
		  energy_consumption = "15000kJ",
		  target_type = "direction",
      action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "ps15000pr",
            starting_speed = 2,
          }
        }
    },
	      sound =
      {
          filename = "__hardcorio__/sound/player/weapons/plasma-heavy.wav",
          volume = 0.5
        }
	},
	call_for_help_radius = 40
 },
})