require "util"

local car_light=
	{
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    }
local car_burner=
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.25, 0.25},
          frequency = 50,
          position = {0, 1.5},
          slow_down_factor = 0.9,
          starting_frame = 3,
          starting_frame_deviation = 5,
          starting_frame_speed = 0,
          starting_frame_speed_deviation = 5
        }
      }
    }
local car_animation=
	{
      layers =
      {
        {
          width = 102,
          height = 86,
          frame_count = 2,
          axially_symmetrical = false,
          direction_count = 64,
          shift = {0, -0.1875},
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
             filename = "__base__/graphics/entity/car/car-1.png",
             width_in_frames = 2,
             height_in_frames = 22,
            },
            {
             filename = "__base__/graphics/entity/car/car-2.png",
             width_in_frames = 2,
             height_in_frames = 22,
            },
            {
             filename = "__base__/graphics/entity/car/car-3.png",
             width_in_frames = 2,
             height_in_frames = 20,
            },
          }
        },
        {
          width = 100,
          height = 75,
          frame_count = 2,
          apply_runtime_tint = true,
          axially_symmetrical = false,
          direction_count = 64,
          max_advance = 0.2,
          line_length = 2,
          shift = {0, -0.171875},
          stripes = util.multiplystripes(2,
          {
            {
              filename = "__base__/graphics/entity/car/car-mask-1.png",
              width_in_frames = 1,
              height_in_frames = 22,
            },
            {
              filename = "__base__/graphics/entity/car/car-mask-2.png",
              width_in_frames = 1,
              height_in_frames = 22,
            },
            {
              filename = "__base__/graphics/entity/car/car-mask-3.png",
              width_in_frames = 1,
              height_in_frames = 20,
            },
          })
        },
        {
          width = 114,
          height = 76,
          frame_count = 2,
          draw_as_shadow = true,
          axially_symmetrical = false,
          direction_count = 64,
          shift = {0.28125, 0.25},
          max_advance = 0.2,
          stripes = util.multiplystripes(2,
          {
           {
            filename = "__base__/graphics/entity/car/car-shadow-1.png",
            width_in_frames = 1,
            height_in_frames = 22,
           },
           {
            filename = "__base__/graphics/entity/car/car-shadow-2.png",
            width_in_frames = 1,
            height_in_frames = 22,
           },
           {
            filename = "__base__/graphics/entity/car/car-shadow-3.png",
            width_in_frames = 1,
            height_in_frames = 20,
           },
          })
        }
      }
    }
local car_turret_animation=
    {
      layers =
      {
        {
          filename = "__base__/graphics/entity/car/car-turret.png",
          line_length = 8,
          width = 36,
          height = 29,
          frame_count = 1,
          axially_symmetrical = false,
          direction_count = 64,
          shift = {0.03125, -0.890625},
          animation_speed = 8,
        },
        {
          filename = "__base__/graphics/entity/car/car-turret-shadow.png",
          line_length = 8,
          width = 46,
          height = 31,
          frame_count = 1,
          axially_symmetrical = false,
          draw_as_shadow = true,
          direction_count = 64,
          shift = {0.875, 0.359375},
        }
      }
    }
local car_stop_trigger=
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    }
local car_working_sound=
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    }
	
data:extend(
{

	{
    type = "item",
    name = "truck",
    icon = "__hardcorio__/graphics/entity/player/truck/carhoTruck_icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-d[truck]",
    stack_size = 1,
	place_result = "truck",
  },
	
	 {
    type = "car",
    name = "truck",
    icon = "__hardcorio__/graphics/entity/player/truck/carhoTruck_icon.png",
    icon_size = 32,
    flags = {"pushable", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 100, result = "truck"},
    max_health = 300,
	energy_per_hit_point = 1,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
	  { type = "physical", percent = 100 },
	  { type = "fire", percent = 100 },
	  { type = "piercing", percent = 100 },
      { type = "impact", decrease = 10, percent = 60},
      { type = "acid", percent = 40 },
	  { type = "claw", percent = 10 }
    },
    collision_box = {{-1, -1.5}, {1, 1.5}},
    selection_box = {{-1, -1.5}, {1, 1.5}},
    effectivity = 0.5,
    braking_power = "200kW",
    burner =
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.25, 0.25},
          frequency = 50,
          position = {0, 1.5},
          slow_down_factor = 0.9,
          starting_frame = 3,
          starting_frame_deviation = 5,
          starting_frame_speed = 0,
          starting_frame_speed_deviation = 5
        }
      }
    },
    consumption = "150kW",
    friction = 2e-3,
    crash_damage_multiplier = 0.1,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
    animation =
    {
      layers =
      {
        {
          width = 128,
          height = 128,
          frame_count = 2,
          axially_symmetrical = false,
          direction_count = 72,
          shift = {0, -0.2},
          animation_speed = 2,
          max_advance = 0.2,
		  scale = 1,
          stripes =
          {
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_01.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_01_1.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_02.png",
             width_in_frames = 1,
             height_in_frames = 16,
            }  ,          
			{
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_02_1.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_03.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },           
			{
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_03_1.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_04.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },           
			{
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_04_1.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_05.png",
             width_in_frames = 1,
             height_in_frames = 8,
            },          
			{
             filename = "__hardcorio__/graphics/entity/player/truck/carhoTruck_05_1.png",
             width_in_frames = 1,
             height_in_frames = 8,
            },
          }
        }
      }
    },

    turret_rotation_speed = 0.35 / 60,
    stop_trigger_speed = 0.2,
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    crash_trigger = car_crash_trigger,
    sound_minimum_speed = 0.2;
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    rotation_speed = 0.01,
    weight = 5000,
	guns = {"truck-repair"},
    inventory_size = 60
  },

  {
    type = "item",
    name = "hummer",
    icon = "__base__/graphics/icons/car.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-e[hummer]",
    stack_size = 1,
	place_result = "hummer",
  },
  {
    type = "car",
    name = "hummer",
    icon = "__base__/graphics/icons/car.png",
    icon_size = 32,
    flags = {"pushable", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 100, result = "hummer"},
    max_health = 200,
	resistances =
    {
	  { type = "physical", percent = 100 },
	  { type = "fire", percent = 100 },
	  { type = "piercing", percent = 100 },
      { type = "impact", decrease = 10, percent = 60},
      { type = "acid", percent = 70 },
	  { type = "claw", percent = 25 }
    },
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_per_hit_point = 1,
    collision_box = {{-0.7, -1}, {0.7, 1}},
    selection_box = {{-0.7, -1}, {0.7, 1}},
    effectivity = 0.5,
    braking_power = "200kW",
    burner = car_burner,
    consumption = "150kW",
    friction = 2e-3,
    light = car_light,
    animation = car_animation,
    turret_animation = car_turret_animation,
    turret_rotation_speed = 0.35 / 60,
    stop_trigger_speed = 0.2,
    stop_trigger = car_stop_trigger,
    crash_trigger = car_crash_trigger,
    sound_minimum_speed = 0.2;
    working_sound = car_working_sound,
    open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    rotation_speed = 0.015,
    weight = 700,
    guns = { "flamethrower","car-launcher"},
    inventory_size = 2
  }, 
  {
    type = "item",
    name = "new-tank",
    icon = "__hardcorio__/graphics/entity/player/tank/Tank_icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-f[new-tank]",
    stack_size = 1,
	place_result = "new-tank0",
  },
})
for i = 0,100 do
  data:extend({
  {
    type = "car",
    name = "new-tank"..i,
    icon = "__hardcorio__/graphics/entity/player/tank/Tank_icon.png",
    icon_size = 32,
    flags = {"pushable", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 180, result = "new-tank"},
    max_health = 3000,
	energy_per_hit_point = 0.3,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
	  { type = "physical", percent = 100 },
	  { type = "fire", percent = 100 },
	  { type = "piercing", percent = 100 },
      { type = "impact", decrease = 50, percent = 60},
      { type = "acid", percent = 20 },
	  { type = "claw", percent = 60 }
    },
    collision_box = {{-0.9*1.5, -1.3*1.5}, {0.9*1.5, 1.3*1.5}},
    selection_box = {{-0.9*1.75, -1.3*1.75}, {0.9*1.75, 1.3*1.75}},
    effectivity = 0.15 + 0.0015*i,
    braking_power = "1000kW",
    burner =
    {
      fuel_category = "chemical",
      effectivity = 1,
      fuel_inventory_size = 4,
    },
    consumption = "1500kW",
    terrain_friction_modifier = 0.2,
    friction = 2e-3,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
	
    animation =
    {
      layers =
      {
        {
          width = 128,
          height = 128,
          frame_count = 1,
          axially_symmetrical = false,
          direction_count = 72,
          shift = {0, 0},
          animation_speed = 8,
          max_advance = 1,
		  scale = 1.5,
          stripes =
          {
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_01.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_02.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_03.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_04.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_05.png",
             width_in_frames = 1,
             height_in_frames = 8,
            }
          }
        },
      }
    },
	
    turret_animation =
    {
      layers =
      {
        {
          width = 128,
          height = 128,
          frame_count = 1,
          axially_symmetrical = false,
          direction_count = 72,
          shift = {0, 0},
          animation_speed = 8,
          max_advance = 1,
		  scale = 1.5,
          stripes =
          {
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_gun_01.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_gun_02.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_gun_03.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_gun_04.png",
             width_in_frames = 1,
             height_in_frames = 16,
            },
            {
             filename = "__hardcorio__/graphics/entity/player/tank/Tank_gun_05.png",
             width_in_frames = 1,
             height_in_frames = 8,
            }
          }
        },
      }
    },
    turret_rotation_speed = 0.0035+0.000085*i,
    turret_return_timeout = 300,
    stop_trigger_speed = 0.2,
    sound_no_fuel =
    {
      {
        filename = "__base__/sound/fight/tank-no-fuel-1.ogg",
        volume = 0.6
      },
    },
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    crash_trigger = crash_trigger(),
    sound_minimum_speed = 0.15;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/fight/tank-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/fight/tank-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/fight/tank-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    rotation_speed = 0.002+0.00005*i,
    tank_driving = true,
    weight = 20000,
    inventory_size = 4,
    guns = { "tank-repair"..i, "tank-laser"..i, "tank-cannon"..i, "tank-launcher"..i },
  },
})
end