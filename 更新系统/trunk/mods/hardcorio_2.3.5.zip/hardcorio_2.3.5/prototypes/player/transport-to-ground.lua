data:extend(
{
  {
    type = "recipe",
    name = "underground-belt-2",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
      {"iron-plate", 3},
      {"transport-belt", 3},
      {"underground-belt", 1}
    },
    result = "underground-belt-2"
  },
  {
    type = "item",
    name = "underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/underground-belt.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "longbelt",
    order = "b[underground-belt]-d[underground-belt-2]",
    place_result = "underground-belt-2",
    stack_size = 50
  },
  {
    type = "underground-belt",
    name = "underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/underground-belt.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "underground-belt-2"},
    max_health = 150,
    corpse = "small-remnants",
    max_distance = 11,
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    underground_remove_belts_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines-remove.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    resistances = 
    { 
      {
        type = "fire",
        percent = 100
      },
      {
        type = "physical",
        percent = 100
      },
      {
        type = "piercing",
        percent = 100
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    animation_speed_coefficient = 32,
    belt_horizontal = basic_belt_horizontal,
    belt_vertical = basic_belt_vertical,
    ending_top = basic_belt_ending_top,
    ending_bottom = basic_belt_ending_bottom,
    ending_side = basic_belt_ending_side,
    starting_top = basic_belt_starting_top,
    starting_bottom = basic_belt_starting_bottom,
    starting_side = basic_belt_starting_side,
    fast_replaceable_group = "transport-belt",
    speed = 0.03125,
    structure =
    {
      direction_in =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.25, 0},
          width = 57,
          height = 43,
          y = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            y = 85,
            scale = 0.5
          }
        }
      },
      direction_out =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.25, 0},
          width = 57,
          height = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            scale = 0.5
          }
        }
      }
    },
    ending_patch = ending_patch_prototype
  },
  
  {
    type = "recipe",
    name = "fast-underground-belt-2",
    enabled = "false",
    ingredients =
    {
      {"iron-plate", 9},
      {"fast-transport-belt", 9},
      {"fast-underground-belt", 1}
    },
    result = "fast-underground-belt-2"
  },
  {
    type = "recipe",
    name = "fast-underground-belt-3",
    enabled = "false",
    ingredients =
    {
      {"iron-plate", 6},
      {"fast-transport-belt", 6},
      {"iron-gear-wheel", 30},
      {"underground-belt-2", 1}
    },
    result = "fast-underground-belt-2"
  },
  {
    type = "item",
    name = "fast-underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/fast-underground-belt.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "longbelt",
    order = "b[underground-belt]-e[fast-underground-belt-2]",
    place_result = "fast-underground-belt-2",
    stack_size = 50
  },
  {
    type = "underground-belt",
    name = "fast-underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/fast-underground-belt.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "fast-underground-belt-2"},
    max_health = 160,
    corpse = "small-remnants",
    max_distance = 23,
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    underground_remove_belts_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines-remove.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    resistances = 
    { 
      {
        type = "fire",
        percent = 100
      },
      {
        type = "physical",
        percent = 100
      },
      {
        type = "piercing",
        percent = 100
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    animation_speed_coefficient = 32,
    belt_horizontal = fast_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = fast_belt_vertical,
    ending_top = fast_belt_ending_top,
    ending_bottom = fast_belt_ending_bottom,
    ending_side = fast_belt_ending_side,
    starting_top = fast_belt_starting_top,
    starting_bottom = fast_belt_starting_bottom,
    starting_side = fast_belt_starting_side,
    fast_replaceable_group = "transport-belt",
    speed = 0.0625,
    structure =
    {
      direction_in =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/fast-underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.26, 0},
          width = 57,
          height = 43,
          y = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-fast-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            y = 85,
            scale = 0.5
          }
        }
      },
      direction_out =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/fast-underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.26, 0},
          width = 57,
          height = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-fast-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            scale = 0.5
          }
        }
      }
    },
    ending_patch = ending_patch_prototype
  },
  
  {
    type = "recipe",
    name = "express-underground-belt-2",
    enabled = "false",
    ingredients =
    {
      {"iron-plate", 15},
      {"express-transport-belt", 15},
      {"express-underground-belt", 1}
    },
    result = "express-underground-belt-2"
  },
  {
    type = "recipe",
    name = "express-underground-belt-3",
    category = "crafting-with-fluid",
    enabled = "false",
    ingredients =
    {
      {"iron-plate", 6},
      {"express-transport-belt", 6},
      {"iron-gear-wheel", 60},
      {"fast-underground-belt-2", 1},
      {type="fluid", name="lubricant", amount=240},	  
    },
    result = "express-underground-belt-2"
  },
  {
    type = "item",
    name = "express-underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/express-underground-belt.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "longbelt",
    order = "b[underground-belt]-f[express-underground-belt-2]",
    place_result = "express-underground-belt-2",
    stack_size = 50
  },
  {
    type = "underground-belt",
    name = "express-underground-belt-2",
    icon = "__hardcorio__/graphics/icons/building/express-underground-belt.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "express-underground-belt-2"},
    max_health = 170,
    corpse = "small-remnants",
    max_distance = 35,
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    underground_remove_belts_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines-remove.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    resistances = 
    { 
      {
        type = "fire",
        percent = 100
      },
      {
        type = "physical",
        percent = 100
      },
      {
        type = "piercing",
        percent = 100
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    animation_speed_coefficient = 32,
    belt_horizontal = express_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = express_belt_vertical,
    ending_top = express_belt_ending_top,
    ending_bottom = express_belt_ending_bottom,
    ending_side = express_belt_ending_side,
    starting_top = express_belt_starting_top,
    starting_bottom = express_belt_starting_bottom,
    starting_side = express_belt_starting_side,
    fast_replaceable_group = "transport-belt",
    speed = 0.09375,
    structure =
    {
      direction_in =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/express-underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.26, 0},
          width = 57,
          height = 43,
          y = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-express-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            y = 85,
            scale = 0.5
          }
        }
      },
      direction_out =
      {
        sheet =
        {
          filename = "__hardcorio__/graphics/entity/player/underground-belt/express-underground-belt-structure.png",
          priority = "extra-high",
          shift = {0.26, 0},
          width = 57,
          height = 43,
          hr_version =
          {
            filename = "__hardcorio__/graphics/entity/player/underground-belt/hr-express-underground-belt-structure.png",
            priority = "extra-high",
            shift = {0.15625, 0.0703125},
            width = 106,
            height = 85,
            scale = 0.5
          }
        }
      }
    },
    ending_patch = ending_patch_prototype
  }
}
)