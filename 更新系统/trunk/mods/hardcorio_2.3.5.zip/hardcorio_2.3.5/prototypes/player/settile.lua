data:extend(
{
  {
    type = "technology",
    name = "engineering-bomb",
    icon = "__hardcorio__/graphics/technology/engineering-bomb.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "detonator"
      },
      {
        type = "unlock-recipe",
        recipe = "engineering-bomb"
      }
    },
    prerequisites = {"explosives", "advanced-chemistry"},
    unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 15
    },
    order = "e-d"
  },
  {
    type = "recipe",
    name = "detonator",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"advanced-circuit", 2},
      {"battery", 1}
    },
    result = "detonator"
  },
  {
    type = "recipe",
    name = "engineering-bomb",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"stone-brick", 18},
      {"steel-plate", 12},
      {"advanced-circuit", 8},
      {"explosives", 32},
    },
    result = "engineering-bomb"
  },
  {
    type = "capsule",
    name = "detonator",
    icon = "__hardcorio__/graphics/icons/items/detonator.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    capsule_action =
    {
      type = "use-on-self",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 120,
        range = 0,
        ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "instant",
              source_effects =
              {
                  type = "create-entity",
                  entity_name = "event-detonator",
                  trigger_created_entity="true"
              }
            }
          }
        }
      }
    },
    subgroup = "defensive-structure",
    order = "d[settile]-a[detonator]",
    stack_size = 100
  },
  {
    type = "item",
    name = "engineering-bomb",
    icon = "__hardcorio__/graphics/icons/items/bomb.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    damage_radius = 4,
    subgroup = "defensive-structure",
    order = "d[settile]-b[engineering-bomb]",
    place_result = "engineering-bomb",
    stack_size = 5,
    trigger_radius = 0
  },
  {
    type = "simple-entity",
	name = "engineering-bomb",
    icon = "__hardcorio__/graphics/icons/items/bomb.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation", "not-on-map"},
    minable = {mining_time = 5, result = "engineering-bomb"},
    max_health = 20,
    resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 }, { type = "piercing", percent = 100 } },
    corpse = "small-remnants",
    collision_box = {{-0.99, -0.99}, {0.99, 0.99}},
    selection_box = {{-1, -1}, {1, 1}},
    render_layer = "object",
    picture =
    {
	  layers =
	  {
	    {
          filename = "__hardcorio__/graphics/icons/items/bomb.png",
          priority = "medium",
          width = 32,
          height = 32,
	      scale = 1
        },
	    {
          filename = "__hardcorio__/graphics/entity/wall.png",
          priority = "medium",
          width = 155,
          height = 165,
		  shift = {-0.02, -0.02},
	      scale = 0.4
        },
	    {
          filename = "__hardcorio__/graphics/entity/wall-shadow.png",
          priority = "medium",
          draw_as_shadow = true,
          width = 169,
          height = 160,
		  shift = {0.06, 0.1},
	      scale = 0.4
        },
	  }
	}
  }
})
