data:extend(
{
  {
    type = "resource-category",
    name = "solid-elerium"
  },
  
  {
    type = "resource-category",
    name = "liquid-elerium"
  },
  
  {
    type = "resource-category",
    name = "nothing-mine"
  }
}
)
