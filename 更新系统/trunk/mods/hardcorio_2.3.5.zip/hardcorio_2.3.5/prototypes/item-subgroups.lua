data:extend(
{

  {
    type = "item-subgroup",
    name = "longbelt",
    group = "logistics",
    order = "b-b",
  },

  {
    type = "item-subgroup",
    name = "livesupport",
    group = "production",
    order = "b-b"
  },

  {
    type = "item-subgroup",
    name = "chemistry",
    group = "intermediate-products",
    order = "a-b"
  },

  {
    type = "item-subgroup",
    name = "smelting",
    group = "intermediate-products",
    order = "c-a"
  },

  {
    type = "item-subgroup",
    name = "decompressing",
    group = "intermediate-products",
    order = "c-b"
  },

  {
    type = "item-subgroup",
    name = "compressing",
    group = "intermediate-products",
    order = "c-c"
  },

  {
    type = "item-subgroup",
    name = "smelting2",
    group = "intermediate-products",
    order = "c-d"
  },

  {
    type = "item-subgroup",
    name = "127x33",
    group = "combat",
    order = "a"
  },
  
  {
    type = "item-subgroup",
    name = "556x45",
    group = "combat",
    order = "b"
  },
  
  {
    type = "item-subgroup",
    name = "762x39",
    group = "combat",
    order = "c"
  },
  
  {
    type = "item-subgroup",
    name = "127x99",
    group = "combat",
    order = "d"
  },
  
  {
    type = "item-subgroup",
    name = "grenade",
    group = "combat",
    order = "e"
  },
  
  {
    type = "item-subgroup",
    name = "laser",
    group = "combat",
    order = "f"
  },
  
  {
    type = "item-subgroup",
    name = "plasma",
    group = "combat",
    order = "g"
  },
  
  {
    type = "item-subgroup",
    name = "cars",
    group = "combat",
    order = "h"
  },

})
