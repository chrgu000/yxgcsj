data:extend(
{
{
    type = "technology",
    name = "laser-basic",
    icon = "__hardcorio__/graphics/technology/laser-basic.png",
	icon_size = 64,
    effects =
    {

    },
	prerequisites = {"556x45-basic",  "nuclear-power"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
      },
      time = 20
    },
    order = "a-a-e-a"
},

{
    type = "technology",
    name = "laser-ammo",
    icon = "__hardcorio__/graphics/technology/laser-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-laser-rifle"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-gauss-rifle"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-ps40"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-ps2000"
    },
	{
    type = "unlock-recipe",
    recipe = "recipe-ps160"
	}
    },
	prerequisites = {"laser-basic"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-e-b-a"
},

{
    type = "technology",
    name = "laser-turret-1",
    localised_name = {"technology-name.laser-turret-1"},
    icon = "__hardcorio__/graphics/technology/laser-turret.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-red-laser-turret"
    },
    },
	prerequisites = {"laser-basic"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-e-c-a"
},

{
    type = "technology",
    name = "laser-turret-2",
    localised_name = {"technology-name.laser-turret-2"},
    icon = "__hardcorio__/graphics/technology/laser-turret.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-green-laser-turret"
    },
    },
	prerequisites = {"laser-turret-1"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-e-c-b"
},

{
    type = "technology",
    name = "laser-turret-3",
    localised_name = {"technology-name.laser-turret-3"},
    icon = "__hardcorio__/graphics/technology/laser-turret.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-blue-laser-turret"
    },
    },
	prerequisites = {"laser-turret-2"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-e-c-b"
},

}
)
