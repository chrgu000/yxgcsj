data:extend(
{
{
    type = "technology",
    name = "127x99-basic",
    icon = "__hardcorio__/graphics/technology/127x99-basic.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-gun-turret-127x99"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-m82"
	},
    },
	prerequisites = {"automation-2", "steel-processing", "radar"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
      },
      time = 5
    },
	upgrade = "true",
    order = "a-a-c-a"
},

{
    type = "technology",
    name = "127x99-basic-2",
    icon = "__hardcorio__/graphics/technology/127x99-basic.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-m82s"
	}
    },
	prerequisites = {"127x99-basic", "advanced-electronics"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
      },
      time = 5
    },
	upgrade = "true",
    order = "a-a-c-a"
},

{
    type = "technology",
    name = "127x99-ammo-1",
    localised_name = {"technology-name.127x99-ammo-1"},
    icon = "__hardcorio__/graphics/technology/127x99-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-127x99ep"
    },
    },
	prerequisites = {"127x99-basic", "compressing", "electrolize"},
    unit =
    {
      count = 30,
      ingredients =
      {
        {"science-pack-1", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-c-b-a"
},

{
    type = "technology",
    name = "127x99-ammo-2",
    localised_name = {"technology-name.127x99-ammo-2"},
    icon = "__hardcorio__/graphics/technology/127x99-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-127x99mg"
    },
    },
	prerequisites = {"127x99-ammo-1", "chemistry"},
    unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 2},
		{"science-pack-2", 1},
      },
      time = 20
    },
	upgrade = "true",
    order = "a-a-c-b-b"
},
{
    type = "technology",
    name = "127x99-ammo-3",
    localised_name = {"technology-name.127x99-ammo-3"},
    icon = "__hardcorio__/graphics/technology/127x99-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-127x99he"
    },
    },
	prerequisites = {"127x99-ammo-2", "explosives", "advanced-chemistry"},
    unit =
    {
      count = 40,
      ingredients =
      {
        {"science-pack-1", 3},
		{"science-pack-2", 2},
		{"science-pack-3", 1},
      },
      time = 40
    },
	upgrade = "true",
    order = "a-a-c-b-c"
},
{
    type = "technology",
    name = "127x99-ammo-4",
    localised_name = {"technology-name.127x99-ammo-4"},
    icon = "__hardcorio__/graphics/technology/127x99-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-127x99du"
    },
    },
	prerequisites = {"127x99-ammo-3", "high-tech-chemistry"},
    unit =
    {
      count = 80,
      ingredients =
      {
        {"science-pack-1", 4},
		{"science-pack-2", 3},
		{"science-pack-3", 2},
		{"high-tech-science-pack", 1},
      },
      time = 40
    },
	upgrade = "true",
    order = "a-a-c-b-d"
},


}
)
