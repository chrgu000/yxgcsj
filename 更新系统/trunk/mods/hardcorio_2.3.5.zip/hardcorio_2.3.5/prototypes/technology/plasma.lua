data:extend(
{
{
    type = "technology",
    name = "plasma-basic",
    icon = "__hardcorio__/graphics/technology/plasma-basic.png",
	icon_size = 64,
    effects =
    {

    },
	prerequisites = {"laser-basic", "high-tech-chemistry"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"high-tech-science-pack", 1},
      },
      time = 30
    },
    order = "a-a-f-a"
},

{
    type = "technology",
    name = "plasma-ammo",
    icon = "__hardcorio__/graphics/technology/plasma-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-plasma-shotgun"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-plasma-gun"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-plasma-sniper"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-ps3200"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-ps200"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-ps4000"
    },
    },
	prerequisites = {"plasma-basic"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"high-tech-science-pack", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-f-b-a"
},

{
    type = "technology",
    name = "plasma-turret",
    icon = "__hardcorio__/graphics/technology/plasma-turret.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-plasma-turret"
    },
    },
	prerequisites = {"plasma-basic", "advanced-electronics-2"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"high-tech-science-pack", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-f-c-a"
},
}
)
