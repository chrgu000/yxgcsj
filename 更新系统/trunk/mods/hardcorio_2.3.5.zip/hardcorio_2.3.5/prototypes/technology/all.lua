data:extend(
{
   {
    type = "technology",
    name = "fish-farm",
    icon = "__hardcorio__/graphics/technology/fish-farm.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "incubator"
      },
      {
        type = "unlock-recipe",
        recipe = "feeder"
      },
      {
        type = "unlock-recipe",
        recipe = "cutting-small-fish"
      },
      {
        type = "unlock-recipe",
        recipe = "cutting-tiny-fish"
      },
      {
        type = "unlock-recipe",
        recipe = "organic-food"
      }
    },
	prerequisites = {"support-tank"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
      },
      time = 10
    },
    order = "a-a-a-2",
  },
  
   {
    type = "technology",
    name = "support-tank",
    icon = "__hardcorio__/graphics/technology/support-tank.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "support-tank"
      },
      {
        type = "unlock-recipe",
        recipe = "chemical-plant"
      },
      {
        type = "unlock-recipe",
        recipe = "biomass-food"
      },
      {
        type = "unlock-recipe",
        recipe = "water"
      },
      {
        type = "unlock-recipe",
        recipe = "cutting-fish"
      }
    },
	prerequisites = {"electrolize", "steel-processing", "chemistry"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 1},
      },
      time = 10
    },
    order = "a-a-a-1",
  },
  
   {
    type = "technology",
    name = "electrolize",
    icon = "__hardcorio__/graphics/technology/electrolize.png",
	icon_size = 64,
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "electrolizer"
      },
	  {
        type = "unlock-recipe",
        recipe = "electrolize"
      },
	  {
        type = "unlock-recipe",
        recipe = "electrolize-oxy"
      }
    },
	prerequisites = {"electronics"},
    unit =
    {
      count = 30,
      ingredients =
      {
        {"science-pack-1", 1},
      },
      time = 10
    },
    order = "a-a-a",
  },
  
   {
    type = "technology",
    name = "radar",
    icon = "__hardcorio__/graphics/technology/radar.png",
	icon_size = 64,
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "radar"
      }
	  
    },
	prerequisites = {"electronics"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
      },
      time = 20
    },
    order = "a-a",
  },
  
   {
    type = "technology",
    name = "observer",
    icon = "__hardcorio__/graphics/technology/radar-2.png",
	icon_size = 64,
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "observer"
      }
	  
    },
	prerequisites = {"nuclear-power", "advanced-electronics-2", "radar"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 2},
		{"science-pack-2", 2},
		{"science-pack-3", 1},
      },
      time = 20
    },
    order = "a-a",
  },
  
  {
    type = "technology",
    name = "laboratory",
    icon = "__hardcorio__/graphics/technology/laboratory.png",
	icon_size = 64,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "lab"
      }
    },
    prerequisites = {"logistics"},
    unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 5
    },
    order = "c-m"
  },
  
  {
    type = "technology",
    name = "chemistry",
	icon_size = 64,
    icon = "__hardcorio__/graphics/technology/chemistry.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "science-pack-2"
      }
    },
    prerequisites = {"logistics"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 15
    },
    order = "c-l-a"
  },
  
  {
    type = "technology",
    name = "advanced-chemistry",
	icon_size = 64,
    icon = "__hardcorio__/graphics/technology/advanced-chemistry.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "science-pack-3"
      }
    },
    prerequisites = {"engine", "advanced-electronics"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 15
    },
    order = "c-l-b"
  },
  
  {
    type = "technology",
    name = "production-chemistry",
	icon_size = 64,
    icon = "__hardcorio__/graphics/technology/production-chemistry.png",
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "production-science-pack"
      }
    },
    prerequisites = {"electric-engine", "advanced-material-processing-2", "advanced-chemistry"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 15
    },
    order = "c-l-c"
  },
  
  {
    type = "technology",
    name = "high-tech-chemistry",
	icon_size = 64,
    icon = "__hardcorio__/graphics/technology/high-tech-chemistry.png",
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "high-tech-science-pack"
      }
    },
    prerequisites = {"battery", "advanced-electronics-2", "speed-module", "production-chemistry"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 15
    },
    order = "c-l-d"
  },
  
  {
    type = "technology",
    name = "repair-kit",
    icon = "__hardcorio__/graphics/icons/ammo/repair-kit.png",
	icon_size = 32,
    effects =
    {
      {	
        type = "unlock-recipe",
        recipe = "recipe-repair-kit"
      }
    },
    prerequisites = {"automobilism", "advanced-electronics"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 15
    },
    order = "e-c"
  },
  
  {
    type = "technology",
    name = "medi-kit",
    icon = "__hardcorio__/graphics/icons/ammo/medi-kit.png",
	icon_size = 32,
    effects =
    {
      {	
        type = "unlock-recipe",
        recipe = "recipe-regenerator"
      },
      {	
        type = "unlock-recipe",
        recipe = "recipe-medi-kit"
      }
    },
    prerequisites = {"sulfur-processing"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 15
    },
    order = "d-c-a"
  },
  
  {
    type = "technology",
    name = "uranium-walls",
    icon = "__hardcorio__/graphics/technology/uranium-walls.png",
	icon_size = 64,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "uranium-wall"
      },
      {
        type = "unlock-recipe",
        recipe = "uranium-brick"
      },
      {
        type = "unlock-recipe",
        recipe = "uranium-stone"
      }
    },
	prerequisites = {"stone-walls", "nuclear-power", "high-tech-chemistry"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 3},
        {"science-pack-2", 2},
        {"science-pack-3", 1},
        {"high-tech-science-pack", 1},
      },
      time = 10
    },
    order = "a-l-a-b"
  },
  
  {
    type = "technology",
    name = "uranium-gates",
    icon = "__hardcorio__/graphics/technology/uranium-gates.png",
	icon_size = 64,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "uranium-gate"
      }
    },
    prerequisites = {"uranium-walls", "gates"},
    unit =
    {
      count = 10,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"high-tech-science-pack", 1},
      },
      time = 30
    },
    order = "a-l-a-c"
  },
  
  {
    type = "technology",
    name = "compressing",
    icon = "__hardcorio__/graphics/technology/compressing.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "recipe-compressor"
      },
      {
        type = "unlock-recipe",
        recipe = "compressing-iron-ore"
      },
      {
        type = "unlock-recipe",
        recipe = "compressing-copper-ore"
      },
      {
        type = "unlock-recipe",
        recipe = "compressing-iron-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "compressing-copper-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "compressing-steel-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "uncompressing-iron-ore"
      },
      {
        type = "unlock-recipe",
        recipe = "uncompressing-copper-ore"
      },
      {
        type = "unlock-recipe",
        recipe = "uncompressing-iron-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "uncompressing-copper-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "uncompressing-steel-plate"
      },
      {
        type = "unlock-recipe",
        recipe = "smelt-iron-ore-block"
      },
      {
        type = "unlock-recipe",
        recipe = "smelt-copper-ore-block"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-iron-plate-block"
      }
    },
	prerequisites = {"automation-2", "steel-processing"},
    unit =
    {
      count = 30,
      ingredients = {{"science-pack-1", 1}},
      time = 15
    },
    order = "c-a-a"
  },

  {
    type = "technology",
    name = "grinding",
    icon = "__hardcorio__/graphics/technology/grinder-upgr.png",
	icon_size = 64,
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "recipe-grinder"
      },
      {
        type = "unlock-recipe",
        recipe = "grind-iron"
      },
	  {
        type = "unlock-recipe",
        recipe = "grind-copper"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-copper-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-iron-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "recipe-steel-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-steel-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "compressing-iron-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "compressing-copper-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "compressing-steel-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "uncompressing-iron-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "uncompressing-copper-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "uncompressing-steel-dust"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-iron-dust-block"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-copper-dust-block"
      },
	  {
        type = "unlock-recipe",
        recipe = "smelt-steel-dust-block"
      }
    },
	prerequisites = {"advanced-electronics", "electric-engine", "compressing"},
    unit =
    {
      count = 500,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1}
      },
      time = 10
    },
    order = "c-a-b",
  }
}
)
