data:extend({{
	type = "technology",
	name = "gun-damage-upgrade-1",
	icon = "__hardcorio__/graphics/technology/gun-damage-upgr.png",
	icon_size = 64,
	effects =
	{
      {
		type = "ammo-damage",
		ammo_category = "shotgun-shell",
		modifier = 0.0125
	  },
	  {
		type = "ammo-damage",
		ammo_category = "556x45",
		modifier = 0.0125
	  },
	  {
		type = "ammo-damage",
		ammo_category = "762x39",
		modifier = 0.0125
	  },
	  {
		type = "ammo-damage",
		ammo_category = "127x99",
		modifier = 0.0125
	  },
	  {
		type = "ammo-damage",
		ammo_category = "105x",
		modifier = 0.0125
	  },
	  {
		type = "ammo-damage",
		ammo_category = "125x",
		modifier = 0.0125
	  },
	},
	prerequisites = {},
	unit =
	{
		count = 1,
		ingredients =
		{
			{"science-pack-1", 2},
			{"enemy-dna", 1},
		},
	  time = 5
	},
	upgrade = "true",
	order = "1-a-1"
}})

for i = 2,100 do
	data:extend({{
			type = "technology",
			name = "gun-damage-upgrade-"..i,
			icon = "__hardcorio__/graphics/technology/gun-damage-upgr.png",
			icon_size = 64,
			effects =
			{
			  {
				type = "ammo-damage",
				ammo_category = "shotgun-shell",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			  {
				type = "ammo-damage",
				ammo_category = "556x45",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			  {
				type = "ammo-damage",
				ammo_category = "762x39",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			  {
				type = "ammo-damage",
				ammo_category = "127x99",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			  {
				type = "ammo-damage",
				ammo_category = "105x",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			  {
				type = "ammo-damage",
				ammo_category = "125x",
				modifier = 0.0125+0.01*(i-1)/2
			  },
			},
			prerequisites = {"gun-damage-upgrade-"..i-1},
			unit =
			{
			  count = i,
			  ingredients =
			  {
				{"science-pack-1", i*2},
				{"enemy-dna", i^2},
			  },
			  time = 5
			},
			upgrade = "true",
			order = "1-a"..i
	}})
end

data:extend({{
	type = "technology",
	name = "energy-damage-upgrade-1",
	icon = "__hardcorio__/graphics/technology/energy-damage-upgr.png",
	icon_size = 64,
	effects =
	{
     {
			type = "ammo-damage",
			ammo_category = "ps40",
			modifier = 0.0125
		},
		{
			type = "ammo-damage",
			ammo_category = "ps2000",
			modifier = 0.0125
		},
		{
			type = "ammo-damage",
			ammo_category = "ps200",
			modifier = 0.0125
		},
		{	
			type = "ammo-damage",
			ammo_category = "ps4000",
			modifier = 0.0125
		},	
		{
			type = "ammo-damage",
			ammo_category = "ps3200",
			modifier = 0.0125
		},
		{
			type = "ammo-damage",
			ammo_category = "ps160",
			modifier = 0.0125
		},
		{
			type = "ammo-damage",
			ammo_category = "laser-turret",
			modifier = 0.0125
		},
		{
			type = "ammo-damage",
			ammo_category = "tank-rockets",
			modifier = 0.0125
		},
	},
	prerequisites = {"nuclear-power"},
	unit =
	{
		count = 1,
		ingredients =
		{
			{"science-pack-1", 2},
			{"enemy-dna", 1},
			{"elerium", 3},
		},
	  time = 5
	},
	upgrade = "true",
	order = "1-a-1"
}})

for i = 2,100 do
	data:extend({{
		type = "technology",
		name = "energy-damage-upgrade-"..i,
		icon = "__hardcorio__/graphics/technology/energy-damage-upgr.png",
		icon_size = 64,
		effects =
		{
		{
			type = "ammo-damage",
			ammo_category = "ps40",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{
			type = "ammo-damage",
			ammo_category = "ps2000",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{
			type = "ammo-damage",
			ammo_category = "ps200",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{	
			type = "ammo-damage",
			ammo_category = "ps4000",
			modifier = 0.0125+0.01*(i-1)/2
		},	
		{
			type = "ammo-damage",
			ammo_category = "ps3200",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{
			type = "ammo-damage",
			ammo_category = "ps160",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{
			type = "ammo-damage",
			ammo_category = "laser-turret",
			modifier = 0.0125+0.01*(i-1)/2
		},
		{
			type = "ammo-damage",
			ammo_category = "tank-rockets",
			modifier = 0.0125+0.01*(i-1)/2
		},
		},
		prerequisites = {"energy-damage-upgrade-"..i-1},
		unit =
		{
		  count = i,
		  ingredients =
		  {
			{"science-pack-1", i*2},
			{"enemy-dna", i^2},
			{"elerium", i*3},
		  },
		  time = 5
		},
		upgrade = "true",
		order = "2-a"..i
	}})
end
for n = 1,3 do
	if n == 1 then name = "oxy" prerequisites_upgr = "steel-processing" 
	elseif n == 2 then name = "water" prerequisites_upgr = "plastics"
	elseif n == 3 then name = "food" prerequisites_upgr = "compressing"
	end
	data:extend({{
		type = "technology",
		name = name.."-upgr-1",
		icon = "__hardcorio__/graphics/technology/"..name.."-upgr.png",
		icon_size = 64,
		effects =
		{
		 
		},
		prerequisites = {prerequisites_upgr},
		unit =
		{
			count = 11*n,
			ingredients =
			{
				{"science-pack-1", 1},
			},
		  time = 2
		},
		upgrade = "true",
		order = "y-"..n.."-"..name.."-1"
	}})

	for i = 2,50 do
		if i <= 10 then ingredients_upgr = {{"science-pack-1", math.ceil(i/5)}}
		elseif i <= 20 then ingredients_upgr = {{"science-pack-1", math.ceil(i/5)},{"science-pack-2", math.floor(i/10)}}
		elseif i <= 50 then ingredients_upgr = {{"science-pack-1", math.ceil(i/5)},{"science-pack-2", math.floor(i/10)},{"science-pack-3", math.floor(i/20)}} end
		if i == 11 then prerequisites_upgr = {name.."-upgr-"..i-1, "chemistry"}
		elseif i == 21 then prerequisites_upgr = {name.."-upgr-"..i-1, "advanced-chemistry"}
		else prerequisites_upgr = {name.."-upgr-"..i-1} end
		data:extend({{
				type = "technology",
				name = name.."-upgr-"..i,
				icon = "__hardcorio__/graphics/technology/"..name.."-upgr.png",
				icon_size = 64,
				effects =
				{

				},
				prerequisites = prerequisites_upgr,
				unit =
				{
				  count = math.ceil(10*n*1.1^i),
				  ingredients = ingredients_upgr,
				  time = 2*i
				},
				upgrade = "true",
				order = "y-"..n.."-"..name.."-"..i
		}})
	end
end