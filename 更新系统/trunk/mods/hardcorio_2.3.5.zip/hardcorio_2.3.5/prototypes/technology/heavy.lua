data:extend(
{
{
    type = "technology",
    name = "heavy-basic",
    icon = "__hardcorio__/graphics/technology/heavy-basic.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "flamethrower"
	}
    },
	prerequisites = {"556x45-basic", "762x39-basic", "127x99-basic", "oil-processing"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-d-a"
},

{
    type = "technology",
    name = "heavy-basic-2",
    icon = "__hardcorio__/graphics/technology/heavy-basic.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-turret_missle"
    },
	{
        type = "unlock-recipe",
        recipe = "recipe-rpg"
	}
    },
	prerequisites = {"heavy-basic", "advanced-electronics"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-d-a"
},

{
    type = "technology",
    name = "heavy-ammo-1",
    localised_name = {"technology-name.heavy-ammo-1"},
    icon = "__hardcorio__/graphics/technology/heavy-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "flamethrower-ammo"
    },
    },
	prerequisites = {"heavy-basic"},
    unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
      },
      time = 10
    },
	upgrade = "true",
    order = "a-a-d-b-a"
},

{
    type = "technology",
    name = "heavy-ammo-2",
    localised_name = {"technology-name.heavy-ammo-2"},
    icon = "__hardcorio__/graphics/technology/heavy-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-105he"
    }
    },
	prerequisites = {"heavy-ammo-1", "heavy-basic-2", "explosives", "electrolize"},
    unit =
    {
      count = 40,
      ingredients =
      {
        {"science-pack-1", 2},
		{"science-pack-2", 1},
      },
      time = 20
    },
	upgrade = "true",
    order = "a-a-d-b-b"
},
{
    type = "technology",
    name = "heavy-ammo-3",
    localised_name = {"technology-name.heavy-ammo-3"},
    icon = "__hardcorio__/graphics/technology/heavy-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-105mg"
    },
    },
	prerequisites = {"heavy-ammo-2", "advanced-chemistry"},
    unit =
    {
      count = 80,
      ingredients =
      {
        {"science-pack-1", 3},
		{"science-pack-2", 2},
		{"science-pack-3", 1},
      },
      time = 40
    },
	upgrade = "true",
    order = "a-a-d-b-c"
},
{
    type = "technology",
    name = "heavy-ammo-4",
    localised_name = {"technology-name.heavy-ammo-4"},
    localised_description = {"technology-description.heavy-ammo-4"},
    icon = "__hardcorio__/graphics/technology/heavy-ammo.png",
	icon_size = 64,
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "recipe-105tbc"
    },
    },
	prerequisites = {"heavy-ammo-3", "high-tech-chemistry"},
    unit =
    {
      count = 160,
      ingredients =
      {
        {"science-pack-1", 4},
		{"science-pack-2", 3},
		{"science-pack-3", 2},
		{"high-tech-science-pack", 1},
      },
      time = 40
    },
	upgrade = "true",
    order = "a-a-d-b-d"
},

}
)
