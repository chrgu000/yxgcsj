data.raw["gui-style"].default["hardcorio_button_style"] =
    {
      type = "button_style",
      parent = "button",
	  top_padding = 0,
      right_padding = 0,
      bottom_padding = 0,
      left_padding = 0,
	  horizontal_spacing = 0,
      vertical_spacing = 0,
      left_click_sound =
      {
        {
          filename = "__core__/sound/gui-click.ogg",
          volume = 1
        }
      }
    }
	

data.raw["gui-style"].default["hardcorio_progressbar_oxy"] =
	 {
		type = "progressbar_style",
		parent = "progressbar",
		color = {r=1, g=1, b=1, a=1}
	}
data.raw["gui-style"].default["hardcorio_progressbar_water"] =
	 {
		type = "progressbar_style",
		parent = "progressbar",
		color = {r=0, g=0.4, b=0.8, a=1}
	}
data.raw["gui-style"].default["hardcorio_progressbar_food"] =
	 {
		type = "progressbar_style",
		parent = "progressbar",
		color = {r=0.7, g=0.4, b=0.2, a=1}
	}
data.raw["gui-style"].default["hardcorio_progressbar_weapon"] =
	 {
		type = "progressbar_style",
		parent = "progressbar",
		color = {r=1, g=1, b=0, a=1}
	}

	
data:extend({
{
	type = "font",
	name = "hardcorio_font",
	from = "default-bold",
	size = 10
},
{
	type = "font",
	name = "hardcorio_font_weapon",
	from = "default-bold",
	size = 9
},
})

data.raw["gui-style"].default["hardcorio_label"] =
	 {
      type = "label_style",
      font = "hardcorio_font",
      font_color = {r=1, g=1, b=1, a=0.7}
    }
	
data.raw["gui-style"].default["hardcorio_label_weapon"] =
	 {
      type = "label_style",
      font = "hardcorio_font_weapon",
      font_color = {r=1, g=1, b=1, a=0.7}
    }