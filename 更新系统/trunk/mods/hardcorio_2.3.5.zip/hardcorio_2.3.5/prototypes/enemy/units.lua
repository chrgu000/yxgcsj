local unit_get_run = nil
local collision_size = nil
local selection_size = nil
local sticker_size = nil
local unit_get_shooting_cursor_size = nil
local unit_get_attack_parameters = nil
local unit_get_movement_speed = nil
local unit_get_distance_per_frame = nil
local unit_get_dying_sound = nil
local unit_get_vision_distance  = nil
local unit_get_resistances = nil
local unit_get_dying_explosion = nil
local unit_get_collision_mask = nil

local function defiler_attack()
  return
    {
      category = "biological",
      target_type = "direction",
      action =
        {
          type = "direct",
          action_delivery =
          {
			{
			  type = "projectile",
			  projectile = "defiler-atk",
			  starting_speed = 0.1,
			  max_range = 0.2,
			},
          },
        },

    }
end

local function units_data_extend_stats(name,i)
	if name == "zrlg" then
		unit_get_run = {width = 66, height = 66, frame_count = 9, axially_symmetrical = false, direction_count = 16,scale = 1, stripes = {{filename = "__hardcorio__/graphics/entity/units/zerling/zerling-run_01.png", width_in_frames = 9, height_in_frames = 16}}}
		unit_get_attack = {filename = "__hardcorio__/graphics/entity/units/zerling/zerling-attack_01.png", width = 66, height = 66, frame_count = 10, direction_count = 16, scale = 1, axially_symmetrical = false}
		collision_size = {{-0.3, -0.3}, {0.3, 0.3}}
		selection_size = {{-0.3, -0.3}, {0.3, 0.3}}
		sticker_size = {{-0.2, -0.3}, {0.2, 0.1}}
		unit_get_shooting_cursor_size = 1
		unit_get_attack_parameters = { type = "projectile", range = 1.5, cooldown = 25, ammo_type = make_unit_claw_ammo_type(5.5+0.5*i), sound = {filename = "__hardcorio__/sound/enemies/zerling-atk.wav", volume = 0.5}, animation = unit_get_attack}
		unit_get_movement_speed = 0.1+0.04*i
		unit_get_distance_per_frame = 0.22
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/zerling-dth.wav", volume = 0.5}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 19+1*i, }, { type = "fire", percent = -38-2*i, }, { type = "piercing", percent = 100, },  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-small"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "bnlg" then
		unit_get_run = {width = 48, height = 48, frame_count = 15, axially_symmetrical = false, direction_count = 16,scale = 1, stripes = {{filename = "__hardcorio__/graphics/entity/units/baneling/baneling-run_01.png", width_in_frames = 15, height_in_frames = 16}}}
		collision_size = {{-0.3, -0.3}, {0.3, 0.3}}
		selection_size = {{-0.3, -0.3}, {0.3, 0.3}}
		sticker_size = {{-0.2, -0.3}, {0.3, 0.3}}
		unit_get_shooting_cursor_size = 1
		unit_get_attack_parameters = { type = "projectile", range = 0.1, cooldown = 100, ammo_type = {category = "biological", target_type = "direction", action = { type = "direct", action_delivery ={{type = "projectile",projectile = "baneling-boom", starting_speed = 0.01, max_range = 0.01}}}},sound = {filename = "__hardcorio__/sound/enemies/baneling-atk.wav", volume = 1}, animation = unit_get_run}
		unit_get_movement_speed = 0.05+0.05*i
		unit_get_distance_per_frame = 0.17
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/baneling-dth.wav", volume = 0.5}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95}, { type = "claw", percent = 90}, { type = "physical", percent = -39-1*i}, { type = "fire", percent = -19-1*i}, { type = "piercing", percent = 100},  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-small"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "scrg" then
		unit_get_run = {layers={{filename = "__hardcorio__/graphics/entity/units/defiler/defiler-run.png",width = 69,height = 59,frame_count = 8,axially_symmetrical = false,direction_count = 16,scale = 0.7,shift = { -0.08, -0.1 }},{filename = "__hardcorio__/graphics/entity/units/defiler/defiler-run-mask.png",width = 69,height = 59,frame_count = 8,axially_symmetrical = false,direction_count = 16,scale = 0.7,tint = {r=0, g=0.99-0.039*i^2, b=0.039*i^2, a=0.7},shift = { -0.08, -0.1 }}}}
		unit_get_attack = unit_get_run
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.4, -0.4}, {0.4, 0.4}}
		sticker_size = {{-0.2, -0.3}, {0.2, 0.2}}
		unit_get_shooting_cursor_size = 2
		unit_get_attack_parameters = { type = "projectile", range = 0.1,cooldown = 100,ammo_type ={category = "biological",target_type = "direction",action ={type = "direct",action_delivery ={{type = "projectile",projectile = "scourge-boom",starting_speed = 0.01,max_range = 0.01}}}},sound ={filename = "__hardcorio__/sound/enemies/baneling-atk.wav",volume = 0.5},animation = unit_get_attack}
		unit_get_movement_speed = 0.09+0.05*i
		unit_get_distance_per_frame = 0.17
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/baneling-dth.wav", volume = 0.3}
		unit_get_vision_distance  = 48+2*i
		unit_get_resistances = {{ type = "acid", percent = 100 }, { type = "claw", percent = 90, }}
		unit_get_dying_explosion = "blood-explosion-small"
		unit_get_collision_mask = {"floor-layer"}
	elseif name == "sclg" then
		unit_get_run = biterrunanimation(smallbiterscale, small_biter_tint1, {r=0, g=0.99-0.039*i^2, b=i*0.01, a=0.7})
		unit_get_attack = biterattackanimation(smallbiterscale, small_biter_tint1, {r=0, g=0.99-0.039*i^2, b=0.039*i^2, a=0.7})
		collision_size = {{-0.3, -0.3}, {0.3, 0.3}}
		selection_size = {{-0.3, -0.3}, {0.3, 0.3}}
		sticker_size = {{-0.3, -0.4}, {0.3, 0.1}}
		unit_get_shooting_cursor_size = 1.5
		unit_get_attack_parameters = { type = "projectile", range = 1.5, cooldown = 30, ammo_type = make_unit_claw_ammo_type(3.5+0.5*i), sound = {filename = "__hardcorio__/sound/enemies/zerling-atk.wav", volume = 0.5}, animation = unit_get_attack}
		unit_get_movement_speed = 0.09+0.04*i
		unit_get_distance_per_frame = 0.1
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/zerling-dth.wav", volume = 0.5}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 65+5*i, }, { type = "fire", percent = -39-1*i, }, { type = "piercing", percent = -19-1*i, },  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-small"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "hdsk" then
		unit_get_run = {width = 64, height = 64, frame_count = 13, axially_symmetrical = false, direction_count = 16,scale = 1.3, stripes = {{filename = "__hardcorio__/graphics/entity/units/hydralisk/hydralisk-run_01.png", width_in_frames = 13, height_in_frames = 16}}}
		unit_get_attack = {width = 64, height = 64, frame_count = 19, axially_symmetrical = false, direction_count = 16, animation_speed = 0.5, scale = 1.3, stripes = {{filename = "__hardcorio__/graphics/entity/units/hydralisk/hydralisk-attack_01.png", width_in_frames = 19, height_in_frames = 16}}}
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.4, -0.4}, {0.4, 0.4}}
		sticker_size = {{-0.3, -0.6}, {0.3, 0.1}}
		unit_get_shooting_cursor_size = 1.5
		unit_get_attack_parameters = { type = "projectile", range = 13+1*i, cooldown = 70, warmup = 10, ammo_type = {category = "biological", target_type = "direction", action = {type = "direct", action_delivery = {type = "projectile", projectile = "hydralisk-atk", starting_speed = 1.5}}},sound = {filename = "__hardcorio__/sound/enemies/hydralisk-atk.wav", volume = 0.7}, animation = unit_get_attack}
		unit_get_movement_speed = 0.07+0.04*i
		unit_get_distance_per_frame = 0.17
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/hydralisk-dth.wav", volume = 0.6}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 29+1*i, }, { type = "fire", percent = -19-1*i, }, { type = "piercing", percent = 80, },  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "roch" then
		unit_get_run = {width = 64, height = 64, frame_count = 11, axially_symmetrical = false, direction_count = 16, scale = 1.25, shift = {0, -0.05}, stripes = {{filename = "__hardcorio__/graphics/entity/units/roach/roach-run_01.png", width_in_frames = 11, height_in_frames = 16}}}
		unit_get_attack = {width = 64,height = 64,frame_count = 10,axially_symmetrical = false,direction_count = 16,animation_speed = 0.5,scale = 1.25, shift = {0, -0.05},stripes ={{filename = "__hardcorio__/graphics/entity/units/roach/roach-attack_01.png",width_in_frames = 10,height_in_frames = 16}}}
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.4, -0.4}, {0.4, 0.4}}
		sticker_size = {{-0.35, -0.35}, {0.35, 0.35}}
		unit_get_shooting_cursor_size = 2
		unit_get_attack_parameters = { type = "projectile", range = 10,projectile_creation_distance = 2.5,cooldown = 90,warmup = 30,ammo_type ={category = "biological",target_type = "direction",action ={type = "direct",action_delivery ={type = "projectile",projectile = "devourer-acid"..i,starting_speed = 1,max_range = 14}}},sound ={filename = "__hardcorio__/sound/enemies/devourer-atk.wav",volume = 0.7},animation = unit_get_attack}
		unit_get_movement_speed = 0.04+0.032*i
		unit_get_distance_per_frame = 0.15
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/hydralisk-dth.wav", volume = 0.5}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 59+1*i}, { type = "fire", percent = -19-1*i}, { type = "piercing", -28-2*i},  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "lrkr" then
		unit_get_run = {width = 64,height = 64,frame_count = 21,axially_symmetrical = false,direction_count = 16,scale = 1.25,stripes ={{filename = "__hardcorio__/graphics/entity/units/lurker/lurker-run_01.png",width_in_frames = 21,height_in_frames = 16}}}
		unit_get_attack = {width = 64,height = 64,frame_count = 12+16,axially_symmetrical = false,direction_count = 16,animation_speed = 0.26,scale = 1.25,stripes ={{filename = "__hardcorio__/graphics/entity/units/lurker/lurker-attack_01.png",width_in_frames = 12,height_in_frames = 16,},{filename = "__hardcorio__/graphics/entity/units/lurker/lurker-attack_02.png",width_in_frames = 16,height_in_frames = 16}}}
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.4, -0.4}, {0.4, 0.4}}
		sticker_size = {{-0.35, -0.35}, {0.35, 0.35}}
		unit_get_shooting_cursor_size = 1.7
		unit_get_attack_parameters = 
		{ 
		  type = "projectile",
		  ammo_category = "biological",
		  cooldown = 40,
		  range = 13.5+0.5*i,
		  warmup = 35,
		  ammo_type =
		  {
		    category = "biological",
			action =
			{
			  type = "direct",
			  action_delivery =
			  {
			    type = "instant",
				target_effects =
				{
				  {
				    type = "nested-result",
					action =
					{
					  {
					    type = "area",
						radius = 3.5,
						entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
						collision_mask = {"player-layer", "floor-layer"},
						action_delivery = 
						{
						  type = "instant",
						  target_effects =
						  {
						    {
							  type = "damage",
							  damage = { amount = 5, type = "claw" }
							}
						  }
						}
					  },
					  {
					    type = "area",
						radius = 1.5,
						entity_flags = {"player-creation"},
						collision_mask = {"player-layer", "floor-layer"},
						action_delivery =
						{
						  type = "instant",
						  target_effects =
						  {
						    type = "damage",
							damage = { amount = 10, type = "claw" }
						  }
						}
					  }
					}
				  },
				  {
				    type = "damage",
					damage = {amount = 10, type = "explosion"},
				  },
				  {
				    type = "create-entity",
					entity_name = "spike" 
				  }
				}
			  }
			}
		  },
		  sound ={filename = "__hardcorio__/sound/enemies/lurker-atk.wav",volume = 0.6},
		  animation = unit_get_attack
		}
		unit_get_movement_speed = 0.08+0.04*i
		unit_get_distance_per_frame = 0.15
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/lurker-dth.wav", volume = 0.8}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 28+2*i}, { type = "fire", percent = 28+2*i}, { type = "piercing", percent = -28-2*i},  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "dvur" then
		unit_get_run = spitterrunanimation(1,{r=0, g=0.99-0.039*i^2, b=0.039*i^2, a=0.7})
		unit_get_attack = spitterattackanimation(1,{r=0, g=0.99-0.039*i^2, b=0.039*i^2, a=0.7})
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.5, -0.5}, {0.5, 0.5}}
		sticker_size = {{-0.4, -0.7}, {0.4, 0.2}}
		unit_get_shooting_cursor_size = 2
		unit_get_attack_parameters = { type = "projectile", range = 14,projectile_creation_distance = 2.5,cooldown = 50,warmup = 30,ammo_type ={category = "biological",target_type = "direction",action ={type = "direct",action_delivery ={type = "projectile",projectile = "devourer-acid"..i,starting_speed = 1.5,max_range = 14}}},sound ={filename = "__hardcorio__/sound/enemies/devourer-atk.wav",volume = 0.7},animation = unit_get_attack}
		unit_get_movement_speed = 0.07+0.04*i
		unit_get_distance_per_frame = 0.1
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/devourer-dth.wav", volume = 0.7}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 29+1*i, }, { type = "fire", percent = -19-1*i, }, { type = "piercing", percent = 80, },  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "utsk" then
		unit_get_run = {width = 96,height = 96,frame_count = 16,axially_symmetrical = false,direction_count = 16,scale = 1.7,stripes ={{filename = "__hardcorio__/graphics/entity/units/ultralisk/ultralisk-run_01.png",width_in_frames = 16,height_in_frames = 16}}}
		unit_get_attack = {filename = "__hardcorio__/graphics/entity/units/ultralisk/ultralisk-attack_01.png",width = 96,height = 96,frame_count = 16,axially_symmetrical = false,direction_count = 16,animation_speed = 0.15,scale = 1.7}
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.6, -0.6}, {0.6, 0.6}}
		sticker_size = {{-0.5, -0.5}, {0.5, 0.5}}
		unit_get_shooting_cursor_size = 2
		unit_get_attack_parameters = { type = "projectile", range = 1.5, cooldown = 50, ammo_type = make_unit_claw_ammo_type(28+2*i), sound = {filename = "__hardcorio__/sound/enemies/ultralisk-atk.wav", volume = 0.7}, animation = unit_get_attack}
		unit_get_movement_speed = 0.04+0.032*i
		unit_get_distance_per_frame = 0.15
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/ultralisk-dth.wav", volume = 0.8}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = 65+5*i}, { type = "fire", percent = 49+1*i}, { type = "piercing", percent = -300},  { type = "explosion", decrease = -2}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"player-layer"}
	elseif name == "dflr" then
		unit_get_run = {width = 64,height = 64,frame_count = 14,axially_symmetrical = false,direction_count = 16,scale = 1.25,shift = { -0.08, -0.1 },animation_speed = 0.26,stripes ={{filename = "__hardcorio__/graphics/entity/units/defiler/defiler-run_01.png",width_in_frames = 14,height_in_frames = 16}}}
		unit_get_attack = unit_get_run
		collision_size = {{-0.4, -0.4}, {0.4, 0.4}}
		selection_size = {{-0.7, -0.7}, {0.7, 0.7}}
		sticker_size = {{-0.3, -0.5}, {0.3, 0.1}}
		unit_get_shooting_cursor_size = 2
		unit_get_attack_parameters = { type = "projectile", range = 19.5+0.5*i,cooldown = 160-20*i,ammo_category = "melee",ammo_type = defiler_attack(),animation = unit_get_attack}
		unit_get_movement_speed = 0.07+0.022*i
		unit_get_distance_per_frame = 0.17
		unit_get_dying_sound = {filename = "__hardcorio__/sound/enemies/defiler-dth.wav", volume = 0.8}
		unit_get_vision_distance  = 29+i
		unit_get_resistances = {{ type = "acid", percent = 95 }, { type = "claw", percent = 90, }, { type = "physical", percent = -28-2*i}, { type = "fire", percent = 45+5*i}, { type = "piercing", percent = 40},  { type = "explosion", percent = -200}}
		unit_get_dying_explosion = "blood-explosion-big"
		unit_get_collision_mask = {"floor-layer"}
	end
end

local function buildings_data_extend(name,hp)
	for i = 1,5 do
		units_data_extend_stats(name,i)
		data:extend({
		{
			type = "unit",
			name = name..i,
			icon = "__hardcorio__/graphics/entity/units/icons/"..name..".png",
			icon_size = 32,
			flags = {"placeable-enemy", "placeable-off-grid", "breaths-air"},
			max_health = hp*i*2,
			order = "x".."name"..i,
			subgroup="enemies",
			shooting_cursor_size = unit_get_shooting_cursor_size,
			resistances = unit_get_resistances,
			healing_per_tick = (hp*i*2)/(3600),
			collision_mask = unit_get_collision_mask,
			collision_box = collision_size,
			selection_box = selection_size,
			sticker_box = sticker_size,
			attack_parameters = unit_get_attack_parameters,
			vision_distance = unit_get_vision_distance,
			movement_speed = unit_get_movement_speed,
			distance_per_frame = unit_get_distance_per_frame,
			pollution_to_join_attack = 0,
			distraction_cooldown = 20,
			dying_explosion = unit_get_dying_explosion,
			dying_sound = unit_get_dying_sound,
			run_animation = unit_get_run,
		  },
		})
	end
end

for n = 1,10 do
	if n == 1 then
		buildings_data_extend("zrlg",20)
	elseif n == 2 then
		buildings_data_extend("bnlg",15)
	elseif n == 3 then
		buildings_data_extend("scrg",5)
	elseif n == 4 then
		buildings_data_extend("sclg",35)
	elseif n == 5 then
		buildings_data_extend("hdsk",75)
	elseif n == 6 then
		buildings_data_extend("roch",125)
	elseif n == 7 then
		buildings_data_extend("lrkr",125)
	elseif n == 8 then
		buildings_data_extend("dvur",285)
	elseif n == 9 then
		buildings_data_extend("utsk",357)
	elseif n == 10 then
		buildings_data_extend("dflr",100)
	end
end