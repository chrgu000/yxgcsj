local function buildings_data_extend_stats(name,i)
	if name == "po0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/pool-idle.png", width = 768 / 6, height = 136, scale = 1, shift = { 0, -0.8 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/pool-idle-mask.png", width = 768 / 6, height = 136, scale = 1, shift = { 0, -0.8 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-1.4, -1}, {1.4, 1}}
	elseif name == "nu0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/nursery-idle.png", width = 600 / 5, height = 96, scale = 1, shift = { 0.4, -0.3 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/nursery-idle-mask.png", width = 600 / 5, height = 96, scale = 1, shift = { 0.4, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-1.2, -1}, {1.2, 1}}
	elseif name == "de0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/den-idle.png", width = 600 / 5, height = 104, scale = 1, shift = { 0, -0.3 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/den-idle-mask.png", width = 600 / 5, height = 104, scale = 1, shift = { 0, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-1.4, -1}, {1.4, 1}}
	elseif name == "mo0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/mound-idle.png", width = 600 / 5, height = 96, scale = 1, shift = { 0, -0.3 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/mound-idle-mask.png", width = 600 / 5, height = 96, scale = 1, shift = { 0, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-1.7, -1}, {1.7, 1}}
	elseif name == "ca0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/cavern-idle.png", width = 600 / 5, height = 104, scale = 1.5, shift = { 0, -0.3 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/cavern-idle-mask.png", width = 600 / 5, height = 104, scale = 1.5, shift = { 0, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-2.1, -1.5}, {2.1, 1.5}}
	elseif name == "ch0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/chamber-idle.png", width = 600 / 5, height = 96, scale = 1.5, shift = { 0, -0.3 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/chamber-idle-mask.png", width = 600 / 5, height = 96, scale = 1.5, shift = { 0, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-2.1, -1.5}, {2.1, 1.5}}
	elseif name == "sp0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/spire-idle.png", width = 600 / 5, height = 104, scale = 1.5, shift = { -0.1, -1 }, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/spire-idle-mask.png", width = 600 / 5, height = 104, scale = 1.5, shift = { -0.1, -1 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 5, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-1.4, -1}, {1.4, 1}}
	elseif name == "ne0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/nest-idle.png", width = 144, height = 136, scale = 2, shift = { -0.3, -1.5 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/nest-idle-mask.png", width = 144, height = 136, scale = 2, shift = { -0.3, -1.5 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-2.9, -1.7}, {2.8, 2}}
	elseif name == "la0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/lair-idle.png", width = 144, height = 136, scale = 2, shift = { -0.8, -1.5 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/lair-idle-mask.png", width = 144, height = 136, scale = 2, shift = { -0.8, -1.5 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-3, -2.3}, {2.8, 2.3}}
	elseif name == "hi0" then
		spawner_get_animation = { layers = {
			{filename = "__hardcorio__/graphics/entity/enemy-base/hive-idle.png", width = 144, height = 136, scale = 2, shift = { -0.3, -1.5 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
			{filename = "__hardcorio__/graphics/entity/enemy-base/hive-idle-mask.png", width = 144, height = 136, scale = 2, shift = { -0.3, -1.5 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
		spawner_get_size = {{-3, -2.3}, {2.8, 2.3}}
	end
end

local function buildings_data_extend(name,hp,help_radius,lcmn,lcmx,prab)
  for i = 1,21 do
    buildings_data_extend_stats(name,i)
    data:extend({
    {
      type = "turret",
      name = name..i,
      icon = "__hardcorio__/graphics/entity/enemy-base/icons/"..name..".png",
      icon_size = 32,
      flags = {"placeable-enemy", "placeable-off-grid"},
      subgroup = "enemies",
      order = "z"..name..i,
      max_health = hp+hp*0.45*(i-1),
      collision_box = spawner_get_size,
      selection_box = spawner_get_size,
      shooting_cursor_size = 0,
      resistances = {{ type = "acid", percent = 90 },{ type = "claw", percent = 90 },{ type = "physical", percent = 16.25+3.75*i },{ type = "fire", percent = 16.25+3.75*i},{ type = "piercing", percent = 100 },{ type = "explosion", decrease = -9.9-3.1*i}},
      dying_explosion = "blood-explosion-huge",
      loot = {{count_min = lcmn,count_max = lcmx,item = "alien-artifact",probability = prab}},
      folded_speed = 0.015,
      folded_animation = spawner_get_animation,
      prepared_speed = 0.015,
      prepared_animation = spawner_get_animation,
      attack_parameters =
      {
        type = "projectile",
        range = 100,
        cooldown = 3600,
        ammo_category = "biological",
        ammo_type =
        {
          category = "biological",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "instant",
              source_effects =
              {
                  type = "create-entity",
                  entity_name = "base-check",
                  trigger_created_entity="true"
              }
            }
          }
        }
      },
      call_for_help_radius = help_radius
    }
    })
  end
end

for n = 1,10 do
	if n == 1 then
		buildings_data_extend("po0",1500,40,1,1,0.3)
	elseif n == 2 then
		buildings_data_extend("nu0",1500,40,1,1,0.3)
	elseif n == 3 then
		buildings_data_extend("de0",2000,40,1,1,0.5)
	elseif n == 4 then
		buildings_data_extend("mo0",2000,40,1,1,0.5)
	elseif n == 5 then
		buildings_data_extend("ch0",2500,40,1,1,0.7)
	elseif n == 6 then
		buildings_data_extend("ca0",2500,40,1,1,0.7)
	elseif n == 7 then
		buildings_data_extend("sp0",2500,40,1,1,0.7)
	elseif n == 8 then
		buildings_data_extend("ne0",5000,80,1,3,1)
	elseif n == 9 then
		buildings_data_extend("la0",10000,80,2,6,1)
	elseif n == 10 then
		buildings_data_extend("hi0",15000,80,3,9,1)
	end
end