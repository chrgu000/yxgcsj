data:extend(
{
  {
    type = "item",
    name = "eggs",
    icon = "__hardcorio__/graphics/entity/units/icons/eggs.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory", "hidden"},
    subgroup = "raw-material",
    order = "a",
    stack_size = 100
  },
  {
    type = "item",
    name = "alien-artifact",
    icon = "__hardcorio__/graphics/icons/items/alien-artifact.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "g[alien-artifact]",
    stack_size = 500,
    default_request_amount = 10
  }
})
