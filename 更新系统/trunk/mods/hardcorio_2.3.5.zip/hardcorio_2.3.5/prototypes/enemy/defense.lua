local function buildings_data_extend_stats(name,i)
  if name == "su0" then
    defense_get_iddle = { layers = {
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony-idle.png", width = 96, height = 80, scale = 1, shift = { -0.3, -0.3 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony-idle-mask.png", width = 96, height = 80, scale = 1, shift = { -0.3, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
    function defense_get_attack(run_mode) 
      return { layers = {
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony-attack.png", width = 96, height = 80, scale = 1, shift = { -0.3, -0.3 }, frame_count = 10, direction_count = 12, axially_symmetrical = false, run_mode = run_mode},
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony-attack-mask.png", width = 96, height = 80, scale = 1, shift = { -0.3, -0.3 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 10, direction_count = 12, axially_symmetrical = false, run_mode = run_mode}}}
	end
    defense_get_attack2 =
    {
      type = "projectile",
      ammo_category = "biological",
      cooldown = 1220-20*i,
      range = 29+ i,
      ammo_type =
      {
        category = "biological",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "instant",
            target_effects =
            {
              {
                type = "nested-result",
                action =
                {
                  {
                    type = "area",
                    radius = 3.5,
                    entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
					collision_mask = {"player-layer", "floor-layer"},
                    action_delivery =
                    {
                      type = "instant",
                      target_effects =
                      {
                        {
                          type = "damage",
                          damage = { amount = 10, type = "claw" }
                        }
                      }
                    }
                  },
                  {
                    type = "area",
                    radius = 1.5,
                    entity_flags = {"player-creation"},
					collision_mask = {"player-layer", "floor-layer"},
                    action_delivery =
                    {
                      type = "instant",
                      target_effects =
                      {
                        type = "damage",
                        damage = { amount = 10, type = "claw" }
                      }
                    }
                  }
                }
              },
              {
                type = "damage",
                damage = {amount = 10, type = "explosion"}
              },
              {
                type = "create-entity", entity_name = "spike" 
              }
            }
          }
        }
      }
    }
    defense_get_size = {{ -0.9, -0.7}, {0.9, 0.7}}
    defense_get_starting_attack_sound ={filename = "__hardcorio__/sound/enemies/sunken-atk.wav", volume = 0.6}
  elseif name == "co0" then
    defense_get_iddle = { layers = {
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony2-idle.png", width = 96, height = 80, scale = 1, shift = { -0.2, -0.2 }, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"},
      {filename = "__hardcorio__/graphics/entity/enemy-base/colony2-idle-mask.png", width = 96, height = 80, scale = 1, shift = { -0.2, -0.2 }, tint = {r=0, g=0.99-i*0.047, b=i*0.047, a=0.7}, frame_count = 6, direction_count = 1, axially_symmetrical = false, run_mode = "forward-then-backward"}}}
    defense_get_size = {{ -0.9, -0.9}, {0.9, 0.9}}
  end
end

local function buildings_data_extend(name,hp)
  for i = 1,21 do
    buildings_data_extend_stats(name,i)
	if name =="su0" then
	  data:extend({
	  {
	  type = "turret",
	  name = name..i,
	  icon = "__hardcorio__/graphics/entity/enemy-base/icons/"..name..".png",
      icon_size = 32,
	  flags = {"placeable-enemy", "placeable-off-grid"},
	  order = "z"..name..i,
	  max_health = hp+hp*0.45*(i-1),
	  subgroup = "enemies",
	  healing_per_tick = 0.9+0.1*i,
	  collision_box = defense_get_size,
	  selection_box = defense_get_size,
	  shooting_cursor_size = 0,
	  resistances = {{ type = "acid", percent = 90 },{ type = "claw", percent = 90 },{ type = "physical", percent = 18.2+1.8*i },{ type = "fire", percent = 18.2+1.8*i},{ type = "piercing", percent = 100 },{ type = "explosion", decrease = -18.75-6.25*i}},
	  rotation_speed = 1,
	  dying_explosion = "blood-explosion-huge",
	  folded_speed = 0.015,
	  folded_animation = defense_get_iddle,
	  prepared_speed = 0.015,
	  prepared_animation = defense_get_iddle,
	  starting_attack_speed = 0.015,
	  starting_attack_animation = defense_get_attack("forward"),
	  starting_attack_sound = defense_get_starting_attack_sound,
	  ending_attack_speed = 0.015,
	  ending_attack_animation = defense_get_attack("backward"),
	  attack_parameters = defense_get_attack2,
	  call_for_help_radius = 40
	  }
	  })
	else
	  data:extend({
	  {
	  type = "turret",
	  name = name..i,
	  icon = "__hardcorio__/graphics/entity/enemy-base/icons/"..name..".png",
      icon_size = 32,
	  flags = {"placeable-enemy", "placeable-off-grid"},
	  order = "z"..name..i,
	  max_health = hp+hp*0.45*(i-1),
	  subgroup = "enemies",
	  healing_per_tick = 0.9+0.1*i,
	  collision_box = defense_get_size,
	  selection_box = defense_get_size,
	  shooting_cursor_size = 0,
	  resistances = {{ type = "acid", percent = 90 },{ type = "claw", percent = 90 },{ type = "physical", percent = 18.2+1.8*i },{ type = "fire", percent = 18.2+1.8*i},{ type = "piercing", percent = 100 },{ type = "explosion", decrease = -9.9-3.1*i}},
	  dying_explosion = "blood-explosion-huge",
	  folded_speed = 0.015,
	  folded_animation = defense_get_iddle,
	  attack_parameters = {type = "projectile", range = 0, cooldown = 999, ammo_category = "biological"},
	  call_for_help_radius = 40
	  }
	  })
	end
  end
end

for n = 1,2 do
  if n == 1 then
    buildings_data_extend("su0",800)
  elseif n == 2 then
    buildings_data_extend("co0",1000)
  end
end