local function queen_run_animation(scale)
  return
  {
    layers=
    {
      {
	    
        width = 96,
        height = 96,
        frame_count = 16,
        axially_symmetrical = false,
        direction_count = 16,
        scale = scale,
		shift = { 0, 0 },
		animation_speed = 1,
        stripes =
        {
		  {
            filename = "__hardcorio__/graphics/entity/units/queen/queen-run_01.png",
            width_in_frames = 16,
            height_in_frames = 16,
          }
        }
      },
    }
  }
end

local function queen_attack_animation(scale)
  return
  {
    layers=
    {
      {
        width = 96,
        height = 96,
        frame_count = 18+17,
        axially_symmetrical = false,
        direction_count = 16,
		animation_speed = 0.4,
        scale = scale,
		shift = { 0, 0 },
        stripes =
        {
          {
            filename = "__hardcorio__/graphics/entity/units/queen/queen-attack_01.png",
            width_in_frames = 18,
            height_in_frames = 16,
          },
          {
            filename = "__hardcorio__/graphics/entity/units/queen/queen-attack_02.png",
            width_in_frames = 17,
            height_in_frames = 16,
          }
        }
      },
    }
  }
end

local function queen_die_animation(scale)
  return
  {
    layers=
    {
      {
        width = 96,
        height = 96,
        frame_count = 10,
        axially_symmetrical = false,
        direction_count = 16,
		animation_speed = 0.7,
        shift = {0, 0},
        scale = scale,
        stripes =
        {
          {
            filename = "__hardcorio__/graphics/entity/units/queen/queen-die_01.png",
            width_in_frames = 10,
            height_in_frames = 16,
          },

        }
      },

    }
  }
end

local function larva_egg_die_animation(scale)
  return
  {
    layers=
    {
      {
        width = 39,
        height = 30,
        frame_count = 1,
        axially_symmetrical = false,
        direction_count = 1,
		animation_speed = 0.7,
        shift = {0, 0},
        scale = scale,
        stripes =
        {
          {
            filename = "__hardcorio__/graphics/entity/units/larva/egg-die.png",
            width_in_frames = 1,
            height_in_frames = 1,
          },

        }
      },

    }
  }
end

function make_unit_claw_ammo_type(damagevalue)
  return
  {
    category = "melee",
    target_type = "entity",
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "damage",
          damage = { amount = damagevalue , type = "claw"}
        }
      }
    }
  }
end

data:extend({
  {
    type = "unit",
    name = "abomb",
    icon = "__hardcorio__/graphics/entity/units/icons/zrlg.png",
    icon_size = 32,
    flags = {"placeable-enemy", "placeable-off-grid", "breaths-air", "not-on-map"},
    max_health = 1,
    order = "x".."name",
    subgroup="enemies",
    shooting_cursor_size = 2,
    healing_per_tick = 0.01,
    collision_mask = {"floor-layer"},
    attack_parameters = { type = "projectile", range = 1.5, cooldown = 15, ammo_type = {category = "biological", target_type = "direction", action = { type = "direct", action_delivery ={{type = "projectile",projectile = "baneling-boom", starting_speed = 0.01, max_range = 0.01}}}},sound = {filename = "__hardcorio__/sound/enemies/baneling-atk.wav", volume = 1}, animation = {width = 16,height = 18,frame_count = 33,line_length = 5,axially_symmetrical = false,direction_count = 1,scale = 2,animation_speed = 0.26,filename = "__base__/graphics/entity/acid-projectile-purple/acid-projectile-purple.png",}},
    vision_distance = 30,
    movement_speed = 0.2,
    distance_per_frame = 0.1,
    pollution_to_join_attack = 0,
    distraction_cooldown = 20,
    dying_explosion = "blood-explosion-big",
    run_animation = {width = 16,height = 18,frame_count = 33,line_length = 5,axially_symmetrical = false,direction_count = 1,scale = 2,animation_speed = 0.26,filename = "__base__/graphics/entity/acid-projectile-purple/acid-projectile-purple.png",},
  },
  
  {
    type = "turret",
    name = "ex",
    icon = "__hardcorio__/graphics/icons/enemy/base.png",
    icon_size = 32,
    flags = {"placeable-enemy", "placeable-off-grid"},
    subgroup = "enemies",
    order="b-a",
    max_health = 15000,
    healing_per_tick = 0.1,
    collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
    selection_box = {{-0.3, -0.3}, {0.3, 0.3}},
    shooting_cursor_size = 0,
    dying_explosion = "blood-explosion-big",
    corpse = "egg-corpse",
    folded_speed = 0.015,
    folded_animation =
    {
      layers=
      {
        {
          filename = "__hardcorio__/graphics/entity/enemy-base/extractor-idle.png",
          width = 640 / 5,
          height = 120,
          frame_count = 5,
          direction_count = 1,
          axially_symmetrical = false,
          shift = { -0.3, -0.1 },
		  run_mode = "forward-then-backward"
        },
      }
    },
    attack_parameters = {type = "projectile", range = 0, cooldown = 999, ammo_category = "biological"},
    call_for_help_radius = 40
  },
  {
    type = "turret",
    name = "egg",
    icon = "__base__/graphics/icons/small-worm.png",
    icon_size = 32,
    flags = {"placeable-enemy", "placeable-off-grid", "breaths-air", "not-on-map"},
    subgroup = "enemies",
    order="b-a",
	minable = {mining_time = 5, result = nil},
    max_health = 100,
    healing_per_tick = 0.1,
    collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
    selection_box = {{-0.7, -0.5}, {0.5, 0.5}},
    shooting_cursor_size = 1,
    dying_explosion = "blood-explosion-big",
    corpse = "egg-corpse",
    folded_speed = 0.03,
    folded_animation =
    {
      layers=
      {
        {
          filename = "__hardcorio__/graphics/entity/units/larva/baneling-egg-idle_01.png",
          width = 48,
          height = 47,
          frame_count = 18,
          direction_count = 1,
          axially_symmetrical = false,
          shift = { 0, -0.1 },
          animation_speed = 0.1,
        }
      }
    },
    attack_parameters = {type = "projectile", range = 0, cooldown = 999, ammo_category = "biological"},
    call_for_help_radius = 0
  },
  
  {
    type = "corpse",
    name = "egg-corpse",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 32,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    flags = {"placeable-off-grid", "building-direction-8-way"},
    subgroup="corpses",
    order = "c[corpse]-a[biter]-b[medium]",
    dying_speed = 0.02,
    final_render_layer = "corpse",
    animation = larva_egg_die_animation(1)
  },
  
  {
    type = "unit",
    name = "queen",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 32,
    flags = {"placeable-enemy", "placeable-off-grid", "breaths-air", "not-on-map"},
    max_health = 3000,
    order = "queen",
    subgroup="enemies",
    shooting_cursor_size = 3,
    healing_per_tick = 0.02,
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.8, -0.8}, {0.8, 0.8}},
    sticker_box = {{-0.5, -0.6}, {0.5, 0.5}},
    attack_parameters = { type = "projectile", range = 3, cooldown = 40, ammo_type = make_unit_claw_ammo_type(30), sound = {filename = "__hardcorio__/sound/enemies/ultralisk-atk.wav", volume = 0.7}, animation = queen_attack_animation(2)},
    vision_distance = 30,
    movement_speed = 0.15,
    distance_per_frame = 0.25,
    pollution_to_join_attack = 1,
    distraction_cooldown = 10,
    dying_explosion = "blood-explosion-huge",
    dying_sound =
    {
        filename = "__hardcorio__/sound/enemies/broodling-dth.wav",
        volume = 0.7
    },
    run_animation = queen_run_animation(2),
    corpse = "queen-corpse",
  },
  
  {
    type = "corpse",
    name = "queen-corpse",
    icon = "__base__/graphics/icons/medium-biter-corpse.png",
    icon_size = 32,
    selectable_in_game = false,
    selection_box = {{-1, -1}, {1, 1}},
    flags = {"placeable-off-grid", "building-direction-8-way"},
    subgroup="corpses",
    order = "c[corpse]-a[biter]-b[medium]",
    dying_speed = 0.01,
    final_render_layer = "corpse",
    animation = queen_die_animation(2)
  },
  
  {
    type = "simple-entity",
	name = "check-place",
    collision_box = {{-6, -6}, {6, 6}},
    render_layer = "object",
    picture = { filename = "__core__/graphics/empty.png", width = 1, height = 1 }
  },
  {
    type = "simple-entity",
	name = "check-place2",
    collision_box = {{-10, -10}, {10, 10}},
    render_layer = "object",
    picture = { filename = "__core__/graphics/empty.png", width = 1, height = 1 }
  },

  {
    type = "explosion",
    name = "base-check",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__core__/graphics/empty.png",
        frame_count = 1,
        width = 1,
        height = 1
	  }
    }
  },

  {
    type = "explosion",
    name = "event-detonator",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__core__/graphics/empty.png",
        frame_count = 1,
        width = 1,
        height = 1
	  }
    }
  },

  {
    type = "explosion",
    name = "event-explosion-cancel",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__hardcorio__/graphics/entity/light-alarm.png",
        frame_count = 32,
        line_length = 16,
        width = 75,
        height = 75,
        priority = "high",
		shift = {0.1, 1.1},
        animation_speed = 1
	  }
    },
	sound = {{ filename = "__hardcorio__/sound/exp-cancel.wav", volume = 0.6 }}
  },

  {
    type = "explosion",
    name = "base-scream",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__core__/graphics/empty.png",
        frame_count = 1,
        width = 1,
        height = 1
	  }
    },
	sound =
    {
      { filename = "__hardcorio__/sound/enemies/base-1.wav", volume = 1 },
      { filename = "__hardcorio__/sound/enemies/base-2.wav", volume = 1 },
      { filename = "__hardcorio__/sound/enemies/base-3.wav", volume = 1 },
      { filename = "__hardcorio__/sound/enemies/base-4.wav", volume = 1 },
      { filename = "__hardcorio__/sound/enemies/base-5.wav", volume = 1 },
      { filename = "__hardcorio__/sound/enemies/base-6.wav", volume = 1 },
    },
    max_sounds_per_type = 1
  },
  
  {
    type = "explosion",
    name = "spike",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.1,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.2,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.3,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.4,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.5,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.6,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.7,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.8,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 1.9,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
	  {
        filename = "__hardcorio__/graphics/entity/enemy-base/spike.png",
        priority = "extra-high",
        width = 26,
        height = 36,
		scale = 2,
        frame_count = 11,
		shift = {0, 0.5},
        animation_speed = 0.27
      },
    },
	sound =
    {
      {
        filename = "__hardcorio__/sound/enemies/spike.wav",
        volume = 0.6
      }
    }
  },
  {
    type = "explosion",
    name = "acid-splash",
    flags = {"not-on-map"},
	animations =
    {
      {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.2,
		tint = {r=0, g=0.6, b=0, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.4,
		tint = {r=0.15, g=0.7, b=0, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.6,
		tint = {r=0.3, g=0.8, b=0, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 3.8,
		tint = {r=0.45, g=0.9, b=0, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 4,
		tint = {r=0.6, g=1, b=0, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 1,
      },
    },
  },
 
  
  {
    type = "projectile",
    name = "baneling-boom",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
		source_effects =
		{
			{
			type = "damage",
			damage = { amount = 1000, type = "self"}
			}
		}
      }
    },
    animation =
    {
      filename = "__core__/graphics/empty.png",
      frame_count = 1,
      width = 1,
      height = 1
    }
  },
  
  {
    type = "projectile",
    name = "defiler-atk",
    flags = {"not-on-map"},
    acceleration = 0.1,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "defiler-trigger",
            trigger_created_entity="true"
          },
        }
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/empty.png",
      frame_count = 1,
      width = 25,
      height = 25,
      priority = "high"
    },
  },

  {
    type = "explosion",
    name = "defiler-trigger",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__core__/graphics/empty.png",
        frame_count = 1,
        width = 1,
        height = 1,
	  }
    }
  },
  
  {
    type = "projectile",
    name = "scourge-boom",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
		source_effects =
		{
			{
			type = "damage",
			damage = { amount = 1000, type = "self"}
			}
		}
      }
    },
    animation =
    {
      filename = "__core__/graphics/empty.png",
      frame_count = 1,
      width = 1,
      height = 1,
    }
  },
  
  {
    type = "explosion",
    name = "acid-splash-scourge",
    flags = {"not-on-map"},
	animations =
    {
      {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 1.4,
		tint = {r=0, g=0.6, b=0.6, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 1.6,
		tint = {r=0, g=0.7, b=0.5, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 1.8,
		tint = {r=0.3, g=0.8, b=0.4, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 2,
		tint = {r=0, g=0.9, b=0.3, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 0.7,
      },
	  {
        filename = "__base__/graphics/entity/flamethrower-fire-stream/flamethrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
		scale = 2.2,
		tint = {r=0, g=1, b=0.2, a=1},
        frame_count = 64,
        line_length = 8,
		animation_speed = 1,
      },
    },
  },
  {
    type = "explosion",
    name = "devourer-acid-explosion",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/units/devourer/devourer-acid-explosion.png",
        priority = "extra-high",
        width = 128,
        height = 128,
        frame_count = 14,
        shift = {-0.1, 0.7 },
        animation_speed = 0.5
      }
    }
  },

  {
    type = "explosion",
    name = "devourer-trigger",
    flags = {"not-on-map"},
    animations =
	{
      {
        filename = "__core__/graphics/empty.png",
        frame_count = 1,
        width = 1,
        height = 1
	  }
    }
  },
  
  {
    type = "projectile",
    name = "hydralisk-atk",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "acid-explosion-small"
          },
          {
            type = "damage",
            damage = {amount = 20, type = "acid"}
          }
        }
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/units/hydralisk/hydralisk-pr.png",
      frame_count = 1,
      width = 21,
      height = 49,
      priority = "high"
    }
  },

  {
    type = "explosion",
    name = "acid-explosion-small",
    flags = {"not-on-map"},
    animations =
    {
      {
        filename = "__hardcorio__/graphics/entity/units/hydralisk/acid-explosion-small.png",
        priority = "extra-high",
        width = 31,
        height = 32,
        line_length = 8,
        frame_count = 8,
        animation_speed = 0.2
      }
    }
  },
})

for i = 1,5 do
data:extend({
  {
    type = "explosion",
    name = "baneling-boom-explosion"..i,
    flags = {"not-on-map"},
    acceleration = 0.005,
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "acid-explosion-huge"
          },
		  {
            type = "create-entity",
            entity_name = "acid-splash"
          },
          {
            type = "nested-result",
            action =
            {
				{
				type = "area",
				radius = 1,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 15+5*i, type = "acid" }}}},
				{
				type = "area",
				radius = 2,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 7.5+2.5*i, type = "acid" }}}},
				{
				type = "area",
				radius = 3,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 7.5+2.5*i, type = "acid" }}}},
				{
				type = "area",
				radius = 4,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 7.5+2.5*i, type = "acid" }}}},
				{
				type = "area",
				radius = 5,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}},
				{
				type = "area",
				radius = 6,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}}
            },
          }
        }
      }
    },
    light = {intensity = 0.5, size = 4},
    animations =
    {{
      filename = "__base__/graphics/entity/grenade/grenade-shadow.png",
      frame_count = 1,
      width = 1,
      height = 1,
      priority = "high"
    }}
  },
  
  {
    type = "explosion",
    name = "scourge-boom-explosion"..i,
    flags = {"not-on-map"},
    acceleration = 0.005,
    created_effect =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "blood-explosion-small"
          },
		  {
            type = "create-entity",
            entity_name = "acid-splash-scourge"
          },
          {
            type = "nested-result",
            action =
            {
				{
				type = "area",
				radius = 1,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}},
				{
				type = "area",
				radius = 2,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}},
				{
				type = "area",
				radius = 3,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
				action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}},
            },
          }
        }
      }
    },
    light = {intensity = 0.5, size = 4},
    animations =
    {{
      filename = "__base__/graphics/entity/grenade/grenade-shadow.png",
      frame_count = 1,
      width = 1,
      height = 1,
      priority = "high"
    }}
  },
  
  {
    type = "projectile",
    name = "devourer-acid"..i,
    flags = {"not-on-map"},
    collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
    acceleration = 0,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "devourer-trigger",
            trigger_created_entity="true"
          },
		  {
            type = "create-entity",
            entity_name = "devourer-acid-explosion"
          },
          {
            type = "nested-result",
            action =
            {
              {
                type = "area",
                radius = 1,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
                action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 2.5+2.5*i, type = "acid" }}}
              },
              {
                type = "area",
                radius = 2,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
                action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}
              },
              {
                type = "area",
                radius = 3,
                entity_flags = {"player-creation", "placeable-player", "placeable-neutral", "pushable"},
				collision_mask = {"player-layer", "floor-layer"},
                action_delivery = { type = "instant", target_effects = { type = "damage", damage = { amount = 3.75+1.25*i, type = "acid" }}}
              },
            },
          }
        }
      }
    },
    animation =
    {
      filename = "__hardcorio__/graphics/entity/units/devourer/devourer-acid.png",
      frame_count = 1,
      scale = 0.6,
      width = 35,
      height = 35,
      priority = "low"
    },
  },
		
})
end