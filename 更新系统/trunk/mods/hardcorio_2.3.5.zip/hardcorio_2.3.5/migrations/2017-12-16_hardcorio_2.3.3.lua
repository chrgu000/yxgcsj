for index, force in pairs(game.forces) do
  local technologies = force.technologies;
  local recipes = force.recipes;
  if technologies["logistics-3"].researched then
    recipes["express-underground-belt-2"].enabled = true
    recipes["express-underground-belt-3"].enabled = true
    recipes["fast-underground-belt-2"].enabled = true
    recipes["fast-underground-belt-3"].enabled = true
    recipes["underground-belt-2"].enabled = true
  elseif technologies["logistics-2"].researched then
    recipes["fast-underground-belt-2"].enabled = true
    recipes["fast-underground-belt-3"].enabled = true
    recipes["underground-belt-2"].enabled = true
  elseif technologies["logistics"].researched then
    recipes["underground-belt-2"].enabled = true
  end
  
  if technologies["rocket-speed-7"].researched then
    force.set_gun_speed_modifier("tank-rockets", 1.5)
    force.set_gun_speed_modifier("rocket", 0)
  elseif technologies["rocket-speed-6"].researched then
    force.set_gun_speed_modifier("tank-rockets", 1.25)
    force.set_gun_speed_modifier("rocket", 0)
  end
end
