for index, force in pairs(game.forces) do
  local technologies = force.technologies;
  local recipes = force.recipes;
  
  if technologies["support-tank"].researched then
    recipes["cutting-fish"].enabled = true
  end
  if technologies["fish-farm"].researched then
    recipes["cutting-small-fish"].enabled = true
    recipes["cutting-tiny-fish"].enabled = true
  end
end
