if data.raw.car["raven-1"] ~= nil then
	data.raw.car["raven-1"].minable.mining_time = 60
end

data.raw["locomotive"]["locomotive"].minable.mining_time = 20
data.raw["locomotive"]["locomotive"].resistances =
    {
	  { type = "physical", percent = 100 },
	  { type = "fire", percent = 100 },
	  { type = "piercing", percent = 100 },
      { type = "impact", decrease = 50, percent = 60},
      { type = "acid", percent = 20 },
	  { type = "claw", percent = 60 }
    }
data.raw["cargo-wagon"]["cargo-wagon"].minable.mining_time = 20
data.raw["cargo-wagon"]["cargo-wagon"].resistances =
    {
	  { type = "physical", percent = 100 },
	  { type = "fire", percent = 100 },
	  { type = "piercing", percent = 100 },
      { type = "impact", decrease = 50, percent = 60},
      { type = "acid", percent = 20 },
	  { type = "claw", percent = 60 }
    }

data.raw["underground-belt"]["underground-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["underground-belt"]["fast-underground-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["underground-belt"]["express-underground-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["splitter"]["splitter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["splitter"]["fast-splitter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["splitter"]["express-splitter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["transport-belt"]["transport-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["transport-belt"]["fast-transport-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["transport-belt"]["express-transport-belt"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["logistic-robot"]["logistic-robot"].collision_mask = {"not-colliding-with-itself"}
data.raw["logistic-robot"]["logistic-robot"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 }, { type = "acid", percent = 30 } }
data.raw["construction-robot"]["construction-robot"].collision_mask = {"not-colliding-with-itself"}
data.raw["construction-robot"]["construction-robot"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 }, { type = "acid", percent = 30 } }
data.raw["logistic-container"]["logistic-chest-passive-provider"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["logistic-container"]["logistic-chest-active-provider"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["logistic-container"]["logistic-chest-storage"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["logistic-container"]["logistic-chest-requester"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["electric-pole"]["big-electric-pole"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["electric-pole"]["medium-electric-pole"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["electric-pole"]["small-electric-pole"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["electric-pole"]["substation"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["ammo-turret"]["gun-turret"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["combat-robot"]["distractor"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["combat-robot"]["defender"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["combat-robot"]["destroyer"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["pipe"]["pipe"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["pipe-to-ground"]["pipe-to-ground"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["furnace"]["stone-furnace"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["boiler"]["boiler"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["generator"]["steam-engine"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["offshore-pump"]["offshore-pump"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["burner-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["lamp"]["small-lamp"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["assembling-machine"]["assembling-machine-1"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["assembling-machine"]["assembling-machine-2"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["assembling-machine"]["assembling-machine-3"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["car"]["car"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["container"]["iron-chest"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["container"]["steel-chest"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["long-handed-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["fast-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["stack-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["stack-filter-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["inserter"]["filter-inserter"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["solar-panel"]["solar-panel"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["pump"]["pump"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["train-stop"]["train-stop"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["rail-signal"]["rail-signal"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["roboport"]["roboport"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["storage-tank"]["storage-tank"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["accumulator"]["accumulator"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["wall"]["stone-wall"].repair_speed_modifier = 4
data.raw["wall"]["stone-wall"].resistances = { { type = "impact", decrease = 45, percent = 60 }, { type = "claw", percent = 60 }, { type = "acid", percent = 10 }, { type = "explosion", decrease = 10, percent = 30 }, { type = "fire", percent = 100 },{ type = "piercing", percent = 100 },{ type = "physical", percent = 100 } }
data.raw["gate"]["gate"].repair_speed_modifier = 3
data.raw["gate"]["gate"].resistances = { { type = "impact", decrease = 45, percent = 60 }, { type = "claw", percent = 60 }, { type = "acid", percent = 10 }, { type = "explosion", decrease = 10, percent = 30 }, { type = "fire", percent = 100 },{ type = "piercing", percent = 100 },{ type = "physical", percent = 100 } }
data.raw["straight-rail"]["straight-rail"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["curved-rail"]["curved-rail"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["mining-drill"]["burner-mining-drill"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["mining-drill"]["electric-mining-drill"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["lab"]["lab"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["container"]["wooden-chest"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["mining-drill"]["pumpjack"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["beacon"]["beacon"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["assembling-machine"]["oil-refinery"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["assembling-machine"]["chemical-plant"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["furnace"]["steel-furnace"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["furnace"]["electric-furnace"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["container"]["big-ship-wreck-1"].resistances = { { type = "fire", percent = 100 }, { type = "physical", percent = 100 },{ type = "piercing", percent = 100 } }
data.raw["radar"]["radar"].energy_per_sector = "5MJ"
data.raw["radar"]["radar"].energy_per_nearby_scan = "80kJ"
data.raw["radar"]["radar"].max_distance_of_nearby_sector_revealed = 2
data.raw["radar"]["radar"].energy_usage = "100kW"
data.raw["container"]["big-ship-wreck-1"].max_health = 1500
data.raw["lab"]["lab"].energy_usage = "100kW"
data.raw["lab"]["lab"].inputs =
    {
      "science-pack-1",
      "science-pack-2",
      "science-pack-3",
      "production-science-pack",
      "high-tech-science-pack",
      "space-science-pack"
    }
data.raw["player"]["player"].max_health = 10
data.raw["player"]["player"].running_speed = 0.45
data.raw["player"]["player"].distance_per_frame = 0.39
data.raw["player"]["player"].healing_per_tick = 1
data.raw["player"]["player"].inventory_size = 60
data.raw["player"]["player"].reach_distance = 0
data.raw["player"]["player"].reach_resource_distance = 0
data.raw["player"]["player"].crafting_categories = {"nothing-craft"}
data.raw["player"]["player"].mining_categories = {"nothing-mine"}
data.raw["player"]["player"].mining_speed = 0

data.raw["explosion"]["medium-explosion"].light = {intensity = 1, size = 15}

data.raw["fish"]["fish"].icon = "__hardcorio__/graphics/icons/items/fish.png"
data.raw["fish"]["fish"].minable = {mining_time = 1, result = "fish"}
data.raw["fish"]["fish"].flags = {"placeable-neutral", "not-on-map", "placeable-off-grid"}
data.raw["simple-entity"]["medium-ship-wreck"].minable = {mining_particle = "iron-ore-particle", mining_time = 6, result = nil}
data.raw["simple-entity"]["small-ship-wreck"].minable = {mining_particle = "iron-ore-particle", mining_time = 6, result = nil}
data.raw["decorative"]["big-ship-wreck-grass"].render_layer = "decorative"
data.raw["decorative"]["small-ship-wreck-grass"].render_layer = "decorative"


data.raw["pipe-to-ground"]["pipe-to-ground"].fluid_box.pipe_connections = {{ position = {0, -1} },{position = {0, 1},max_underground_distance = 20}}

data.raw["underground-belt"]["underground-belt"].max_distance = 5
data.raw["underground-belt"]["fast-underground-belt"].max_distance = 5
data.raw["underground-belt"]["express-underground-belt"].max_distance = 5

data.raw["solar-panel"]["solar-panel"].collision_box = {{ -0.9, -0.9}, {0.9, 0.9}}
data.raw["solar-panel"]["solar-panel"].selection_box = {{ -1, -1}, {1, 1}}
data.raw["solar-panel"]["solar-panel"].picture.layers[1].shift = util.by_pixel(-2, 2)
data.raw["solar-panel"]["solar-panel"].picture.layers[1].scale = 2/3
data.raw["solar-panel"]["solar-panel"].picture.layers[1].hr_version.shift = util.by_pixel(-1, 1.2)
data.raw["solar-panel"]["solar-panel"].picture.layers[1].hr_version.scale = 1/3
data.raw["solar-panel"]["solar-panel"].picture.layers[2].shift = util.by_pixel(6.7, 4)
data.raw["solar-panel"]["solar-panel"].picture.layers[2].scale = 2/3
data.raw["solar-panel"]["solar-panel"].picture.layers[2].hr_version.shift = util.by_pixel(3.2, 2)
data.raw["solar-panel"]["solar-panel"].picture.layers[2].hr_version.scale = 1/3
data.raw["solar-panel"]["solar-panel"].overlay.layers[1].shift = util.by_pixel(7.3, 4)
data.raw["solar-panel"]["solar-panel"].overlay.layers[1].scale = 2/3
data.raw["solar-panel"]["solar-panel"].overlay.layers[1].hr_version.shift = util.by_pixel(3.5, 2)
data.raw["solar-panel"]["solar-panel"].overlay.layers[1].hr_version.scale = 1/3
data.raw["solar-panel"]["solar-panel"].production = "30kW"

data.raw["artillery-wagon"]["artillery-wagon"].minable.mining_time = 20
data.raw["artillery-wagon"]["artillery-wagon"].resistances =
  {
    { type = "physical", percent = 100 },
    { type = "fire", percent = 100 },
    { type = "piercing", percent = 100 },
    { type = "impact", decrease = 50, percent = 60},
    { type = "explosion", decrease = 15, percent = 30 },
    { type = "acid", percent = 20 },
    { type = "claw", percent = 60 }
  }
data.raw["artillery-turret"]["artillery-turret"].minable.mining_time = 10
data.raw["artillery-turret"]["artillery-turret"].resistances =
  {
    { type = "physical", percent = 100 },
    { type = "fire", percent = 100 },
    { type = "piercing", percent = 100 },
    { type = "impact", decrease = 50, percent = 60},
    { type = "explosion", decrease = 15, percent = 30 },
    { type = "acid", percent = 20 },
    { type = "claw", percent = 60 }
  }
local check =
{
  type = "create-entity",
  entity_name = "base-check",
  trigger_created_entity="true"
}
table.insert(data.raw["artillery-projectile"]["artillery-projectile"].action.action_delivery.target_effects, check)

data.raw["map-settings"]["map-settings"].enemy_expansion.enabled = false
data.raw["map-settings"]["map-settings"].enemy_evolution = { enabled=true, time_factor = 0.000004, destroy_factor = 0, pollution_factor = 0.00001 }
data.raw["map-settings"]["map-settings"].pollution= { enabled=true, diffusion_ratio=0.04, min_to_diffuse=45, ageing=1, expected_max_per_chunk=7000, min_to_show_per_chunk=700, min_pollution_to_damage_trees = 3500, pollution_with_max_forest_damage = 10000, pollution_per_tree_damage = 2000, pollution_restored_per_tree_damage = 500, max_pollution_to_restore_trees = 1000 }