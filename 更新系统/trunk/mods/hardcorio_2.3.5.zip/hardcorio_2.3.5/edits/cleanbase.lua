data.raw["autoplace-control"]["enemy-base"] = nil

data.raw["unit-spawner"]["biter-spawner"] = nil
data.raw["unit-spawner"]["spitter-spawner"] = nil

data.raw["turret"]["small-worm-turret"] = nil
data.raw["turret"]["medium-worm-turret"] = nil
data.raw["turret"]["big-worm-turret"] = nil

data.raw["map-gen-presets"]["default"]["death-world"] = nil
data.raw["map-gen-presets"]["default"]["death-world-marathon"] = nil
data.raw["map-gen-presets"]["default"]["rail-world"].basic_settings.autoplace_controls["enemy-base"] = nil


data.raw["kill-achievement"]["steamrolled"] = nil

data.raw["ammo"]["shotgun-shell"].ammo_type.category = "bullet"
data.raw["ammo"]["piercing-shotgun-shell"].ammo_type.category = "bullet"

data.raw["electric-turret"]["laser-turret"].attack_parameters.ammo_type.category = "electric"