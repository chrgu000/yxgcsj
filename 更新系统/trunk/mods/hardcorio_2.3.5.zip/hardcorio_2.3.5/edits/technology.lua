data.raw["technology"]["landfill"].prerequisites = {"chemistry"}
data.raw["technology"]["toolbelt"].prerequisites = {"chemistry"}

data.raw["technology"]["flying"].prerequisites = {"advanced-electronics", "electric-engine", "battery"}
data.raw["technology"]["robotics"].prerequisites = {"advanced-electronics", "electric-engine", "battery"}
data.raw["technology"]["logistics"].prerequisites = {"electronics"}
data.raw["technology"]["logistics"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "underground-belt-2"
      },
      {
        type = "unlock-recipe",
        recipe = "splitter"
      },
      {
        type = "unlock-recipe",
        recipe = "inserter"
      },
      {
        type = "unlock-recipe",
        recipe = "long-handed-inserter"
      }
    }
data.raw["technology"]["logistics"].unit.time = 5
data.raw["technology"]["logistics-2"].prerequisites = {"logistics", "chemistry"}
data.raw["technology"]["logistics-2"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fast-transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-underground-belt-2"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-underground-belt-3"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-splitter"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-inserter"
      },
      {
        type = "unlock-recipe",
        recipe = "filter-inserter"
      }
    }
data.raw["technology"]["logistics-3"].prerequisites = {"logistics-2", "advanced-chemistry"}
data.raw["technology"]["logistics-3"].unit.ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      }
data.raw["technology"]["logistics-3"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "express-underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "express-underground-belt-2"
      },
      {
        type = "unlock-recipe",
        recipe = "express-underground-belt-3"
      },
      {
        type = "unlock-recipe",
        recipe = "express-splitter"
      },
      {
        type = "unlock-recipe",
        recipe = "stack-inserter"
      },
      {
        type = "unlock-recipe",
        recipe = "stack-filter-inserter"
      },
      {
        type = "stack-inserter-capacity-bonus",
        modifier = 3
      },
    }
data.raw["technology"]["braking-force-1"].prerequisites = {"railway", "advanced-chemistry"}
data.raw["technology"]["braking-force-3"].prerequisites = {"braking-force-2", "logistics-3", "production-chemistry"}
data.raw["technology"]["braking-force-6"].prerequisites = {"braking-force-5", "high-tech-chemistry"}
data.raw["technology"]["electronics"].prerequisites = {}
data.raw["technology"]["electronics"].unit =
    {
      count = 10,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 5
    }
data.raw["technology"]["electronics"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electronic-circuit"
      }
    }
data.raw["technology"]["circuit-network"].prerequisites = {"chemistry"}
data.raw["technology"]["advanced-electronics"].prerequisites = {"electronics", "plastics"}
data.raw["technology"]["advanced-electronics"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-circuit"
      }
    }
data.raw["technology"]["advanced-electronics-2"].prerequisites = {"advanced-electronics", "sulfur-processing", "advanced-chemistry"}
data.raw["technology"]["advanced-electronics-2"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "processing-unit"
      }
    }
data.raw["technology"]["automation"].prerequisites = {"electronics"}
data.raw["technology"]["automation"].unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 20
    }
data.raw["technology"]["automation"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "assembling-machine-1"
      },
      {
        type = "unlock-recipe",
        recipe = "electric-mining-drill"
      }
    }
data.raw["technology"]["automation-2"].prerequisites = {"automation"}
data.raw["technology"]["automation-3"].prerequisites = {"speed-module", "automation-2", "production-chemistry"}
data.raw["technology"]["advanced-material-processing"].prerequisites = {"steel-processing", "chemistry"}
data.raw["technology"]["advanced-material-processing-2"].prerequisites = {"advanced-material-processing", "advanced-chemistry"}
data.raw["technology"]["advanced-material-processing-2"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electric-furnace"
      }
    }
data.raw["technology"]["concrete"].prerequisites = {"advanced-material-processing", "automation-2"}
data.raw["technology"]["speed-module-2"].prerequisites = {"speed-module", "advanced-electronics-2", "advanced-chemistry"}
data.raw["technology"]["productivity-module-2"].prerequisites = {"productivity-module", "advanced-electronics-2", "advanced-chemistry"}
data.raw["technology"]["effectivity-module-2"].prerequisites = {"effectivity-module", "advanced-electronics-2", "advanced-chemistry"}
data.raw["technology"]["speed-module-3"].prerequisites = {"speed-module-2", "production-chemistry"}
data.raw["technology"]["speed-module-3"].unit.ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      }
data.raw["technology"]["effectivity-module-3"].prerequisites = {"effectivity-module-2", "production-chemistry"}
data.raw["technology"]["effectivity-module-3"].unit.ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      }
data.raw["technology"]["productivity-module-3"].prerequisites = {"productivity-module-2", "production-chemistry"}
data.raw["technology"]["engine"].prerequisites = {"automation-2", "steel-processing", "chemistry"}
data.raw["technology"]["electric-engine"].prerequisites = {"engine", "oil-processing"}
data.raw["technology"]["railway"].prerequisites = {"logistics-2", "engine"}
data.raw["technology"]["optics"].prerequisites = {"electronics"}
data.raw["technology"]["solar-energy"].prerequisites = {"optics", "chemistry", "steel-processing"}
data.raw["technology"]["effect-transmission"].prerequisites = {"modules", "high-tech-chemistry"}
data.raw["technology"]["electric-energy-distribution-1"].prerequisites = {"steel-processing", "chemistry"}
data.raw["technology"]["electric-energy-distribution-2"].prerequisites = {"electric-energy-distribution-1", "advanced-chemistry"}
data.raw["technology"]["research-speed-1"].prerequisites = {"laboratory", "chemistry"}
data.raw["technology"]["research-speed-3"].prerequisites = {"research-speed-2", "advanced-chemistry"}
data.raw["technology"]["research-speed-5"].prerequisites = {"research-speed-4", "production-chemistry"}
data.raw["technology"]["research-speed-6"].prerequisites = {"research-speed-5", "high-tech-chemistry"}
data.raw["technology"]["logistic-system"].prerequisites = {"logistic-robotics", "high-tech-chemistry"}
data.raw["technology"]["character-logistic-slots-3"].prerequisites = {"character-logistic-slots-2", "advanced-chemistry"}
data.raw["technology"]["character-logistic-slots-4"].prerequisites = {"character-logistic-slots-3", "production-chemistry"}
data.raw["technology"]["character-logistic-slots-6"].prerequisites = {"character-logistic-slots-5", "high-tech-chemistry"}
data.raw["technology"]["character-logistic-trash-slots-2"].prerequisites = {"character-logistic-trash-slots-1", "advanced-chemistry"}
data.raw["technology"]["worker-robots-speed-1"].prerequisites = {"logistic-robotics", "advanced-chemistry"}
data.raw["technology"]["worker-robots-speed-3"].prerequisites = {"worker-robots-speed-2", "production-chemistry"}
data.raw["technology"]["worker-robots-speed-5"].prerequisites = {"worker-robots-speed-4", "high-tech-chemistry"}
data.raw["technology"]["worker-robots-speed-6"].prerequisites = {"worker-robots-speed-5", "rocket-silo"}
data.raw["technology"]["worker-robots-storage-1"].prerequisites = {"logistic-robotics", "advanced-chemistry"}
data.raw["technology"]["worker-robots-storage-2"].prerequisites = {"worker-robots-storage-1", "production-chemistry"}
data.raw["technology"]["heavy-armor"].prerequisites = {"steel-processing"}
data.raw["technology"]["modular-armor"].prerequisites = {"heavy-armor", "advanced-electronics"}
data.raw["technology"]["power-armor"].prerequisites = {"modular-armor", "advanced-electronics-2", "electric-engine"}
data.raw["technology"]["power-armor-2"].prerequisites = {"power-armor", "speed-module-3", "effectivity-module-3", "high-tech-chemistry"}
data.raw["technology"]["energy-shield-mk2-equipment"].prerequisites = {"energy-shield-equipment", "advanced-chemistry"}
data.raw["technology"]["exoskeleton-equipment"].prerequisites = {"solar-panel-equipment", "advanced-chemistry"}
data.raw["technology"]["battery-mk2-equipment"].prerequisites = {"battery-equipment", "advanced-chemistry"}
data.raw["technology"]["solar-panel-equipment"].prerequisites = {"solar-energy", "modular-armor"}
data.raw["technology"]["fusion-reactor-equipment"].prerequisites = {"solar-panel-equipment", "nuclear-power", "high-tech-chemistry"}
data.raw["technology"]["personal-roboport-equipment"].prerequisites = {"construction-robotics", "solar-panel-equipment", "advanced-chemistry"}
data.raw["technology"]["personal-roboport-equipment-2"].prerequisites = {"personal-roboport-equipment", "high-tech-chemistry"}
data.raw["technology"]["combat-robotics"].prerequisites =  {"flying", "robotics", "556x45-ammo-2"}
data.raw["technology"]["combat-robotics"].effects = {{
        type = "unlock-recipe",
        recipe = "recipe-robot-556x45"
		}}
data.raw["technology"]["combat-robotics-2"].prerequisites =  {"combat-robotics", "762x39-ammo-3", "advanced-chemistry"}
data.raw["technology"]["combat-robotics-2"].effects = {{
        type = "unlock-recipe",
        recipe = "recipe-robot-762x39"
		}}
data.raw["technology"]["combat-robotics-3"].prerequisites =  {"combat-robotics-2", "127x99-ammo-3", "high-tech-chemistry"}
data.raw["technology"]["combat-robotics-3"].effects = {{
        type = "unlock-recipe",
        recipe = "recipe-robot-127x99"
		}}
data.raw["technology"]["follower-robot-count-3"].prerequisites = {"follower-robot-count-2", "combat-robotics-2"}
data.raw["technology"]["follower-robot-count-7"].prerequisites = {"follower-robot-count-6", "rocket-silo"}
data.raw["technology"]["land-mine"].prerequisites =  {"explosives", "electrolize"}
data.raw["technology"]["land-mine"].effects = {{
        type = "unlock-recipe",
        recipe = "recipe-station-mine"
		}}
data.raw["technology"]["explosives"].prerequisites = {"sulfur-processing", "heavy-basic"}
data.raw["technology"]["explosives"].order = "a-a-e-b"
data.raw["technology"]["explosives"].effects = { { type = "unlock-recipe", recipe = "explosives" } }

data.raw["technology"]["rocket-speed-1"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.1" } }
data.raw["technology"]["rocket-speed-1"].unit.count = 200
data.raw["technology"]["rocket-speed-2"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.15" } }
data.raw["technology"]["rocket-speed-2"].unit.count = 300
data.raw["technology"]["rocket-speed-3"].prerequisites = {"rocket-speed-2", "advanced-chemistry"}
data.raw["technology"]["rocket-speed-3"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.2" } }
data.raw["technology"]["rocket-speed-3"].unit.count = 200
data.raw["technology"]["rocket-speed-4"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.25" } }
data.raw["technology"]["rocket-speed-4"].unit.count = 250
data.raw["technology"]["rocket-speed-5"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.3" } }
data.raw["technology"]["rocket-speed-6"].prerequisites = {"rocket-speed-5", "high-tech-chemistry"}
data.raw["technology"]["rocket-speed-6"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.25" } }
data.raw["technology"]["rocket-speed-7"].effects = { { type = "gun-speed", ammo_category = "tank-rockets", modifier = "0.25" } }
data.raw["technology"]["rocket-silo"].prerequisites = {"concrete", "solar-energy", "electric-energy-accumulators-1", "rocket-speed-5", "high-tech-chemistry"}

data.raw["technology"]["tanks"].icon = "__hardcorio__/graphics/technology/tank.png"
data.raw["technology"]["tanks"].icon_size = 64
data.raw["technology"]["tanks"].prerequisites =  {"rocketry", "nuclear-power"}
data.raw["technology"]["tanks"].effects = {
		{
        type = "unlock-recipe",
        recipe = "recipe-new-tank"
		},
		{
        type = "unlock-recipe",
        recipe = "recipe-125x"
		}
		}
data.raw["technology"]["tanks"].unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 20
    }
data.raw["technology"]["automobilism"].effects = { 
	  {	
        type = "unlock-recipe",
        recipe = "recipe-truck"
      },
      {	
        type = "unlock-recipe",
        recipe = "recipe-hummer"
      }
	  }
data.raw["technology"]["explosive-rocketry"].icon = "__hardcorio__/graphics/technology/rocketry-exp.png"
data.raw["technology"]["explosive-rocketry"].icon_size = 64
data.raw["technology"]["explosive-rocketry"].prerequisites =  {"rocketry", "nuclear-power"}
data.raw["technology"]["explosive-rocketry"].effects = 
		{
		{
        type = "unlock-recipe",
        recipe = "recipe-rockets-1"
		},
		{
        type = "unlock-recipe",
        recipe = "recipe-rockets-3"
		}
		}
data.raw["technology"]["rocketry"].icon = "__hardcorio__/graphics/technology/rocketry.png"
data.raw["technology"]["rocketry"].icon_size = 64
data.raw["technology"]["rocketry"].prerequisites =  {"automobilism", "land-mine"}
data.raw["technology"]["rocketry"].effects = 
    {	
      {
        type = "unlock-recipe",
        recipe = "recipe-rockets-2"
      },
      {
        type = "unlock-recipe",
        recipe = "recipe-hydrogen-can"
      }
	}
data.raw["technology"]["gates"].prerequisites = {"steel-processing", "stone-walls", "chemistry"}


data.raw["technology"]["oil-processing"].prerequisites = {"steel-processing", "chemistry"}
data.raw["technology"]["advanced-oil-processing"].prerequisites = {"oil-processing", "advanced-chemistry"}
data.raw["technology"]["battery"].effects =
    {
      {
        type = "unlock-recipe",
        recipe = "battery"
      }
    }
data.raw["technology"]["mining-productivity-4"].prerequisites = {"mining-productivity-1", "advanced-chemistry"}
data.raw["technology"]["mining-productivity-8"].prerequisites = {"mining-productivity-4", "production-chemistry"}
data.raw["technology"]["mining-productivity-12"].prerequisites = {"mining-productivity-8", "high-tech-chemistry"}
data.raw["technology"]["mining-productivity-16"].prerequisites = {"mining-productivity-12", "rocket-silo"}
data.raw["technology"]["inserter-capacity-bonus-1"].prerequisites = {"logistics", "chemistry"}
data.raw["technology"]["inserter-capacity-bonus-2"].prerequisites = {"inserter-capacity-bonus-1", "logistics-2"}
data.raw["technology"]["inserter-capacity-bonus-3"].prerequisites = {"inserter-capacity-bonus-2", "logistics-3"}
data.raw["technology"]["inserter-capacity-bonus-4"].prerequisites = {"inserter-capacity-bonus-3", "production-chemistry"}
data.raw["technology"]["inserter-capacity-bonus-7"].prerequisites = {"inserter-capacity-bonus-6", "high-tech-chemistry"}
data.raw["technology"]["inserter-capacity-bonus-1"].effects =
    {
      {
        type = "inserter-stack-size-bonus",
        modifier = 1
      }
    }
data.raw["technology"]["inserter-capacity-bonus-2"].effects =
    {
      {
        type = "inserter-stack-size-bonus",
        modifier = 1
      }
    }
data.raw["technology"]["coal-liquefaction"].prerequisites = {"advanced-oil-processing", "production-chemistry"}
data.raw["technology"]["nuclear-fuel-reprocessing"].prerequisites = {"nuclear-power", "production-chemistry"}
data.raw["technology"]["kovarex-enrichment-process"].prerequisites = {"nuclear-power", "high-tech-chemistry"}
data.raw["technology"]["nuclear-power"].prerequisites = {"advanced-electronics", "concrete", "advanced-chemistry"}

data.raw["technology"]["artillery"].prerequisites = {"high-tech-chemistry", "concrete", "radar"}
data.raw["technology"]["artillery-shell-range-1"].prerequisites = {"artillery", "rocket-silo"}
data.raw["technology"]["artillery-shell-speed-1"].prerequisites = {"artillery", "rocket-silo"}

table.insert(data.raw["technology"]["nuclear-power"].effects, 4, {type = "unlock-recipe", recipe = "elerium-processing"})
for i in pairs(data.raw["technology"]) do
	for j,k in ipairs(data.raw["technology"][i].unit.ingredients) do
		if k[1] == "military-science-pack" then data.raw["technology"][i].unit.ingredients[j] = nil end
	end
end
