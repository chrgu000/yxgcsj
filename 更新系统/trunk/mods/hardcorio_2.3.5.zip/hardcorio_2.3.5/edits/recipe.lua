data.raw["recipe"]["steam-engine"].normal.energy_required = 5
data.raw["recipe"]["steam-engine"].expensive.energy_required = 5
data.raw["recipe"]["boiler"].energy_required = 5
data.raw["recipe"]["steam-turbine"].energy_required = 20
data.raw["recipe"]["heat-exchanger"].energy_required = 10
data.raw["recipe"]["centrifuge"].energy_required = 40
data.raw["recipe"]["nuclear-reactor"].energy_required = 80
data.raw["recipe"]["locomotive"].energy_required = 20
data.raw["recipe"]["cargo-wagon"].energy_required = 20
data.raw["recipe"]["fusion-reactor-equipment"].ingredients =  { {"processing-unit", 100}, {"uranium-fuel-cell", 10}, {"elerium", 10}, {"alien-artifact", 30} }

data.raw["recipe"]["pipe-to-ground"].result_count = 1
data.raw["recipe"]["transport-belt"].enabled = "false"
data.raw["recipe"]["underground-belt"].ingredients = { {"iron-plate", 5}, {"transport-belt", 3} }
data.raw["recipe"]["underground-belt"].result_count = 1
data.raw["recipe"]["fast-underground-belt"].ingredients = { {"iron-gear-wheel", 15}, {"underground-belt", 1} }
data.raw["recipe"]["fast-underground-belt"].result_count = 1
data.raw["recipe"]["express-underground-belt"].category = "crafting-with-fluid"
data.raw["recipe"]["express-underground-belt"].ingredients = { {"iron-gear-wheel", 15}, {"fast-underground-belt", 1}, {type="fluid", name="lubricant", amount=60} }
data.raw["recipe"]["express-underground-belt"].result_count = 1

data.raw["recipe"]["pistol"].enabled = "false"
data.raw["recipe"]["firearm-magazine"].enabled = "false"

data.raw["recipe"]["flamethrower-ammo"].ingredients = {{type="item", name="iron-plate", amount=5}, {type="fluid", name="light-oil", amount=150}, {type="fluid", name="heavy-oil", amount=150}}

data.raw["recipe"]["repair-pack"].ingredients =
    {
      {"iron-plate", 2},
      {"copper-cable", 6},
      {"iron-gear-wheel", 2}
    }
data.raw["recipe"]["offshore-pump"].ingredients =
    {
      {"iron-stick", 2},
      {"pipe", 3},
      {"iron-gear-wheel", 2}
    }
data.raw["recipe"]["explosives"].normal.result_count = 1
data.raw["recipe"]["explosives"].expensive.result_count = 1
data.raw["recipe"]["cliff-explosives"].ingredients =
    {
      {"explosives", 5},
      {"coal", 15},
      {"empty-barrel", 1},
    }
data.raw["recipe"]["artillery-wagon"].energy_required = 20
data.raw["recipe"]["artillery-shell"].energy_required = 60
data.raw["recipe"]["artillery-shell"].ingredients =
    {
      {"steel-plate", 12},
      {"plastic-bar", 12},
      {"radar", 1},
      {"explosives", 8},
    }
	
data.raw["recipe"]["electronic-circuit"].normal.enabled = false
data.raw["recipe"]["electronic-circuit"].expensive.enabled = false
data.raw["recipe"]["electric-mining-drill"].normal.enabled = false
data.raw["recipe"]["electric-mining-drill"].expensive.enabled = false
data.raw["recipe"]["inserter"].enabled = false
data.raw["recipe"]["radar"].enabled = false
data.raw["recipe"]["lab"].enabled = false
data.raw["recipe"]["science-pack-2"].enabled = false

data.raw["recipe"]["iron-plate"].subgroup = "smelting"
data.raw["recipe"]["iron-plate"].order = "a-a"
data.raw["recipe"]["copper-plate"].subgroup = "smelting"
data.raw["recipe"]["copper-plate"].order = "a-b"
data.raw["recipe"]["steel-plate"].subgroup = "smelting"
data.raw["recipe"]["steel-plate"].order = "c-a"

data.raw["recipe"]["plastic-bar"].subgroup = "chemistry"
data.raw["recipe"]["plastic-bar"].order = "a-a"
data.raw["recipe"]["sulfur"].subgroup = "chemistry"
data.raw["recipe"]["sulfur"].order = "b-a"
data.raw["recipe"]["explosives"].subgroup = "chemistry"
data.raw["recipe"]["explosives"].order = "b-b"
data.raw["recipe"]["sulfuric-acid"].subgroup = "chemistry"
data.raw["recipe"]["sulfuric-acid"].order = "b-c"
data.raw["recipe"]["battery"].subgroup = "chemistry"
data.raw["recipe"]["battery"].order = "c-a"

