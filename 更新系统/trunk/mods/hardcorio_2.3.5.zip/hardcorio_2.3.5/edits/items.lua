
data.raw["armor"]["light-armor"].durability = 300
data.raw["armor"]["heavy-armor"].durability = 1500
data.raw["armor"]["modular-armor"].durability = 3000
data.raw["armor"]["power-armor"].durability = 4000
data.raw["armor"]["power-armor-mk2"].durability = 6000

data.raw["movement-bonus-equipment"]["exoskeleton-equipment"].movement_bonus = 0.2

data.raw["armor"]["light-armor"].resistances = { { type = "claw", decrease = 1, percent = 30 }, { type = "acid", decrease = 4, percent = 70 }, { type = "explosion", decrease = 2, percent = 20 }}
data.raw["armor"]["heavy-armor"].resistances = { { type = "claw", decrease = 2, percent = 40 }, { type = "acid", decrease = 5, percent = 80 }, { type = "explosion", decrease = 5, percent = 25 }}
data.raw["armor"]["modular-armor"].resistances = { { type = "claw", decrease = 1, percent = 50 }, { type = "acid", decrease = 1, percent = 50 }, { type = "explosion", decrease = 10, percent = 30 }}
data.raw["armor"]["power-armor"].resistances = { { type = "claw", decrease = 1, percent = 50 }, { type = "acid", decrease = 1, percent = 50 }, { type = "explosion", decrease = 15, percent = 40 }}
data.raw["armor"]["power-armor-mk2"].resistances = { { type = "claw", decrease = 1, percent = 50 }, { type = "acid", decrease = 1, percent = 50 }, { type = "explosion", decrease = 20, percent = 50 }}

data.raw["gun"]["flamethrower"].attack_parameters.range = 10
data.raw["gun"]["flamethrower"].attack_parameters.cooldown = 2
data.raw["gun"]["flamethrower"].subgroup = "127x33"
data.raw["gun"]["flamethrower"].order = "e-a"
data.raw["gun"]["flamethrower"].stack_size = 1
data.raw["ammo"]["flamethrower-ammo"].subgroup = "127x33"
data.raw["ammo"]["flamethrower-ammo"].order = "e-b"
data.raw["ammo"]["flamethrower-ammo"].stack_size = 5

data.raw["ammo"]["artillery-shell"].stack_size = 5

data.raw["stream"]["handheld-flamethrower-fire-stream"].action =
    {
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-fire",
              entity_name = "fire-flame",
              initial_ground_flame_count = 2
            }
          }
        }
      },
      {
        type = "area",
        radius = 2.5,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-sticker",
              sticker = "fire-sticker"
            },
            {
              type = "damage",
              damage = {amount = 0.1, type = "explosion"},
              apply_damage_to_trees = false
            }
          }
        }
      }
    }
data.raw["fire"]["fire-flame"].damage_per_tick = {amount = 0.2, type = "explosion"}
data.raw["sticker"]["fire-sticker"].duration_in_ticks = 600
data.raw["sticker"]["fire-sticker"].damage_per_tick = { amount = 0.2, type = "explosion" }

data.raw["module"]["effectivity-module"].effect = { consumption = {bonus = -0.3}, pollution = {bonus = -0.1}}
data.raw["module"]["effectivity-module-2"].effect = { consumption = {bonus = -0.4}, pollution = {bonus = -0.2}}
data.raw["module"]["effectivity-module-3"].effect = { consumption = {bonus = -0.5}, pollution = {bonus = -0.3}}

table.insert(data.raw["module"]["productivity-module"].limitation,"elerium-processing")
table.insert(data.raw["module"]["productivity-module-2"].limitation,"elerium-processing")
table.insert(data.raw["module"]["productivity-module-3"].limitation,"elerium-processing")


data.raw["item-subgroup"]["science-pack"].group = "production"
data.raw["item-subgroup"]["armor"].order = "k"
data.raw["item-subgroup"]["equipment"].order = "l"
data.raw["item-subgroup"]["defensive-structure"].order = "m"

--data.raw["item"]["empty-barrel"].order = "o[empty-barrel]"
data.raw["item"]["radar"].order = "c[radar]-a[radar]"
data.raw["tool"]["production-science-pack"].icon = "__hardcorio__/graphics/icons/items/production-science-pack.png"


data.raw["tool"]["military-science-pack"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["item-with-entity-data"]["car"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item-with-entity-data"]["tank"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["gun-turret"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["laser-turret"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["flamethrower-turret"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["land-mine"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["personal-laser-defense-equipment"].flags = {"goes-to-quickbar", "hidden"}
data.raw["item"]["discharge-defense-equipment"].flags = {"goes-to-quickbar", "hidden"}
data.raw["ammo"]["firearm-magazine"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["piercing-rounds-magazine"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["uranium-rounds-magazine"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["shotgun-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["piercing-shotgun-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["cannon-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["explosive-cannon-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["uranium-cannon-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["explosive-uranium-cannon-shell"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["rocket"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["explosive-rocket"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["ammo"]["atomic-bomb"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["pistol"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["submachine-gun"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["tank-machine-gun"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["vehicle-machine-gun"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["shotgun"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["combat-shotgun"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["gun"]["rocket-launcher"].flags = {"goes-to-main-inventory", "hidden"}
data.raw["capsule"]["raw-fish"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["grenade"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["cluster-grenade"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["poison-capsule"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["slowdown-capsule"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["defender-capsule"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["destroyer-capsule"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["distractor-capsule"].flags = {"goes-to-quickbar", "hidden"}
data.raw["capsule"]["discharge-defense-remote"].flags = {"goes-to-quickbar", "hidden"}