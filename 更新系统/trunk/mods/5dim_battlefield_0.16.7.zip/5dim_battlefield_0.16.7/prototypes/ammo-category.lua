data:extend({
  {
    type = "ammo-category",
    name = "5d-artillery-shell"
  },
})
