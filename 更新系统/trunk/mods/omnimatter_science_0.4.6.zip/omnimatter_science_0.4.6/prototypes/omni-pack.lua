data:extend({
  {
    type = "tool",
    name = "omni-pack",
    icon = "__base__/graphics/icons/production-science-pack.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "science-pack",
    order = "a[science-pack-1]",
	icon_size = 32,
    stack_size = 200,
    durability = 1,
    durability_description_key = "description.science-pack-remaining-amount"
  },
  {
	type = "recipe",
	name = "omni-pack",
	enabled = false,
	ingredients = {
	},
	order = "a[angelsore1-crushed]",
	icon = "__base__/graphics/icons/production-science-pack.png",
	results = {{type = "item", name = "omni-pack", amount=1}},
	energy_required = 5,
	icon_size = 32,
	},
})