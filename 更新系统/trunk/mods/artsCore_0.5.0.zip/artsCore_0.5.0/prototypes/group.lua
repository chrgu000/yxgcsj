data:extend(
{
  {
    type = "item-group",
    name = "ore-fluid",
    order = "e-a",
    inventory_order = "e-a",
    icon = "__artsCore__/graphics/item-group/ore-fluid.png",
	icon_size = 64,
  },
  {
    type = "item-subgroup",
    name = "base-ore-fluid",
    group = "ore-fluid",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "solvent",
    group = "ore-fluid",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "5dim-ore-fluid",
    group = "ore-fluid",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "angels-ore-fluid",
    group = "ore-fluid",
    order = "d"
  },
  {
    type = "item-subgroup",
    name = "bob-ore-fluid",
    group = "ore-fluid",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "bob-ore-fluid",
    group = "ore-fluid",
    order = "f"
  }
}
)

data:extend(
{
  {
    type = "item-group",
    name = "Debug",
    order = "e-b",
    inventory_order = "e-b",
    icon = "__artsCore__/graphics/item-group/Debug.png",
	icon_size = 64,
  },
  {
    type = "item-subgroup",
    name = "Debug-ore",
    group = "Debug",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "Debug-res",
    group = "Debug",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "Debug-fluid",
    group = "Debug",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "Debug-item",
    group = "Debug",
    order = "d"
  }
}
)
