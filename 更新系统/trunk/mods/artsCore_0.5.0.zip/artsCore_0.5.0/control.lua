--[[

script.on_event(defines.events.on_player_created, function(event)
  local player = game.players[event.player_index]
    player.print({"test"})
    player.print(angelsmods)
--    player.print(angelsmods.components)
end)

--global

]]--

script.on_init(function()
  if global.arts == nil then
    global.arts = {}
  end
end)

-- script.on_load(function(event)
  -- if global.arts == nil then
    -- global.arts = {}
  -- end
-- end)
