local Technology = require("stdlib/data/technology")

Technology {
    type = "technology",
    name = "py-burner",
    icon = "__pyindustry__/graphics/technology/burner.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"steel-processing"},
    effects = {},
    unit = {
        count = 40,
        ingredients = {
            {"science-pack-1", 2}
        },
        time = 45
    }
}
