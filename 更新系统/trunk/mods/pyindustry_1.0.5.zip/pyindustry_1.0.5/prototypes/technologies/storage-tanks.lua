local Technology = require("stdlib/data/technology")

Technology {
    type = "technology",
    name = "py-storage-tanks",
    icon = "__pyindustry__/graphics/technology/storage-tanks.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"fluid-handling"},
    effects = {},
    unit = {
        count = 35,
        ingredients = {
            {"science-pack-1", 2}
        },
        time = 45
    }
}
