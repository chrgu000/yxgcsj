

if not NE_Expansion then NE_Expansion = {} end
if not NE_Expansion.Settings then NE_Expansion.Settings = {} end
if not NE_Functions then NE_Functions = {} end
