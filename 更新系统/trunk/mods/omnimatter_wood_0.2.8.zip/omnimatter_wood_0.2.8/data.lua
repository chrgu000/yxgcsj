require("prototypes.category")
require("prototypes.items")
require("prototypes.technology")
require("prototypes.entities")
require("prototypes.constants")
require("prototypes.recipes")
require("prototypes.angels-bioprocessing")
require("prototypes.bioindustries")


