
if mods["aai-industry-sp0"] then
	industry.add_tech("omniwaste")
end

omni.add_omniwaste()
omni.lib.add_unlock_recipe("omniwaste","waste-mutation")

if mods["omnimatter_marathon"] then
	omni.marathon.equalize("burner-omniphlog","omni-mutator")
end