data:extend(
{
  {
    type = "bool-setting",
    name = "omniwood-all-mutated",
    setting_type = "startup",
    default_value = true,
	order=a
  },
  {
    type = "bool-setting",
    name = "omniwood-pure-wood-only",
    setting_type = "startup",
    default_value = true,
	order=a
  },
}
)


