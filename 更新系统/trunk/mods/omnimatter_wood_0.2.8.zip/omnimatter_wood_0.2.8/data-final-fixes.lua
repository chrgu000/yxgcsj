omni.lib.add_prerequisite("omnimutator", "omnic-hydrolyzation-1")

if bobmods and bobmods.electronics then omni.lib.add_recipe_ingredient("omni-mutator",{"basic-circuit-board",2}) end

if mods["bobgreenhouse"] then
	omni.lib.remove_recipe_all_techs("bob-seedling")
	data.raw.technology["omnimutator-2"].enabled=false
	omni.lib.add_prerequisite("bob-greenhouse","omnimutator")
	omni.lib.remove_recipe_all_techs("initial-wood-mutation")
	omni.lib.remove_recipe_all_techs("improved-wood-mutation")
	omni.lib.add_unlock_recipe("omnimutator","seedling-mutation")
	omni.lib.replace_recipe_all_techs("bob-basic-greenhouse-cycle","basic-mutated-wood-growth")
	omni.lib.replace_recipe_all_techs("bob-advanced-greenhouse-cycle","advanced-mutated-wood-growth")
end

if mods["bobplates"] then
	omni.lib.replace_recipe_ingredient("omni-mutator","copper-plate","glass")
end

if settings.startup["omniwood-pure-wood-only"].value then
	if mods["bobelectronics"] then
		omni.lib.remove_recipe_all_techs("synthetic-wood")
		omni.lib.remove_recipe_all_techs("bob-resin-wood")
	end
end	

if settings.startup["omniwood-all-mutated"].value then
	require("prototypes.override")
end

if mods["angelsbioprocessing"] then
	omni.lib.add_prerequisite("bio-processing-green","omni-algae")
	omni.lib.add_prerequisite("bio-processing-brown","omni-algae")
	
	omni.lib.remove_unlock_recipe("bio-processing-green","algae-farm")
	
	omni.lib.add_recipe_ingredient("algae-green",{type="item",name="omni-algae",amount=40})
	omni.lib.add_recipe_ingredient("algae-brown",{type="item",name="omni-algae",amount=40})
	omni.lib.add_recipe_ingredient("algae-red",{type="item",name="omni-algae",amount=40})
	omni.lib.add_recipe_ingredient("algae-blue",{type="item",name="omni-algae",amount=40})
end

if mods["omnimatter_marathon"] then
	omni.marathon.exclude_recipe("omnic-waste")
	omni.marathon.exclude_recipe("waste-mutation")
end

if mods["pycoalprocessing"] then
	local pylog = {"log1", "log2", "log3", "log4", "log5", "log6", "log-organics", "log-wood"}
	for _, p in pairs(pylog) do
		omni.lib.remove_recipe_all_techs(p)
		data.raw.recipe[p] = nil	
	end
	omni.lib.remove_recipe_all_techs("botanical-nursery")
	data.raw.recipe["botanical-nursery"] = nil
end