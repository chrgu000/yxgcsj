data:extend(
{
  {
    type = "item-group",
    name = "omniwood",
    order = "z",
    inventory_order = "z",
    icon = "__omnimatter_wood__/graphics/technology/omniwood-category.png",
	icon_size = 128,
  },
  {
    type = "recipe-category",
    name = "omni-mutator"
  },
  {
    type = "item-subgroup",
    name = "omni-mutator-items",
    group = "omnimatter",
    order = "e-f"
  },
  {
    type = "item-subgroup",
    name = "omni-mutator",
    group = "omnimatter",
    order = "e-f"
  },
  {
    type = "item-subgroup",
    name = "algae",
    group = "omnimatter",
    order = "e-f"
  },
}
)

