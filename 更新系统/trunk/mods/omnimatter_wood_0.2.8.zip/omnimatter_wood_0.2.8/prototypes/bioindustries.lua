if mods["Bio_Industries"] then
	if not mods["bobgreenhouse"] then
	data:extend({
  {
    type = "item",
    name = "omniseedling",
    icons = {
		{icon="__omnimatter_wood__/graphics/icons/Seedling.png"},
	},
    flags = {"goes-to-quickbar"},
	subgroup = "intermediate-product",
    order = "g[greenhouse]",
    stack_size = 400
  },
	})
	end
	omni.lib.replace_recipe_result("bi-Seedling_Mk1","seedling",{"omniseedling",40})
	data.raw.recipe["bi-Seedling_Mk1"].icon=nil
	data.raw.recipe["bi-Seedling_Mk1"].icons={
		{icon="__omnimatter_wood__/graphics/icons/Seedling.png"},
		{icon="__base__/graphics/icons/fluid/water.png",
		scale = 0.4375,
		shift = { 10, 10},}
		}
	data.raw.recipe["bi-Seedling_Mk1"].category="omni-mutator"
	omni.lib.replace_recipe_result("bi-Seedling_Mk2","seedling",{"omniseedling",60})
	data.raw.recipe["bi-Seedling_Mk2"].icon=nil
	data.raw.recipe["bi-Seedling_Mk2"].icons={
		{icon="__omnimatter_wood__/graphics/icons/Seedling.png"},
		{icon="__Bio_Industries__/graphics/icons/ash.png",
		scale = 0.4375,
		shift = { 10, 10},}
		}
	data.raw.recipe["bi-Seedling_Mk2"].category="omni-mutator"
	omni.lib.replace_recipe_result("bi-Seedling_Mk3","seedling",{"omniseedling",90})
	data.raw.recipe["bi-Seedling_Mk3"].icon=nil
	data.raw.recipe["bi-Seedling_Mk3"].icons={
		{icon="__omnimatter_wood__/graphics/icons/Seedling.png"},
		{icon="__Bio_Industries__/graphics/icons/fertiliser_32.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	data.raw.recipe["bi-Seedling_Mk3"].category="omni-mutator"
	omni.lib.replace_recipe_result("bi-Seedling_Mk4","seedling",{"omniseedling",160})
	data.raw.recipe["bi-Seedling_Mk4"].icon=nil
	data.raw.recipe["bi-Seedling_Mk4"].icons={
		{icon="__omnimatter_wood__/graphics/icons/Seedling.png"},
		{icon="__Bio_Industries__/graphics/icons/advanced_fertiliser_32.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	data.raw.recipe["bi-Seedling_Mk4"].category="omni-mutator"
	
	omni.lib.replace_recipe_result("bi-Logs_Mk1","raw-wood",{"mutated-wood",60})
	data.raw.recipe["bi-Logs_Mk1"].icon=nil
	data.raw.recipe["bi-Logs_Mk1"].icons={
		{icon="__omnimatter_wood__/graphics/icons/mutated-wood2.png"},
		{icon="__base__/graphics/icons/fluid/water.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	omni.lib.replace_recipe_ingredient("bi-Logs_Mk1","seedling","omniseedling")
	
	omni.lib.replace_recipe_result("bi-Logs_Mk2","raw-wood",{"mutated-wood",100})
	data.raw.recipe["bi-Logs_Mk2"].icon=nil
	data.raw.recipe["bi-Logs_Mk2"].icons={
		{icon="__omnimatter_wood__/graphics/icons/mutated-wood2.png"},
		{icon="__Bio_Industries__/graphics/icons/ash.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	
	omni.lib.replace_recipe_ingredient("bi-Logs_Mk2","seedling","omniseedling")
	
	omni.lib.replace_recipe_result("bi-Logs_Mk3","raw-wood",{"mutated-wood",150})
	data.raw.recipe["bi-Logs_Mk3"].icon=nil
	data.raw.recipe["bi-Logs_Mk3"].icons={
		{icon="__omnimatter_wood__/graphics/icons/mutated-wood2.png"},
		{icon="__Bio_Industries__/graphics/icons/fertiliser_32.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	
	omni.lib.replace_recipe_ingredient("bi-Logs_Mk3","seedling","omniseedling")
	
	omni.lib.replace_recipe_result("bi-Logs_Mk4","raw-wood",{"mutated-wood",400})
	data.raw.recipe["bi-Logs_Mk4"].icon=nil
	data.raw.recipe["bi-Logs_Mk4"].icons={
		{icon="__omnimatter_wood__/graphics/icons/mutated-wood2.png"},
		{icon="__Bio_Industries__/graphics/icons/advanced_fertiliser_32.png",
		scale = 0.4375,
		shift = { 10, 10},}
	}
	
	omni.lib.replace_recipe_ingredient("bi-Logs_Mk4","seedling","omniseedling")
	
	omni.lib.add_prerequisite("bi_bio_farming", "omnimutator") 
end