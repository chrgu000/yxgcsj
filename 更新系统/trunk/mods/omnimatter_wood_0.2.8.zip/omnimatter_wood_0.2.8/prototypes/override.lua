
for _,tree in pairs(data.raw.tree) do
	if not string.find(tree.icon,"angelsbioprocessing") then
		if tree.minable then 
			if tree.minable.result then
				tree.minable.result="mutated-wood"
			else
				tree.minable.results[1].name="mutated-wood"
			end
		end
	end
end
