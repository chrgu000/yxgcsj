data:extend(
{
  {
    type = "item",
    name = "omni-mutator",
    icon = "__omnimatter_wood__/graphics/icons/omni-mutator.png",
    flags = {"goes-to-quickbar"},
    subgroup = "omni-mutator",
    order = "g[greenhouse]",
    place_result = "omni-mutator",
    icon_size = 32,
    stack_size = 5
  },
  {
    type = "item",
    name = "mutated-wood",
    icon = "__omnimatter_wood__/graphics/icons/mutated-wood2.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "6MJ",
    fuel_category = "chemical",
    subgroup = "omni-mutator",
    order = "g[seedling]",
    icon_size = 32,
    stack_size = 100
  },
  {
    type = "item",
    name = "omniseedling",
    icon = "__omnimatter_wood__/graphics/icons/omniseedling.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "1MJ",
    fuel_category = "chemical",
    subgroup = "omni-mutator",
    order = "g[seedling]",
    icon_size = 32,
    stack_size = 100
  },
}
)
