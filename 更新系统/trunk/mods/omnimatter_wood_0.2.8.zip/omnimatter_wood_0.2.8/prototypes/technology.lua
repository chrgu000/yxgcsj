data:extend(
{
  {
    type = "technology",
    name = "omnimutator",
    icon = "__omnimatter_wood__/graphics/technology/mutator.png",
    icon_size = 128,
    prerequisites =
    {
		"omniwaste"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "omni-mutator"
      },
      {
        type = "unlock-recipe",
        recipe = "initial-wood-mutation"
      },
    },
    unit =
    {
      count = 50,
      ingredients = 
      {
        {"science-pack-1", 1},
      },
      time = 15
    },
    order = "f-a-a"
  },
  {
    type = "technology",
    name = "omnimutator-2",
    icon = "__omnimatter_wood__/graphics/technology/mutator.png",
    icon_size = 128,
    prerequisites =
    {
		"omnimutator"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "improved-wood-mutation"
      },
    },
    unit =
    {
      count = 50,
      ingredients = 
      {
        {"science-pack-1", 3},
        {"science-pack-2", 2},
        {"science-pack-3", 1},
      },
      time = 15
    },
    order = "f-a-a"
  },
}
)

