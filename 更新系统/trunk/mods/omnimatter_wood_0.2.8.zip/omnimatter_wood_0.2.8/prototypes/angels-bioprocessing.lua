if mods["angelsbioprocessing"] then
data:extend(
{
	{
    type = "technology",
    name = "omni-algae",
    icon = "__angelsbioprocessing__/graphics/technology/algae-farm-tech.png",
    icon_size = 128,
    prerequisites =
    {
		"omnimutator",
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "algae-farm"
      },
      {
        type = "unlock-recipe",
        recipe = "omni-algae"
      },
    },
    unit =
    {
      count = 250,
      ingredients = 
      {
        {"science-pack-1", 1},
      },
      time = 15
    },
    order = "f-a-a"
  },
  {
    type = "item",
    name = "omni-algae",
    icon = "__omnimatter_wood__/graphics/icons/algae-omni.png",
    flags = {"goes-to-quickbar"},
    subgroup = "algae",
    order = "g[greenhouse]",
    stack_size = 500
  },
   {
    type = "recipe",
    name = "omni-algae",
    energy_required = 20,
	enabled = "false",
    category = "bio-processing",
	subgroup = "bio-processing-purple",
    ingredients ={
	{type="fluid",name="omnic-acid",amount=144},
	{type="item",name="omnite",amount=24},
	},
    results= {{type="item",name="omni-algae", amount = 144}},
    icon = "__omnimatter_wood__/graphics/icons/algae-omni.png",
   },
  {
    type = "item-subgroup",
    name = "bio-processing-purple",
	group = "bio-processing",
	order = "a",
  },
}
)
end