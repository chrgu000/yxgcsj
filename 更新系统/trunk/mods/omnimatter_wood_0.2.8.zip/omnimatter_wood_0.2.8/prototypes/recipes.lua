local omnic_production = omni.matter.get_constant("acid")*(30+(2-1)*210/(omni.matter.get_constant("fluid level")-1))
local omprize = math.min(12,21-math.floor(12*20/omnic_production+(5+0.84)/3))
--local omprize = math.min(12,math.floor(12*20/(get_ratio("acid")*(30+(omni.wood_gain_level-1)*210/(omni.fluid_levels-1)))+(5+0.84)/3))
--omnite for omnic acid: 12*20/(omni.acid_ratio*(30+(i-1)*210/(omni.fluid_levels-1)))
--Cost to produce wood: 5MJ
--energy cost of one cycle of omnic acid: 0.84 MJ

data:extend(
{
  {
    type = "recipe",
    name = "omni-mutator",
    energy_required = 10,
    enabled = "false",
    icon_size = 32,
    ingredients =
    {
      {type = "item", name = "omnicium-plate", amount = 10},
      {type = "item", name = "iron-plate", amount = 5},
      {type = "item", name = "copper-plate", amount = 5},
      {type = "item", name = "burner-omniphlog", amount = 1},
    },
    result = "omni-mutator"
  },
  {
    type = "recipe",
    name = "wood-extraction",
    icon = "__base__/graphics/icons/raw-wood.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[wood-extraction]",
    category = "omnite-extraction-both",
	energy_required = 5,
    enabled = true,
    ingredients =
    {
      {type = "item", name = "mutated-wood", amount = 5},
    },
    results =
    {
      {type = "item", name = "raw-wood", amount=1},
    },
  },
  {
    type = "recipe",
    name = "waste-mutation",
    icon = "__omnimatter_wood__/graphics/icons/mutated-wood2.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[wood-extraction]",
    category = "omniphlog",
	energy_required = 5,
    enabled = false,
    ingredients =
    {
      {type = "item", name = "raw-wood", amount = 1},
      {type = "fluid", name = "omnic-waste", amount = 200},
    },
    results =
    {
      {type = "item", name = "mutated-wood", amount=8},
    },
  },
}
)
if mods["bobgreenhouse"] then
data:extend({
  {
    type = "recipe",
    name = "seedling-mutation",
    icon = "__omnimatter_wood__/graphics/icons/omniseedling.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[greenhouse-cycle-1]",
    category = "omni-mutator",
	enabled=false,
	energy_required = 2,
    ingredients =
    {
      {type = "item", name = "omnite", amount = 5},
      {type = "item", name = "raw-wood", amount = 1},
      {type = "fluid", name = "omnic-acid", amount = 20},
      {type = "fluid", name = "water", amount = 100}
    },
    results =
    {
      {type = "item", name = "omniseedling", amount_min = 2, amount_max = 8},
    },
  },
  {
    type = "recipe",
    name = "basic-mutated-wood-growth",
    icon = "__omnimatter_wood__/graphics/icons/mutated-wood2.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[greenhouse-cycle-1]",
    category = "bob-greenhouse",
	enabled=false,
	energy_required = 40,
    ingredients =
    {
      {type = "item", name = "omniseedling", amount = 5},
      {type = "fluid", name = "water", amount = 50}
    },
    results =
    {
      {type = "item", name = "mutated-wood", amount_min = 10, amount_max = 30},
    },
  },
  {
    type = "recipe",
    name = "advanced-mutated-wood-growth",
    icon = "__omnimatter_wood__/graphics/icons/mutated-wood2.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[greenhouse-cycle-1]",
    category = "bob-greenhouse",
	energy_required = 30,
	enabled=false,
    ingredients =
    {
      {type = "item", name = "omniseedling", amount = 5},
      {type = "fluid", name = "water", amount = 50},
      {type = "item", name = "fertiliser", amount = 5}
    },
    results =
    {
      {type = "item", name = "mutated-wood", amount_min = 20, amount_max = 60},
    },
  },
 })
else
data:extend(
{
  {
    type = "recipe",
    name = "improved-wood-mutation",
    icon = "__base__/graphics/icons/raw-wood.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[greenhouse-cycle-1]",
    category = "omni-mutator",
	energy_required = 40,
    enabled = "false",
    ingredients =
    {
      {type = "item", name = "omnite", amount = omprize},
      {type = "item", name = "raw-wood", amount = 1},
      {type = "fluid", name = "omnic-acid", amount = 10},
      {type = "fluid", name = "water", amount = 100}
    },
    results =
    {
      {type = "item", name = "raw-wood", amount_min = 5, amount_max = 15},
      {type = "item", name = "mutated-wood", amount_min = 1, amount_max = 3},
    },
  },
  {
    type = "recipe",
    name = "initial-wood-mutation",
    icon = "__omnimatter_wood__/graphics/icons/mutated-wood2.png",
    icon_size = 32,
    subgroup = "omni-mutator-items",
    order = "g[greenhouse-cycle-1]",
    category = "omni-mutator",
	energy_required = 20,
    enabled = "false",
    ingredients =
    {
      {type = "item", name = "omnite", amount = omprize},
      {type = "item", name = "raw-wood", amount = 1},
      {type = "fluid", name = "omnic-acid", amount = 20},
      {type = "fluid", name = "water", amount = 100}
    },
    results =
    {
      {type = "item", name = "raw-wood", amount_min = 1, amount_max = 3},
      {type = "item", name = "mutated-wood", amount_min = 5, amount_max = 15},
    },
  },
}
)
end
--omnite-extraction-both
