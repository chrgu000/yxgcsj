classes = {}
starting_inventory = {}
respawn_inventory = {}


remote.add_interface("bobclasses", {
  add_classes = function(data)
    for name, class in pairs(data) do
      classes[name] = class
    end
  end,

  add_starting_inventory = function(data)
    for i, item in pairs(data) do
      table.insert(starting_inventory, item)
    end
  end,

  add_respawn_inventory = function(data)
    for i, item in pairs(data) do
      table.insert(respawn_inventory, item)
    end
  end
}
)


classes.ballanced = {
  entity_name = "player",
  button = {
    name = "bob_class_ballanced",
    tooltip = {"gui.bob-class-ballanced"},
    style = "bobclass_ballanced_button"
  },
  bonuses = {},
  starting_inventory = {
    add = {
    },
    replace = {
      {remove = {name="iron-plate", count=4}, add = {name="iron-axe", count=1}}
    }
  },
  respawn_inventory = {
    add = {
      {name="iron-axe", count=1},
    }
  }
}

--[[
script.on_event(defines.events.on_player_created, function(event)
  player.insert{name="iron-plate", count=8}
  player.insert{name="pistol", count=1}
  player.insert{name="firearm-magazine", count=10}
  player.insert{name="burner-mining-drill", count = 1}
  player.insert{name="stone-furnace", count = 1}
end)

script.on_event(defines.events.on_player_respawned, function(event)
  player.insert{name="pistol", count=1}
  player.insert{name="firearm-magazine", count=10}
end)
]]--

classes.miner = {
  entity_name = "bob-player-miner",
  button = {
    name = "bob_class_miner",
    tooltip = {"gui.bob-class-miner"},
    style = "bobclass_miner_button"
  },
  bonuses = {},
  starting_inventory = {
    add = {
    },
    replace = {
      {remove = {name="iron-plate", count=8}, add = {name="steel-axe", count=2}},
      {remove = {name="stone-furnace", count = 1}, add = {name="burner-mining-drill", count = 1}}
    }
  },
  respawn_inventory = {
    add = {
      {name="steel-axe", count=1},
    }
  }
}

classes.fighter = {
  entity_name = "bob-player-fighter",
  button = {
    name = "bob_class_fighter",
    tooltip = {"gui.bob-class-fighter"},
    style = "bobclass_fighter_button"
  },
  bonuses = {},
  starting_inventory = {
    add = {
    },
    replace = {
      {remove = {name="iron-plate", count=4}, add = {name="iron-axe", count=1}},
      {remove = {name="iron-plate", count=4}, add = {name="heavy-armor", count=1}},
      {remove = {name="pistol", count = 1}, add = {name="submachine-gun", count = 1}},
      {remove = {name="burner-mining-drill", count = 1}, add = {name="firearm-magazine", count=45}},
      {remove = {name="stone-furnace", count = 1}, add = {name="firearm-magazine", count=45}}
    }
  },
  respawn_inventory = {
    add = {
      {name="iron-axe", count=1},
    },
    replace = {
      {remove = {name="pistol", count = 1}, add = {name="submachine-gun", count = 1}}
    }
  }
}

classes.builder = {
  entity_name = "bob-player-builder",
  button = {
    name = "bob_class_builder",
    tooltip = {"gui.bob-class-builder"},
    style = "bobclass_builder_button"
  },
  bonuses = {
    character_crafting_speed_modifier = 0.2
  },
  starting_inventory = {
    add = {
      {name="burner-inserter", count=2},
      {name="transport-belt", count=10}
    },
    replace = {
      {remove = {name="iron-plate", count=4}, add = {name="iron-axe", count=1}},

      {remove = {name="iron-plate", count=4}, add = {name="burner-inserter", count = 2}},
      {remove = {name="pistol", count = 1}, add = {name="transport-belt", count=5}},
      {remove = {name="firearm-magazine", count = 10}, add = {name="transport-belt", count=5}},
    }
  },
  respawn_inventory = {
    add = {
      {name="iron-axe", count=1},
    }
  }
}



script.on_init(function()
  if not global.players then
    global.players = {}
  end
end)


script.on_configuration_changed(function()
  if not global.players then
    global.players = {}
  end
end)


script.on_load(function()
end)



function add_classes()
-- example call to add a class. Call on on_init and on_load.
  remote.call("bobclasses", "add_classes", {
    builder = {
      entity_name = "bob-player-builder",
      button = {
        name = "bob_class_builder",
        tooltip = {"gui.bob-class-builder"},
        style = "bobclass_builder_button"
      },
      bonuses = {
        character_crafting_speed_modifier = 0.2
      },
      starting_inventory = {
        {name="iron-axe", count=1},
        {name="burner-mining-drill", count = 1},
        {name="stone-furnace", count = 1},
        {name="burner-inserter", count=2},
        {name="transport-belt", count=10}
      },
      respawn_inventory = {
        {name="iron-axe", count=1},
        {name="pistol", count=1},
        {name="firearm-magazine", count=10},
      }
    }
  }
  )
-- example call to add items on spawn and respawn. Call on on_init and on_load.
  remote.call("bobclasses", "add_starting_inventory", {
      {name="iron-plate", count=8},
      {name="copper-plate", count=8}
  })
  remote.call("bobclasses", "add_respawn_inventory", {
      {name="iron-plate", count=4},
      {name="copper-plate", count=4}
  })
end


--script.on_event(defines.events.on_entity_died, function(event)
--entity :: LuaEntity
--cause :: LuaEntity (optional): The entity that did the killing if available.
--force :: LuaForce (optional): The force that did the killing if any.
--end)


--script.on_event(defines.events.on_player_died, function(event)
--player_index :: uint
--cause :: LuaEntity (optional)
--end)


--script.on_event(defines.events.on_pre_player_died, function(event)
--player_index :: uint
--cause :: LuaEntity (optional)
--end)


script.on_event(defines.events.on_player_created, function(event)
--player_index :: uint

  if not global.players[event.player_index] then
    global.players[event.player_index] = {}
  end

  global.players[event.player_index].respawn = false
  class_select(event.player_index)
end)


script.on_event(defines.events.on_player_respawned, function(event)
--player_index :: uint
--player_port :: LuaEntity (optional): The player port used to respawn if one was used.

  if not global.players[event.player_index] then
    global.players[event.player_index] = {}
  end

  global.players[event.player_index].respawn = true
  class_select(event.player_index)
end)


script.on_event(defines.events.on_gui_click, function(event)
  local player = game.players[event.player_index]
  for i, class in pairs(classes) do
    if event.element.valid and event.element.name == class.button.name then
      create_character(event.player_index, class)
      player.gui.center.bob_class_gui.destroy()
    end
  end
end)



function class_select(player_index)
  local player = game.players[player_index]
  if player.character then

    global.players[player_index].position = player.character.position
    global.players[player_index].surface = player.character.surface
    global.players[player_index].force = player.character.force
    global.players[player_index].character = player.character

--    player.set_controller{type = defines.controllers.ghost} -- Prevent interaction with the world.
    draw_gui(player_index)
  end
end


function draw_gui(player_index)
  local player = game.players[player_index]
  if not player.gui.center.bob_class_gui then
    local gui = player.gui.center.add{type = "frame", name = "bob_class_gui", caption = {"gui.bob-class-pick"}, direction = "vertical"}
    gui.add({type = "table", name = "table", column_count = 5})
    for i, class in pairs(classes) do
      gui.table.add{type = "button", name = class.button.name, tooltip = class.button.tooltip, style = class.button.style}
    end
  end
end


function create_character(player_index, class)
  local player = game.players[player_index]
  local position = global.players[player_index].character.position
  local surface = global.players[player_index].surface
  local force = global.players[player_index].force
  local character = global.players[player_index].character

--  player.character = surface.create_entity{name = class.entity_name, position = position, force = force} --, fast_replace = true}
  if character.name ~= class.entity_name then
    player.character = surface.create_entity{name = class.entity_name, position = position, force = force, fast_replace = true}
  end

--[[
  insert_items(player_index, character.get_inventory(defines.inventory.player_main).get_contents())
  insert_items(player_index, character.get_inventory(defines.inventory.player_guns).get_contents())
  insert_items(player_index, character.get_inventory(defines.inventory.player_ammo).get_contents())
  insert_items(player_index, character.get_inventory(defines.inventory.player_tools).get_contents())
  insert_items(player_index, character.get_inventory(defines.inventory.player_armor).get_contents())
  insert_items(player_index, character.get_inventory(defines.inventory.player_quickbar).get_contents())
]]--

--  character.destroy()

  for i, bonus in pairs(class.bonuses) do
    player.character[i] = bonus
  end
  if global.players[player_index].respawn then

    for i, item in pairs(class.respawn_inventory.add) do
      player.insert(item)
    end
    for i, item in pairs(respawn_inventory) do
      player.insert(item)
    end

    if class.respawn_inventory.replace then
      for i, item in pairs(class.respawn_inventory.replace) do
        if player.get_item_count(item.remove.name) >= item.remove.count then
          player.remove_item(item.remove)
          player.insert(item.add)
        end
      end
    end

  else

    for i, item in pairs(class.starting_inventory.add) do
      player.insert(item)
    end
    for i, item in pairs(starting_inventory) do
      player.insert(item)
    end

    if class.starting_inventory.replace then
      for i, item in pairs(class.starting_inventory.replace) do
        if player.get_item_count(item.remove.name) >= item.remove.count then
          player.remove_item(item.remove)
          player.insert(item.add)
        end
      end
    end

  end
end


function insert_items(player_index, items)
  local player = game.players[player_index]
  for i, item in pairs(items) do
    player.insert({name = i, count = item})
  end
end

