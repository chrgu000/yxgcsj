if not bobmods then bobmods = {} end
if not bobmods.classes then bobmods.classes = {} end

require("player")
require("style")


