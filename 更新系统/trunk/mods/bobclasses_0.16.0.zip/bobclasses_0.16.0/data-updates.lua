local multiplier = data.raw.player.player.inventory_size / 60
if settings.startup["bobmods-plates-inventorysize"] then
  multiplier = settings.startup["bobmods-plates-inventorysize"].value / 60
end

for index, player in pairs(bobmods.classes.players) do
  data.raw.player[player.name].inventory_size = math.floor(data.raw.player[player.name].inventory_size * multiplier)
end

if data.raw["recipe-category"]["mixing-furnace"] then
  table.insert(data.raw.player["bob-player-miner"].crafting_categories, "mixing-furnace")
end
