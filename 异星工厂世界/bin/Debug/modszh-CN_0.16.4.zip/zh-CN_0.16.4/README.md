# Factorio zh-CN Locale Library
Factorio zh-CN Locale Library<br>


###### 异星工厂 简体中文 语言 文本库<br>

1.文本库由贴吧吧主、小吧主、贴吧群管理、汉化组成员共同维护。<br>
2.可通过官方[mod网站](http://mods.factorio.com/)、异星工厂游戏中的模组下载页面、[异星工厂贴吧](https://tieba.baidu.com/f?kw=异星工厂)、[贴吧交流群](https://jq.qq.com/?_wv=1027&k=5e44RfV)下载。<br>
3.玩家可通过贴吧交流群提交mod汉化文本。<br>
4.文本库遵循GNU General Public License v3.0协议。<br>
